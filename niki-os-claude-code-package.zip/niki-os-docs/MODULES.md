# MODULES.md — Especificación Detallada de Módulos

## MÓDULO 1: COMUNICACIONES 💬
**ID:** `comunicaciones`  
**Acceso:** Casa Matriz, Franquiciada, Encargada  

### Funcionalidad
Canal de comunicación interna de toda la red. Funciona como un feed de mensajes con categorías.

### Categorías de mensajes
| ID | Label | Color |
|----|-------|-------|
| urgente | Urgente | Rojo `#C0392B` |
| operaciones | Operaciones | Teal `#7A9E9F` |
| capacitacion | Capacitación | Púrpura `#9B8EA6` |
| marketing | Marketing | Rosa `#DDA4AE` |
| rrhh | RRHH | Dorado `#CAA150` |

### Estructura de un mensaje
```
id, perfil (quién lo publicó), emoji, nombre, categoría, texto, fecha, fijado (bool), 
reacciones: { like: int, love: int, star: int }
```

### Reglas
- Casa Matriz puede fijar mensajes (📌)
- Cualquier perfil con acceso puede publicar y reaccionar
- Los mensajes fijados aparecen al tope
- Reacciones: 👍 like, 💖 love, ⭐ star

---

## MÓDULO 2: NIKI REWARDS ✨
**ID:** `rewards`  
**Acceso:** Todos los perfiles  

### Concepto
Sistema de puntos interno. **1 Destello = $1.000 ARS**. Las manicuras acumulan destellos y los canjean por premios del catálogo.

### Catálogo de premios
| Destellos | Premio | Valor aprox. |
|-----------|--------|-------------|
| 30 | Efectivo | $30.000 |
| 200 | Merchandising Niki BB | $200.000 |
| 350 | Vaso Stanley | $350.000 |
| 500 | Set Victoria's Secret + Cena para dos | $500.000 |
| 650 | Voucher $200.000 (spa/ropa/peluq.) | $650.000 |
| 800 | Lapicera Swarovski | $800.000 |
| 900 | Cabina de manicura + Aros Swarovski | $900.000 |
| 1.000 | Tablet | $1.000.000 |
| 1.200 | Cartera Guess | $1.200.000 |
| 2.000 | iPad | $2.000.000 |
| 2.500 | Viaje a Mar del Plata | $2.500.000 |
| 40.000 | Viaje a Brasil ✈️ | $4.000.000 |

### Tabs
1. **Ranking** — Lista de manicuras ordenadas por destellos, con barra de progreso al próximo premio
2. **Catálogo** — Todos los premios con filtros por categoría

---

## MÓDULO 3: COTIZADOR IA 💅
**ID:** `cotizador`  
**Acceso:** Todos los perfiles  

### Flujo (3 pasos)
1. **Paso 1:** Seleccionar tipo de local (Estándar / Premium) + forma de pago (Efectivo / Tarjeta)
2. **Paso 2:** Subir foto del diseño de uñas (cámara o galería)
3. **Paso 3:** Claude API analiza la imagen y devuelve el precio

### Integración Claude API
```javascript
// La imagen va en base64
// El prompt incluye la tabla de precios según local y forma de pago seleccionados
// Respuesta esperada en JSON:
{
  "nivel": "incluido" | "simple" | "complejo",
  "precio": 0 | 4500 | 6500,  // según tabla
  "diseno": "Baby boomer con nail art de flores",
  "justificacion": "El diseño incluye baby boomer en todas las uñas...",
  "elementos": ["baby boomer", "flores en relieve"],
  "tip": "Para un mejor resultado, asegurate de preparar la cutícula antes..."
}
```

### Tabla de precios completa
Ver `PRODUCT_SPEC.md` sección 2.

---

## MÓDULO 4: NIKI LAB 🧪
**ID:** `lab`  
**Acceso:** Todos los perfiles  

### Concepto
Ideas del equipo. Cualquier persona puede proponer una idea. Todos pueden votar y comentar. Solo Casa Matriz puede cambiar el estado.

### Categorías de ideas
| ID | Label | Emoji | Color |
|----|-------|-------|-------|
| colores | Colores | 🎨 | Rosa |
| productos | Productos | 💅 | Dorado |
| proyectos | Proyectos | 🚀 | Teal |
| servicios | Servicios | ✨ | Púrpura |
| operaciones | Operaciones | ⚙️ | Verde |

### Estados de una idea
| ID | Label | Quién puede cambiar |
|----|-------|---------------------|
| nueva | Nueva 💡 | Automático al publicar |
| analisis | En análisis 🔍 | Solo Casa Matriz |
| aprobada | Aprobada ✅ | Solo Casa Matriz |
| descartada | Descartada ✕ | Solo Casa Matriz |

### Estructura de idea
```
id, perfil, emoji, titulo, categoria, descripcion, estado, fecha,
votos: { casa_matriz: 0|1, franquiciada: 0|1, encargada: 0|1, manicura: 0|1, inversor: 0|1 },
comentarios: [{ perfil, emoji, texto, fecha }]
```

### Reglas
- Cada perfil solo puede votar una vez (toggle)
- Las ideas se ordenan por total de votos (mayor a menor)
- Filtros por categoría y por estado

---

## MÓDULO 5: FRASES DEL CAFÉ ☕
**ID:** `frases`  
**Acceso:** Casa Matriz, Franquiciada, Encargada  

### Concepto
30 frases inspiracionales estilo Pinterest para que las encargadas compartan con las clientas durante el servicio.

### Categorías
- 🔥 Actitud
- 👑 Poder  
- 💅 Belleza
- 🌸 Bienestar
- 😏 Humor

### Ejemplos de frases
- "A mal día, lindas uñas."
- "Ella no espera que la arreglen. Ella se arregla sola."
- "Manicura hecha, semana ganada."
- "El autocuidado no es un lujo. Es una necesidad."
- "Café, uñas y buena vibra. El plan perfecto."

### Funcionalidades
- Layout masonry 2 columnas (estilo Pinterest)
- Frase del día (cambia con la fecha)
- Favoritas (tab separado)
- Copiar frase al portapapeles
- Búsqueda por texto
- Filtros por categoría

---

## MÓDULO 6: STAY TUNED ✨
**ID:** `blog`  
**Acceso:** Todos los perfiles  

### Concepto
Feed de novedades, eventos y lanzamientos. Las tarjetas se expanden al tocar.

### Posts actuales
1. **Evento 17 de Mayo 2026** — Con countdown en tiempo real + link https://nikibeautybar.my.canva.site/
2. **Niki Lab activo** — Invitación al módulo
3. **NIKI OS v1.0** — Lanzamiento del sistema
4. **Junior → Senior → Master** — Sistema de niveles Junio 2026
5. **5 Obras en marcha** — Miami, Recoleta II, etc.

---

## MÓDULO 7: AUDITORÍAS 📋
**ID:** `auditorias`  
**Acceso:** Casa Matriz (completo), Franquiciada (solo sus locales)  

### Tipos de auditoría
- **Casa Matriz** (✦): El auditor es visible para todos
- **Misterioso Shopper** (🕵️): El auditor es anónimo — la franquiciada ve el resultado pero NO quién auditó

### 6 Ejes de evaluación (1-10 cada uno)
1. **Estado General** — Orden, limpieza, funcionamiento (ítems: Limpieza general, Orden en mesas, Estado mobiliario, Iluminación, Ambientación)
2. **Operación y Personal** — Dotación, actitud, liderazgo (ítems: Dotación completa, Uniforme, Actitud, Liderazgo encargada, Gestión de agenda)
3. **Imagen y Marca** — Coherencia visual (ítems: Coherencia visual, Elementos decorativos, Sin objetos fuera de estética, Presentación del café, Música y aromas)
4. **Equipamiento** — Mobiliario, insumos, herramientas (ítems: Estado mobiliario, Stock insumos, Organización, Estado equipos, Presentación materiales)
5. **Experiencia del Cliente** — Protocolo de servicio (ítems: Bienvenida, Tiempos de espera, Comunicación, Oferta adicionales, Despedida)
6. **Bioseguridad** — Protocolos de higiene (ítems: Esterilización, Descartables, Protocolo hongos, Higiene manicuras, Limpieza entre clientas)

### Puntaje total
Promedio de los 6 ejes. Semáforo: ≥8 verde, 6-7.9 dorado, <6 rojo.

### Flujo de nueva auditoría
1. Seleccionar local + tipo (CM / Misterioso Shopper) + fecha
2. Cargar puntaje (1-10) + observaciones por cada eje
3. Opción de fotos por eje
4. Conclusiones generales + puntos de mejora
5. Publicar → notificación automática a la franquiciada

### Llamado de atención
Si una auditoría tiene puntaje <6 en algún eje, se genera automáticamente un llamado de atención con 1 semana de plazo para resolver.

### Locales auditables
Belgrano, Saavedra, Cañitas, Recoleta I, Recoleta II, Bella Vista, Banfield, Lomas, Canning, Puerto Madero, Adrogue, Mar del Plata Centro, Mar del Plata Güemes.

---

## MÓDULO 8: OBRAS 🏗️
**ID:** `obras`  
**Acceso:** Casa Matriz, Franquiciada (solo sus obras), Inversor (solo sus obras)  

### Obras activas
| Nombre | Etapa actual |
|--------|-------------|
| Miami — Flagship USA | Obra Civil |
| Recoleta II | Búsqueda Local |
| Ramos Mejía | Firma Contrato |
| San Isidro | Firma Contrato |
| Caballito | Búsqueda Local |

### Checklist de equipamiento (Anexo II del contrato de franquicia)
39 ítems organizados en 8 categorías:

**Mobiliario y Equipamiento:**
Mesa manicura x4, Sillas pana x16, Banquetas pedicura x3, Sillones sector pies x3, Sillas recepción x2, Silla alta recepción x1, Sillones reclinables x2, Mueble recepción x1, Mesa aux. pestañas x1, Mueble toallas x1, Mueble auxiliar x2, Porta esmaltes x1, Apoya pies x3

**Infraestructura:**
Pintura y revestimientos, Artefactos eléctricos, Estructura deck porcelanato x1, Bachas y grifería pies x3, Honorarios arquitecta, Mano de obra y limpieza, Ploteo vidrieras

**Tecnología:**
Tornos x8, Cabinas LED x8, Esterilizador x1, Cámaras x2, PC/notebook x1, Parlantes x1

**Electrodomésticos:** Frigo bar x1, Cafetera x1, Lámparas mesa x8

**Textiles:** Delantales x8, Blazers recepcionista x2, Toallas x30

**Decoración:** Floreros/flores secas x1 set, Merchandising

**Stock inicial:** Cafetería 2 meses, Productos 2 meses, Gráfica 2 meses

**Inauguración:** Evento hasta 30 personas, Publicidad inaugural

### Por ítem del checklist
- **Origen:** Del depósito (Bárbara) | A comprar
- **Fecha límite**
- **Observaciones** (proveedor, presupuesto, link)
- **Checkbox:** listo ✓

### Alerta automática
Cuando una obra está en "Búsqueda Local" o "Firma Contrato" y hay ítems sin asignar → aparece alerta "Es momento de activar compras".

---

## MÓDULO 9: RRHH & TURNOS 👥
**ID:** `rrhh`  
**Acceso:** Casa Matriz, Encargada  

### Funcionalidades
- Listado de personal por local con nivel (Junior/Senior/Master), estado y contacto
- Gestión de turnos (mañana/tarde) por día de la semana
- Registro de vacantes activas
- Historial de ingresos

---

## MÓDULO 10: PROYECTOS CM 📁
**ID:** `proyectos`  
**Acceso:** Casa Matriz (todas), Directoras (solo las propias, Casa Matriz puede ver todas)  

### Campos de un proyecto
- Nombre del proyecto
- Fecha límite
- Prioridad: Alta 🔴 / Media 🟡 / Baja 🟢
- Descripción / comentarios (puede actualizarse)
- Tareas con checkbox (% de avance automático)
- Owner: una de las 4 directoras (Agustina, Laura, Bárbara, Lucía)

### Directoras y sus áreas
| Directora | Área |
|-----------|------|
| Agustina Quaglia | Marketing |
| Laura Felipetti | RRHH |
| Bárbara López | Obras y Stock |
| Lucía Becker | Stock e insumos |

### Permisos
- Nicole + Bárbara pueden editar cualquier proyecto
- Cada directora solo edita los suyos
- Nicole + Bárbara + todas las directoras pueden VER todos los proyectos

---

## MÓDULO 11: STOCK DEPÓSITO 📦
**ID:** `stock`  
**Acceso:** Casa Matriz (Bárbara principalmente)  

### Concepto
Inventario de Bárbara López con el equipamiento disponible en el depósito para futuras obras.

### Campos de ítem
- Nombre del ítem
- Cantidad
- Estado: Disponible ✅ / En uso 📦 / Dañado ⚠️
- Observaciones (local asignado, condición, notas)

### Items actuales (demo)
Tornos profesionales x6 (disponible), Cabinas LED x10 (disponible), Mesas de manicura x4 (disponible), Sillas pana x8 (disponible), Sillones reclinables x2 (disponible), Mueble recepción x1 (disponible), Apoyamanos x9 (disponible), Cabinas de manicura x2 (en uso - Canning), Tornos 2021 x2 (dañado), Mesa recepción vidrio x1 (dañado)

### Integración con Obras
El stock del depósito se muestra en el checklist de equipamiento de obras con badge "🏭 X en depósito".

---

## MÓDULO 12: PLAN DE CARRERA 🌱
**ID:** `plan_carrera`  
**Acceso:** Casa Matriz, Encargada, Franquiciada (solo sus manicuras), Manicura (solo el propio)  

### Permisos de edición
| Quién | Puede editar sobre |
|-------|-------------------|
| Nicole | Todos |
| Directoras + Bárbara | Manicuras, Encargadas, Franquiciadas |
| Encargada / Franquiciada | Sus manicuras del mismo local |
| Manicura | Solo notas propias |

### Registro 1:1
Campos de cada reunión 1:1:
- Fecha de la reunión
- Fecha del próximo 1:1
- Escala de desempeño 1-5: Crítico / A mejorar / En desarrollo / Muy bueno / Excepcional
- Notas de la reunión
- Plan de mejora
- Objetivos acordados (lista de ítems)
- Quién lo registró

---

## MÓDULO 13: INVERSORES 💰
**ID:** `inversores`  
**Acceso:** Casa Matriz (completo), Inversor (solo sus locales)  

### Estructura de inversor
```
id, nombre, local, porcentaje_participacion, tipo,
informes: [ { mes, fecha_envio, facturacion, gastos, resultado_neto,
              ocupacion_%, ticket_promedio, servicios,
              observaciones, dividendo, estado_dividendo,
              fecha_pago, metodo } ],
proximo_retiro: { fecha, metodo, monto_estimado }
```

### Estado del dividendo
- Pendiente ⏳
- Coordinando 📅
- Pagado ✅

### Flujo de retiro de dividendos
1. CM envía el informe mensual (con facturación, gastos, resultado)
2. El dividendo se calcula automáticamente: resultado_neto × porcentaje_participacion
3. CM (o el inversor) inicia "Coordinar retiro"
4. Se elige método: 🏦 Transferencia bancaria | 🏢 Retiro presencial en oficina
5. Se acuerda una fecha
6. CM marca como "Pagado" cuando se transfiere

### Alerta de dividendos pendientes
Si hay inversores con dividendos no pagados, aparece alerta en la vista lista con el total pendiente.

### Inversores actuales (demo)
| Inversor | Local | Participación |
|----------|-------|--------------|
| Inversor A | Lomas de Zamora | 30% |
| Inversor B | Puerto Madero | 20% |
| Inversor C | Canning | 40% |

---

## MÓDULOS PENDIENTES DE ESPECIFICACIÓN COMPLETA

### Skills 📊 (ID: `skills`)
- Tabla de los 34 servicios del menú
- Registro de % de skill por manicura
- Historial de skill reviews
- Cálculo automático de nivel (Junior/Senior/Master)

### Solicitud de Manicura 🤝 (ID: `manicuras`)
- Solicitar manicura por disponibilidad inmediata del local
- Filtrar por nivel (Junior/Senior/Master)
- Ver disponibilidad en tiempo real

### YouTube ▶️ (ID: `youtube`)
- Link al canal oficial de Niki Beauty Bar (pendiente de confirmar URL)
