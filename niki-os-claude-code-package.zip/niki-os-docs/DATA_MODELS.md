# DATA_MODELS.md — Modelos de Datos

## Stack de base de datos recomendado
**Firebase Firestore** (NoSQL, tiempo real, autenticación integrada)

Alternativa: **Supabase** (PostgreSQL, open source)

---

## COLECCIONES PRINCIPALES

### `/users/{userId}`
```typescript
interface User {
  id: string;
  nombre: string;
  email: string;
  perfil: "casa_matriz" | "franquiciada" | "encargada" | "manicura" | "inversor";
  local: string | null;        // Local asignado (null para CM e Inversores)
  area: string | null;         // Área de directoras (Marketing, RRHH, etc.)
  emoji: string;               // Avatar emoji elegido al registrarse
  codigoUsado: string;         // Código de invitación utilizado
  createdAt: Timestamp;
  lastLogin: Timestamp;
  activo: boolean;
}
```

### `/codigos_invitacion/{codigo}`
```typescript
interface CodigoInvitacion {
  codigo: string;              // Ej: "NIKI-MAN-2026"
  perfil: string;
  local: string | null;
  area: string | null;
  usado: boolean;
  usadoPor: string | null;     // userId
  usadoAt: Timestamp | null;
  creadoPor: string;           // userId de quien lo generó
  creadoAt: Timestamp;
}
```

### `/mensajes/{mensajeId}`
```typescript
interface Mensaje {
  id: string;
  perfil: string;
  userId: string;
  emoji: string;
  nombre: string;
  categoria: "urgente" | "operaciones" | "capacitacion" | "marketing" | "rrhh";
  texto: string;
  fecha: Timestamp;
  fijado: boolean;
  reacciones: {
    like: number;
    love: number;
    star: number;
  };
  reactores: {           // Para saber quién reaccionó y no repetir
    like: string[];      // array de userIds
    love: string[];
    star: string[];
  };
}
```

### `/ideas/{ideaId}`
```typescript
interface Idea {
  id: string;
  userId: string;
  perfil: string;
  emoji: string;
  titulo: string;
  categoria: "colores" | "productos" | "proyectos" | "servicios" | "operaciones";
  descripcion: string;
  estado: "nueva" | "analisis" | "aprobada" | "descartada";
  fecha: Timestamp;
  votos: {
    casa_matriz: number;    // 0 o 1
    franquiciada: number;
    encargada: number;
    manicura: number;
    inversor: number;
  };
  votantes: string[];       // array de userIds (para evitar votos dobles)
  comentarios: Comentario[];
}

interface Comentario {
  id: string;
  userId: string;
  perfil: string;
  emoji: string;
  texto: string;
  fecha: Timestamp;
}
```

### `/auditorias/{auditoriaId}`
```typescript
interface Auditoria {
  id: string;
  local: string;
  fecha: Timestamp;
  tipo: "casa_matriz" | "misterioso_shopper";
  auditorId: string;          // userId
  auditorNombre: string;
  auditorVisible: boolean;    // false = misterioso shopper
  puntajeTotal: number;       // promedio de las 6 categorías
  categorias: {
    [categoriaId: string]: {
      puntaje: number;        // 1-10
      observaciones: string;
      fotos: string[];        // URLs de Firebase Storage
    }
  };
  conclusiones: string;
  puntosMejora: string[];
  llamadoAtencion: boolean;
  plazoResolucion: Timestamp | null;
  createdAt: Timestamp;
}
```

### `/obras/{obraId}`
```typescript
interface Obra {
  id: string;
  nombre: string;
  etapa: "Búsqueda Local" | "Firma Contrato" | "Obra Civil" | "Equipamiento" | "Inauguración";
  color: string;
  fechaInicio: Timestamp | null;
  fechaEstimadaApertura: Timestamp | null;
  equipamiento: {
    [itemId: string]: {
      origen: "deposito" | "comprar" | null;
      done: boolean;
      fechaLimite: Timestamp | null;
      observaciones: string;
      cantDisponible: number;
    }
  };
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

### `/proyectos/{proyectoId}`
```typescript
interface Proyecto {
  id: string;
  ownerId: string;           // userId del owner (directora)
  ownerNombre: string;
  ownerArea: string;
  nombre: string;
  fechaLimite: Timestamp | null;
  prioridad: "alta" | "media" | "baja";
  comentarios: string;       // puede tener múltiples entradas separadas por \n\n
  tareas: Tarea[];
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

interface Tarea {
  id: string;
  texto: string;
  done: boolean;
  completadaAt: Timestamp | null;
  completadaPor: string | null;
}
```

### `/stock/{itemId}`
```typescript
interface StockItem {
  id: string;
  nombre: string;
  cantidad: number;
  estado: "disponible" | "en_uso" | "daniado";
  observaciones: string;
  localAsignado: string | null;
  updatedAt: Timestamp;
  updatedPor: string;        // userId
}
```

### `/inversores/{inversorId}`
```typescript
interface Inversor {
  id: string;
  userId: string;            // El usuario con perfil "inversor"
  nombre: string;
  local: string;
  porcentaje: number;        // Ej: 30 = 30%
  tipo: "societario";
  proximo_retiro: {
    fecha: Timestamp | null;
    metodo: "transferencia" | "presencial" | null;
    montoEstimado: number;
  };
}
```

### `/informes/{informeId}`
```typescript
interface Informe {
  id: string;
  inversorId: string;
  mes: string;               // Ej: "Marzo 2026"
  fechaEnvio: Timestamp;
  facturacion: number;
  gastos: number;
  resultado: number;         // facturacion - gastos
  ocupacion: number;         // porcentaje
  ticketPromedio: number;
  servicios: number;
  observaciones: string;
  dividendo: number;         // resultado * (porcentaje / 100)
  estadoDividendo: "pendiente" | "coordinando" | "pagado";
  fechaPago: Timestamp | null;
  metodo: "transferencia" | "presencial" | null;
}
```

### `/unos/{unoId}` (Registros 1:1 Plan de Carrera)
```typescript
interface UnoUno {
  id: string;
  targetUserId: string;      // La persona evaluada
  editorUserId: string;      // Quien registra el 1:1
  fecha: Timestamp;
  proximoUno: Timestamp | null;
  desempeno: 1 | 2 | 3 | 4 | 5;
  notas: string;
  planMejora: string;
  objetivos: string[];
  estado: "completado";
}
```

### `/rewards_balance/{userId}`
```typescript
interface RewardsBalance {
  userId: string;
  destellos: number;         // Total acumulado
  destellosMes: number;      // Del mes actual
  historial: {
    mes: string;
    cantidad: number;
  }[];
}
```

---

## REGLAS DE FIRESTORE (Security Rules)

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function getUserData() {
      return get(/databases/$(database)/documents/users/$(request.auth.uid)).data;
    }
    
    function isCasaMatriz() {
      return isAuthenticated() && getUserData().perfil == 'casa_matriz';
    }
    
    function isInversor() {
      return isAuthenticated() && getUserData().perfil == 'inversor';
    }
    
    function userLocal() {
      return getUserData().local;
    }

    // Users — solo el propio y CM pueden leer
    match /users/{userId} {
      allow read: if isAuthenticated() && (request.auth.uid == userId || isCasaMatriz());
      allow write: if request.auth.uid == userId || isCasaMatriz();
    }
    
    // Mensajes — cualquier perfil con acceso puede leer y crear
    match /mensajes/{mensajeId} {
      allow read: if isAuthenticated();
      allow create: if isAuthenticated();
      allow update: if isCasaMatriz();  // solo CM puede fijar
    }
    
    // Ideas — todos pueden leer y crear; solo CM puede cambiar estado
    match /ideas/{ideaId} {
      allow read: if isAuthenticated();
      allow create: if isAuthenticated();
      allow update: if isAuthenticated();  // votos y comentarios cualquiera
    }
    
    // Auditorías — CM crea y lee todo; franquiciada solo lee las de su local
    match /auditorias/{auditoriaId} {
      allow read: if isCasaMatriz() || 
                     (isAuthenticated() && resource.data.local == userLocal());
      allow write: if isCasaMatriz();
    }
    
    // Inversores — CM todo; Inversor solo lee los propios
    match /inversores/{inversorId} {
      allow read: if isCasaMatriz() || 
                     (isInversor() && resource.data.userId == request.auth.uid);
      allow write: if isCasaMatriz();
    }
    
    match /informes/{informeId} {
      allow read: if isCasaMatriz() || 
                     (isInversor() && get(/databases/$(database)/documents/inversores/$(resource.data.inversorId)).data.userId == request.auth.uid);
      allow write: if isCasaMatriz();
    }
  }
}
```
