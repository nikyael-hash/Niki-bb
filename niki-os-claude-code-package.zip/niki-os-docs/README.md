# NIKI OS — Sistema Operativo Interno de Niki Beauty Bar

## ¿Qué es NIKI OS?

NIKI OS es la aplicación interna de Niki Beauty Bar — una cadena de salones de uñas con sede en Buenos Aires, Argentina, con expansión en Miami, USA. Es un sistema operativo móvil-first que conecta toda la red: casa matriz, franquiciadas, encargadas, manicuras e inversores.

**Stack requerido:** React Native (iOS + Android) o React Web PWA  
**Diseño:** Mobile-first, máximo 430px de ancho  
**Base de datos:** Firebase Firestore (recomendado) o Supabase  
**Auth:** Firebase Auth con email/contraseña  
**IA:** Anthropic Claude API (claude-sonnet-4-20250514) — ya integrada en el cotizador  

---

## Estructura del proyecto

```
niki-os/
├── README.md                    ← Este archivo
├── PRODUCT_SPEC.md              ← Especificación completa del producto
├── DESIGN_SYSTEM.md             ← Colores, tipografía, componentes
├── MODULES.md                   ← Descripción detallada de cada módulo
├── DATA_MODELS.md               ← Esquemas de base de datos
├── PERMISSIONS.md               ← Sistema de permisos por perfil
├── BUSINESS_CONTEXT.md          ← Contexto del negocio Niki BB
└── prototype/
    └── niki-os-final-v1.jsx     ← Prototipo React funcional (fuente de verdad visual)
```

---

## Quick Start para Claude Code

1. Leer `PRODUCT_SPEC.md` primero — contiene TODA la lógica del sistema
2. Leer `DESIGN_SYSTEM.md` — los colores y estilos son exactos y NO deben modificarse
3. El archivo `prototype/niki-os-final-v1.jsx` es el prototipo funcional completo — úsalo como referencia visual y de lógica
4. Implementar módulo por módulo según prioridad en `MODULES.md`

---

## Contacto del proyecto
**Owner:** Nicole Barat — Niki Beauty Bar  
**Contexto:** Nicole no tiene conocimientos técnicos. Todo debe ser deployable sin configuración manual compleja.
