# PRODUCT_SPEC.md — Especificación Completa de NIKI OS

## 1. VISIÓN DEL PRODUCTO

NIKI OS es el sistema operativo interno de Niki Beauty Bar. Conecta en una sola app móvil a todos los actores de la red: casa matriz, franquiciadas, encargadas, manicuras e inversores.

**Posicionamiento:** Luxury nail bar — referencia: Nail'd It Londres (@wenaildit, 187K seguidores, 28 locales globales)  
**Mercado:** Buenos Aires (14 locales) + Miami (expansión 2026)  
**Facturación actual:** $20-25M ARS mensuales

---

## 2. NEGOCIO

### Estructura de la red
- **6 locales propios:** Puerto Madero (flagship), Lomas, Adrogue, Canning, Belgrano, Saavedra
- **Franquicias activas:** Bella Vista, Recoleta, Cañitas, Banfield, Mar del Plata, y más
- **5 obras activas:** Miami, Recoleta II, Ramos Mejía, San Isidro, Caballito
- **Equipo:** ~50+ manicuras en toda la red

### Equipo Casa Matriz
| Nombre | Rol | Área |
|--------|-----|------|
| Nicole Barat | Owner / Casa Matriz | Dirección general |
| Agustina Quaglia | Directora | Marketing |
| Laura Felipetti | Directora | RRHH |
| Bárbara López | Acceso Total | Obras, Stock y Secretaría |
| Lucía Becker | Directora | Stock e insumos |

### Sistema de niveles de manicuras (implementación Junio 2026)
| Nivel | Skill requerido | Comisión |
|-------|----------------|----------|
| Junior | ≤ 60% del menú | 35% |
| Senior | 61-85% del menú | 38% |
| Master | 86-100% del menú | 40% |

El menú tiene 34 servicios totales. El % de skill = servicios que domina / 34.

### Precios del cotizador (Febrero 2026)
| Tipo | Descripción | Estándar Efectivo | Estándar Tarjeta | Premium Efectivo | Premium Tarjeta |
|------|-------------|-------------------|------------------|------------------|-----------------|
| INCLUIDO | Francesita, líneas, baby shine, chromas 1 tono, strass, corazones (2), french 4 uñas | $0 | $0 | $0 | $0 |
| SIMPLE ×2 | Baby boomer esponja/pincel — 1 por mano | $4.500 | $5.200 | $5.500 | $6.000 |
| COMPLEJO | Baby boomer/aura todas las uñas, diseños elaborados | $6.500 | $7.000 | $7.500 | $8.200 |

Locales PREMIUM: Puerto Madero, Recoleta  
Locales ESTÁNDAR: todos los demás

---

## 3. AUTENTICACIÓN Y REGISTRO

### Sistema de login
- **Email + contraseña** (mínimo 6 caracteres)
- NO hay login por nombre de usuario

### Sistema de registro (3 pasos)
1. **Paso 1 — Código de invitación:** La administradora genera un código único que ya tiene el perfil y local asignados. Sin código no se puede registrar.
2. **Paso 2 — Datos personales:** Nombre completo, email, contraseña, repetir contraseña.
3. **Paso 3 — Emoji de avatar:** El usuario elige un emoji de 4 grupos (Caras, Brillos, Flores, Gestos). Este emoji es su avatar en toda la app.

### Códigos de invitación (estructura)
```
Formato: NIKI-[TIPO]-[AÑO]
Ejemplos:
  NIKI-CM-2026    → perfil: casa_matriz,  local: null
  NIKI-FRQ-2026   → perfil: franquiciada, local: "Lomas"
  NIKI-ENC-2026   → perfil: encargada,    local: "Puerto Madero"
  NIKI-MAN-2026   → perfil: manicura,     local: "Adrogue"
  NIKI-INV-2026   → perfil: inversor,     local: null
```
Cada código es de un solo uso. Casa Matriz genera los códigos desde el panel de administración.

---

## 4. PERFILES Y PERMISOS

### Los 5 perfiles del sistema
| Perfil | Color Destello | Descripción |
|--------|---------------|-------------|
| Casa Matriz | Dorado `#CAA150` | Acceso completo — Nicole + directoras + Bárbara |
| Franquiciada | Rosa oscuro `#C4808C` | Dueña de franquicia |
| Encargada | Teal `#7A9E9F` | Encargada de local (propio o franquicia) |
| Manicura | Rosa suave `#DDA4AE` | Manicura del equipo |
| Inversor | Verde inglés `#2E7D5A` | Inversor con participación en locales |

### Permisos por módulo
```
casa_matriz:  comunicaciones, rewards, cotizador, obras, rrhh, auditorias,
              lab, plan_carrera, proyectos, stock, manicuras, skills,
              youtube, blog, inversores, frases

franquiciada: comunicaciones, rewards, cotizador, obras, auditorias,
              lab, youtube, blog, frases

encargada:    comunicaciones, rewards, cotizador, rrhh, lab,
              youtube, blog, frases

manicura:     cotizador, rewards, rrhh, lab, blog, youtube

inversor:     inversores, obras, blog
```

---

## 5. MÓDULOS — RESUMEN

Ver `MODULES.md` para especificación detallada de cada uno.

| ID | Nombre | Estado | Prioridad |
|----|--------|--------|-----------|
| comunicaciones | Comunicaciones | ✅ Funcional | Alta |
| rewards | Niki Rewards | ✅ Funcional | Alta |
| cotizador | Cotizador IA | ✅ Funcional (usa Claude API) | Alta |
| lab | Niki Lab | ✅ Funcional | Alta |
| frases | Frases del Café | ✅ Funcional | Media |
| blog | Stay Tuned | ✅ Funcional | Media |
| auditorias | Auditorías | ✅ Funcional | Alta |
| obras | Obras | ✅ Funcional | Alta |
| rrhh | RRHH & Turnos | ✅ Funcional | Media |
| proyectos | Proyectos CM | ✅ Funcional | Media |
| stock | Stock Depósito | ✅ Funcional | Media |
| plan_carrera | Plan de Carrera | ✅ Funcional | Media |
| inversores | Inversores | ✅ Funcional | Alta |
| manicuras | Solicitud Mani | 🔄 Pendiente | Baja |
| skills | Skills | 🔄 Pendiente | Media |
| youtube | YouTube | 🔄 Link pendiente | Baja |

---

## 6. FLUJO DE NAVEGACIÓN

```
App
├── Login (email + contraseña)
│   └── → Registro (código → datos → emoji)
└── App Principal
    ├── Tab: Inicio
    │   ├── Bienvenida personalizada (emoji + nombre + perfil)
    │   ├── Countdown evento 17/5/2026
    │   ├── Stats (locales, obras, ideas, inversores)
    │   └── Acceso rápido a 6 módulos principales
    ├── Tab: Módulos
    │   └── Grid de todos los módulos (con 🔒 si sin acceso)
    └── Tab: Stay Tuned
        └── Blog con novedades y eventos
```

---

## 7. DISEÑO VISUAL — REGLAS CRÍTICAS

1. **Destello ✦** — El ícono de 4 puntas es la firma de Niki BB. Aparece en login, headers y como decoración. SVG: `M12 2 L13.2 10.8 L22 12 L13.2 13.2 L12 22 L10.8 13.2 L2 12 L10.8 10.8 Z`
2. **Tipografía:** Cormorant Garamond (serif, italic, para títulos) + Lato (sans-serif, para body)
3. **El logo NIKI** — letra spacing de 16px requiere `paddingLeft: 16px` para centrar correctamente
4. **Animaciones del login** — el destello central gira, los flotantes flotan, el glow pulsa. Todo cambia de color según el perfil seleccionado.
5. **Sin nombres en el login** — solo los 5 perfiles como opciones (sin nombres de personas)

Ver `DESIGN_SYSTEM.md` para especificación completa.

---

## 8. INTEGRACIÓN CON CLAUDE API

El cotizador de nail art usa la API de Anthropic directamente:

```javascript
// Endpoint
POST https://api.anthropic.com/v1/messages

// Modelo
claude-sonnet-4-20250514

// Flujo
1. Usuario sube foto del diseño de uñas
2. Usuario selecciona: tipo de local (estándar/premium) + forma de pago (efectivo/tarjeta)  
3. La imagen se envía en base64 junto con un prompt que incluye la tabla de precios
4. Claude devuelve JSON con: nivel (incluido/simple/complejo), precio, diseño detectado, justificación, elementos, tip

// Formato de respuesta esperado
{
  "nivel": "incluido" | "simple" | "complejo",
  "precio": number,
  "diseno": "descripción breve",
  "justificacion": "1-2 oraciones",
  "elementos": ["elemento1", "elemento2"],
  "tip": "consejo profesional"
}
```

**IMPORTANTE:** La API key se maneja del lado del servidor (nunca expuesta en el frontend).

---

## 9. EVENTO IMPORTANTE

**17 de Mayo de 2026** — Evento presencial de Niki Beauty Bar  
Link: https://nikibeautybar.my.canva.site/  
El countdown a este evento aparece en la pantalla de inicio y en Stay Tuned.
