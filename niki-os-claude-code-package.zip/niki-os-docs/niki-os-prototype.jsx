import { useState, useEffect, useRef } from "react";

// ─── COLORES ──────────────────────────────────────────────────────────────────
const B = {
  pink:"#DDA4AE", pinkLight:"#F2D6DA", pinkDeep:"#C4808C",
  pinkBg:"#FDF5F6", gold:"#A67A2E", goldLight:"#CAA150",
  goldPale:"#F5EDD8", white:"#FFFFFF", coolGray:"#F1F1F2",
  glacier:"#D0D2D3", mid:"#7A6A6C", text:"#3D2B2D",
  green:"#5A9E6E", greenPale:"#EBF5EE",
  red:"#C0392B", redPale:"#FDECEA",
  teal:"#7A9E9F", tealPale:"#EBF5F5",
  orange:"#E07A30", orangePale:"#FEF0E4",
  purple:"#9B8EA6", purplePale:"#F0EDF5",
  englishGreen:"#2E7D5A", englishGreenPale:"#E8F5EE",
};

// ─── PERFILES Y PERMISOS ──────────────────────────────────────────────────────
const PERFILES = {
  casa_matriz:  { label:"Casa Matriz",  color:"#CAA150", glow:"rgba(202,161,80,0.4)"  },
  franquiciada: { label:"Franquiciada", color:"#C4808C", glow:"rgba(196,128,140,0.4)" },
  encargada:    { label:"Encargada",    color:"#7A9E9F", glow:"rgba(122,158,159,0.4)" },
  manicura:     { label:"Manicura",     color:"#DDA4AE", glow:"rgba(221,164,174,0.4)" },
  inversor:     { label:"Inversor",     color:"#2E7D5A", glow:"rgba(46,125,90,0.4)"  },
};

const PERMISOS = {
  casa_matriz:  ["comunicaciones","rewards","cotizador","obras","rrhh","auditorias","lab","plan_carrera","proyectos","stock","manicuras","skills","youtube","blog","inversores","frases"],
  franquiciada: ["comunicaciones","rewards","cotizador","obras","auditorias","lab","youtube","blog","frases"],
  encargada:    ["comunicaciones","rewards","cotizador","rrhh","lab","youtube","blog","frases"],
  manicura:     ["cotizador","rewards","rrhh","lab","blog","youtube"],
  inversor:     ["inversores","obras","blog"],
};

// ─── CÓDIGOS DE INVITACIÓN ────────────────────────────────────────────────────
const CODIGOS = {
  "NIKI-CM-2026":  { perfil:"casa_matriz",  local:null },
  "NIKI-FRQ-2026": { perfil:"franquiciada", local:"Lomas" },
  "NIKI-ENC-2026": { perfil:"encargada",    local:"Puerto Madero" },
  "NIKI-MAN-2026": { perfil:"manicura",     local:"Adrogue" },
  "NIKI-INV-2026": { perfil:"inversor",     local:null },
};

const USUARIOS_INIT = [
  { id:"n1", nombre:"Nicole Barat",     email:"nicole@nikibb.com",  pass:"nicole123",  perfil:"casa_matriz",  local:null,            emoji:"👑" },
  { id:"n2", nombre:"Agustina Quaglia", email:"agus@nikibb.com",    pass:"agus123",    perfil:"casa_matriz",  local:null,            emoji:"🌸" },
  { id:"n3", nombre:"Laura Felipetti",  email:"laura@nikibb.com",   pass:"laura123",   perfil:"casa_matriz",  local:null,            emoji:"⭐" },
  { id:"n4", nombre:"Bárbara López",    email:"barbara@nikibb.com", pass:"barba123",   perfil:"casa_matriz",  local:null,            emoji:"💎" },
  { id:"n5", nombre:"Estefanía Soto",   email:"este@nikibb.com",    pass:"este123",    perfil:"manicura",     local:"Adrogue",       emoji:"💅" },
  { id:"n6", nombre:"Bárbara Ortiz",    email:"bartiz@nikibb.com",  pass:"ortiz123",   perfil:"encargada",    local:"Lomas",         emoji:"🌟" },
  { id:"n7", nombre:"Inv. Lomas",       email:"inv@nikibb.com",     pass:"inv123",     perfil:"inversor",     local:null,            emoji:"💰" },
];

// ─── EMOJIS ───────────────────────────────────────────────────────────────────
const EMOJI_GRUPOS = [
  { label:"Caras",    items:["😊","😎","🥰","😏","🤩","😌","🥳","😇","🤗","😄","🌸","✨"] },
  { label:"Brillos",  items:["✨","💫","⭐","🌟","💎","👑","🏆","🎀","💅","💄","🔮","🦄"] },
  { label:"Flores",   items:["🌸","🌺","🌹","🌷","💐","🌻","🌼","🍀","🌿","🦋","🌙","🌈"] },
  { label:"Gestos",   items:["💅","🙌","👏","🤌","💪","🫶","❤️","🩷","🤍","🖤","💜","💛"] },
];

// ─── DATOS MÓDULOS ────────────────────────────────────────────────────────────
const PRECIOS_NAILART = {
  incluido: { label:"INCLUIDO", color:B.green,  pts:0,   desc:"Sin costo adicional",
    items:["Francesita / líneas / puntos","Baby shine","Chromas (1 tono)","Papel oro en líneas","Strass y caviar","Corazones / estrellas (2 total)","French con diseño (4 uñas)"],
    estandar:{efectivo:0,tarjeta:0}, premium:{efectivo:0,tarjeta:0} },
  simple:   { label:"SIMPLE ×2", color:B.pink,  pts:1,   desc:"Un diseño por mano",
    items:["Baby boomer (esponja o pincel)","Baby boomer + brillo"],
    estandar:{efectivo:4500,tarjeta:5200}, premium:{efectivo:5500,tarjeta:6000} },
  complejo: { label:"COMPLEJO",  color:B.gold,  pts:2,   desc:"Diseño en todas las uñas",
    items:["Baby boomer todas las uñas","Aura todas las uñas","Diseños elaborados"],
    estandar:{efectivo:6500,tarjeta:7000}, premium:{efectivo:7500,tarjeta:8200} },
};

const CATS_LAB = [
  { id:"colores",     label:"Colores",     emoji:"🎨", color:B.pink   },
  { id:"productos",   label:"Productos",   emoji:"💅", color:B.gold   },
  { id:"proyectos",   label:"Proyectos",   emoji:"🚀", color:B.teal   },
  { id:"servicios",   label:"Servicios",   emoji:"✨", color:B.purple },
  { id:"operaciones", label:"Operaciones", emoji:"⚙️", color:B.green  },
];
const ESTADOS_LAB = {
  nueva:     { label:"Nueva",       color:B.mid,   bg:B.coolGray, icon:"💡" },
  analisis:  { label:"En análisis", color:B.gold,  bg:B.goldPale, icon:"🔍" },
  aprobada:  { label:"Aprobada",    color:B.green, bg:B.greenPale,icon:"✅" },
  descartada:{ label:"Descartada",  color:B.red,   bg:B.redPale,  icon:"✕"  },
};
const IDEAS_INIT = [
  { id:"i1", perfil:"manicura",     titulo:"Línea de esmaltes nude para invierno ✨",       categoria:"colores",    estado:"analisis",  votos:{"casa_matriz":1,"franquiciada":1,"encargada":1,"manicura":0,"inversor":0}, comentarios:[{perfil:"encargada",texto:"Lo más pedido en el local.",fecha:"18 Abr"}], fecha:"15 Abr" },
  { id:"i2", perfil:"franquiciada", titulo:"Ritual exprés 30 min para el lunch break ✨",   categoria:"servicios",  estado:"nueva",     votos:{"casa_matriz":0,"franquiciada":0,"encargada":1,"manicura":1,"inversor":0}, comentarios:[], fecha:"16 Abr" },
  { id:"i3", perfil:"encargada",    titulo:"App de fidelización para clientas ✨",          categoria:"proyectos",  estado:"analisis",  votos:{"casa_matriz":1,"franquiciada":1,"encargada":0,"manicura":1,"inversor":1}, comentarios:[], fecha:"14 Abr" },
  { id:"i4", perfil:"franquiciada", titulo:"Capacitación mensual en video ✨",              categoria:"operaciones",estado:"aprobada",  votos:{"casa_matriz":1,"franquiciada":1,"encargada":1,"manicura":1,"inversor":0}, comentarios:[{perfil:"casa_matriz",texto:"Aprobado. Empieza en Mayo.",fecha:"18 Abr"}], fecha:"12 Abr" },
];

const DESTELLOS_REWARDS = [
  { d:30,   p:30000,   premio:"Efectivo",                              emoji:"💰" },
  { d:200,  p:200000,  premio:"Merchandising Niki BB",                 emoji:"🎀" },
  { d:350,  p:350000,  premio:"Vaso Stanley",                          emoji:"🥤" },
  { d:500,  p:500000,  premio:"Set Victoria's Secret + Cena para dos", emoji:"🌹" },
  { d:650,  p:650000,  premio:"Voucher $200.000 (spa/ropa/peluq.)",    emoji:"💅" },
  { d:800,  p:800000,  premio:"Lapicera Swarovski",                    emoji:"💎" },
  { d:900,  p:900000,  premio:"Cabina de manicura + Aros Swarovski",   emoji:"💍" },
  { d:1000, p:1000000, premio:"Tablet",                                emoji:"📱" },
  { d:1200, p:1200000, premio:"Cartera Guess",                         emoji:"👜" },
  { d:2000, p:2000000, premio:"iPad",                                  emoji:"💻" },
  { d:2500, p:2500000, premio:"Viaje a Mar del Plata",                 emoji:"🌊" },
  { d:40000,p:4000000, premio:"Viaje a Brasil ✈️",                    emoji:"✈️" },
];

const REWARDS_PERSONAS = [
  { id:"r1", nombre:"Estefanía Soto",  local:"Adrogue",       destellos:340, mes:120, historial:[80,100,120,40] },
  { id:"r2", nombre:"Candela Amaya",   local:"Puerto Madero", destellos:280, mes:100, historial:[60,80,100,40] },
  { id:"r3", nombre:"Sol Martínez",    local:"Lomas",         destellos:190, mes:80,  historial:[40,40,80,30]  },
  { id:"r4", nombre:"Bárbara Ortiz",   local:"Lomas",         destellos:420, mes:200, historial:[80,100,200,40]},
];

const BLOG_POSTS = [
  { id:1, titulo:"Evento Niki Beauty Bar ✨", sub:"17 de Mayo — Encuentro presencial",   fecha:"17 MAY 2026", color:B.pink, emoji:"🎀", tag:"PRÓXIMO EVENTO",  link:"https://nikibeautybar.my.canva.site/", cta:"VER EVENTO", countdown:true },
  { id:2, titulo:"Niki Lab ya está activo 🧪",sub:"Proponé ideas, votá y participá",      fecha:"21 ABR 2026", color:B.green,emoji:"🧪", tag:"NUEVO MÓDULO",    link:null, cta:"IR AL LAB" },
  { id:3, titulo:"NIKI OS v1.0 lanzado ✨",   sub:"Toda la red conectada",               fecha:"21 ABR 2026", color:B.gold, emoji:"◆", tag:"LANZAMIENTO",     link:null, cta:"EXPLORAR"  },
  { id:4, titulo:"Junior → Senior → Master ✨",sub:"Sistema de niveles desde Junio 2026",fecha:"JUN 2026",    color:B.teal, emoji:"⭐",tag:"PRÓXIMAMENTE",    link:null, cta:"VER SKILL" },
  { id:5, titulo:"5 Obras en marcha ✨",       sub:"Miami, Recoleta II, Ramos Mejía...", fecha:"ABR 2026",    color:B.teal, emoji:"🏗️",tag:"EXPANSIÓN",       link:null, cta:"VER OBRAS" },
];

const MODULES_LIST = [
  { id:"comunicaciones", emoji:"💬", label:"Comunicaciones",  color:B.pink,   desc:"Canal interno" },
  { id:"rewards",        emoji:"✨", label:"Niki Rewards",    color:"#CAA150",desc:"Destellos" },
  { id:"cotizador",      emoji:"💅", label:"Cotizador IA",    color:B.pinkDeep,desc:"Nail art → precio" },
  { id:"obras",          emoji:"🏗️", label:"Obras",          color:B.teal,   desc:"Aperturas" },
  { id:"rrhh",           emoji:"👥", label:"RRHH & Turnos",  color:B.purple, desc:"Vacantes" },
  { id:"auditorias",     emoji:"📋", label:"Auditorías",      color:"#CAA150",desc:"Misterioso Shopper" },
  { id:"lab",            emoji:"🧪", label:"Niki Lab",        color:B.green,  desc:"Ideas del equipo" },
  { id:"frases",         emoji:"☕", label:"Frases del Café", color:B.pinkDeep,desc:"Para compartir con clientas" },
  { id:"plan_carrera",   emoji:"🌱", label:"Plan de Carrera", color:B.pink,   desc:"1:1 y crecimiento" },
  { id:"proyectos",      emoji:"📁", label:"Proyectos CM",    color:"#CAA150",desc:"Gestión directoras" },
  { id:"stock",          emoji:"📦", label:"Stock Depósito",  color:B.teal,   desc:"Inventario obras" },
  { id:"inversores",     emoji:"💰", label:"Inversores",      color:B.purple, desc:"Informes y dividendos" },
  { id:"manicuras",      emoji:"🤝", label:"Solicitud Mani",  color:B.pinkDeep,desc:"Pedí por nivel" },
  { id:"skills",         emoji:"📊", label:"Skills",          color:"#CAA150",desc:"Junior → Master" },
  { id:"youtube",        emoji:"▶️", label:"YouTube",         color:B.pinkDeep,desc:"Canal oficial" },
  { id:"blog",           emoji:"✨", label:"Stay Tuned",      color:"#CAA150",desc:"Novedades" },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function useCountdown(d) {
  const [t,setT]=useState({});
  useEffect(()=>{
    const c=()=>{const diff=new Date(d)-new Date();if(diff<=0)return setT({expired:true});setT({dias:Math.floor(diff/864e5),horas:Math.floor((diff%864e5)/36e5),min:Math.floor((diff%36e5)/6e4),seg:Math.floor((diff%6e4)/1e3)});};
    c();const id=setInterval(c,1000);return()=>clearInterval(id);
  },[d]);
  return t;
}

const Destello=({size=16,color="#CAA150",style={}})=>(
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color} style={style}>
    <path d="M12 2 L13.2 10.8 L22 12 L13.2 13.2 L12 22 L10.8 13.2 L2 12 L10.8 10.8 Z"/>
  </svg>
);

const PatternBg=({opacity=0.05,id="pp"})=>(
  <svg style={{position:"absolute",inset:0,width:"100%",height:"100%",opacity,pointerEvents:"none"}}>
    <defs><pattern id={id} x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
      <circle cx="20" cy="20" r="18" fill="none" stroke={B.gold} strokeWidth="0.6"/>
      <circle cx="0" cy="0" r="18" fill="none" stroke={B.gold} strokeWidth="0.6"/>
      <circle cx="40" cy="0" r="18" fill="none" stroke={B.gold} strokeWidth="0.6"/>
      <circle cx="0" cy="40" r="18" fill="none" stroke={B.gold} strokeWidth="0.6"/>
      <circle cx="40" cy="40" r="18" fill="none" stroke={B.gold} strokeWidth="0.6"/>
    </pattern></defs>
    <rect width="100%" height="100%" fill={`url(#${id})`}/>
  </svg>
);

const Bubble=({emoji,color,size=40})=>(
  <div style={{width:size,height:size,borderRadius:"50%",background:`${color}18`,border:`2px solid ${color}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*.44,flexShrink:0}}>
    {emoji}
  </div>
);

const fmt=n=>`$${Number(n).toLocaleString("es-AR")}`;
const Star=({size=12,color="#CAA150"})=>(
  <svg width={size} height={size} viewBox="0 0 24 24" fill={color}>
    <path d="M12 2L13.5 10L22 12L13.5 14L12 22L10.5 14L2 12L10.5 10Z"/>
  </svg>
);


const CSS=`
  @import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300&display=swap');
  *{box-sizing:border-box;margin:0;padding:0;}
  ::-webkit-scrollbar{width:3px;}::-webkit-scrollbar-thumb{background:#F2D6DA;}
  @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
  @keyframes shimmer{0%,100%{opacity:.5}50%{opacity:1}}
  @keyframes softPulse{0%,100%{opacity:1}50%{opacity:.6}}
  @keyframes destelloSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
  @keyframes destelloFloat{0%,100%{transform:translateY(0);opacity:.6}50%{transform:translateY(-7px) rotate(15deg);opacity:1}}
  @keyframes destelloPulse{0%,100%{opacity:.35;transform:scale(.85)}50%{opacity:1;transform:scale(1.1)}}
  @keyframes glowPulse{0%,100%{filter:blur(55px);opacity:.25}50%{filter:blur(70px);opacity:.5}}
  @keyframes ticker{from{transform:translateX(100%)}to{transform:translateX(-100%)}}
  @keyframes spin{to{transform:rotate(360deg)}}
  button{cursor:pointer;border:none;font-family:inherit;}
  input,textarea,select{font-family:inherit;outline:none;}
  .card:active{transform:scale(.98);}
`;

// ─── MÓDULO COMUNICACIONES ────────────────────────────────────────────────────
const MSGS_INIT = [
  { id:"m1", perfil:"casa_matriz", emoji:"👑", nombre:"Nicole Barat",    cat:"urgente",    texto:"Recordatorio: el evento del 17 de Mayo requiere confirmación de asistencia antes del 10/5.", fecha:"Hoy 9:00",   fijado:true,  reacciones:{like:4,love:2,star:1} },
  { id:"m2", perfil:"casa_matriz", emoji:"🌸", nombre:"Agustina",        cat:"marketing",  texto:"Campaña de Mayo lista para revisión. Incluye reels del evento y contenido para Stories. Revisamos mañana a las 11.", fecha:"Hoy 8:30",   fijado:false, reacciones:{like:3,love:1,star:0} },
  { id:"m3", perfil:"encargada",   emoji:"🌟", nombre:"Bárbara Ortiz",   cat:"operaciones",texto:"Lomas: semana con 100% de ocupación. 8 servicios de kapping complejo. Sin reclamos registrados.", fecha:"Ayer 18:00", fijado:false, reacciones:{like:5,love:3,star:2} },
  { id:"m4", perfil:"casa_matriz", emoji:"⭐", nombre:"Laura Felipetti", cat:"rrhh",       texto:"Ingresan 3 manicuras nuevas la semana que viene: Yasmin (Puerto Madero), Ángeles (Lomas), Abril (Recoleta).", fecha:"Ayer 14:00", fijado:false, reacciones:{like:2,love:4,star:1} },
  { id:"m5", perfil:"franquiciada",emoji:"💜", nombre:"Franquiciada Cañitas",cat:"operaciones",texto:"Consulta: ¿cómo solicito la reposición de insumos antes del feriado? ¿Hay stock disponible?",fecha:"Lun 11:00", fijado:false, reacciones:{like:0,love:0,star:0} },
];
const CAT_CONFIG = {
  urgente:    { color:B.red,    bg:B.redPale,    label:"Urgente"      },
  operaciones:{ color:B.teal,   bg:B.tealPale,   label:"Operaciones"  },
  capacitacion:{ color:B.purple,bg:B.purplePale, label:"Capacitación" },
  marketing:  { color:B.pink,   bg:B.pinkLight,  label:"Marketing"    },
  rrhh:       { color:"#CAA150",bg:B.goldPale,   label:"RRHH"         },
};

function ModComunicaciones({user,onBack}){
  const [msgs,setMsgs]=useState(MSGS_INIT);
  const [draft,setDraft]=useState("");
  const [cat,setCat]=useState("operaciones");
  const isCM=user.perfil==="casa_matriz";
  const reaccionar=(id,tipo)=>setMsgs(p=>p.map(m=>m.id!==id?m:{...m,reacciones:{...m.reacciones,[tipo]:(m.reacciones[tipo]||0)+1}}));
  const publicar=()=>{if(!draft.trim())return;setMsgs(p=>[{id:`m_${Date.now()}`,perfil:user.perfil,emoji:user.emoji,nombre:user.nombre,cat,texto:draft.trim(),fecha:"Ahora",fijado:false,reacciones:{like:0,love:0,star:0}},...p]);setDraft("");};
  const fijados=msgs.filter(m=>m.fijado);
  const normales=msgs.filter(m=>!m.fijado);
  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <div style={{background:B.white,padding:"13px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.08)",display:"flex",alignItems:"center",gap:10}}>
        <button onClick={onBack} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>← OS</button>
        <div style={{flex:1}}>
          <div style={{fontSize:13,fontWeight:700,color:B.text}}>💬 Comunicaciones</div>
          <div style={{fontSize:8,color:B.mid}}>Canal interno Niki BB</div>
        </div>
      </div>
      <div style={{padding:"12px 14px 100px"}}>
        {fijados.length>0&&<div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>📌 FIJADOS</div>}
        {[...fijados,...normales].map((m,i)=>{
          const cat=CAT_CONFIG[m.cat]||CAT_CONFIG.operaciones;
          return(
            <div key={m.id} style={{background:m.fijado?B.goldPale:B.white,borderRadius:12,marginBottom:8,padding:"13px 14px",border:`1px solid ${m.fijado?B.goldLight+"50":B.pinkLight}`,animation:`fadeUp .25s ease ${i*.03}s both`}}>
              <div style={{display:"flex",gap:9,alignItems:"flex-start",marginBottom:8}}>
                <Bubble emoji={m.emoji} color={PERFILES[m.perfil]?.color||B.pink} size={34}/>
                <div style={{flex:1}}>
                  <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:3,flexWrap:"wrap"}}>
                    <div style={{fontSize:10,fontWeight:700,color:B.text}}>{m.nombre}</div>
                    <div style={{padding:"1px 7px",borderRadius:20,background:cat.bg,border:`1px solid ${cat.color}40`,fontSize:7,color:cat.color,fontWeight:700}}>{cat.label}</div>
                    {m.fijado&&<div style={{fontSize:7,color:"#CAA150",fontWeight:700}}>📌</div>}
                  </div>
                  <div style={{fontSize:9,color:B.mid}}>{m.fecha}</div>
                </div>
              </div>
              <div style={{fontSize:12,color:B.text,lineHeight:1.6,marginBottom:8}}>{m.texto}</div>
              <div style={{display:"flex",gap:7}}>
                {[["like","👍",m.reacciones.like],["love","💖",m.reacciones.love],["star","⭐",m.reacciones.star]].map(([tipo,ic,cnt])=>(
                  <button key={tipo} onClick={()=>reaccionar(m.id,tipo)} style={{display:"flex",alignItems:"center",gap:3,padding:"3px 9px",background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:20,fontSize:9,color:B.mid}}>
                    {ic} {cnt||""}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,padding:"10px 14px 22px",background:B.white,borderTop:`1px solid ${B.pinkLight}`,boxShadow:"0 -2px 12px rgba(221,164,174,0.08)"}}>
        <div style={{display:"flex",gap:5,marginBottom:8,overflowX:"auto",scrollbarWidth:"none"}}>
          {Object.entries(CAT_CONFIG).map(([k,v])=>(
            <button key={k} onClick={()=>setCat(k)} style={{padding:"3px 10px",borderRadius:20,fontSize:7,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:cat===k?v.color:B.white,color:cat===k?B.white:B.mid,border:`1px solid ${cat===k?v.color:B.glacier}`,transition:"all .2s"}}>{v.label}</button>
          ))}
        </div>
        <div style={{display:"flex",gap:8}}>
          <Bubble emoji={user.emoji} color={PERFILES[user.perfil]?.color||B.pink} size={34}/>
          <input value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>e.key==="Enter"&&publicar()} placeholder="Escribí tu mensaje..." style={{flex:1,padding:"9px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,background:B.pinkBg}}/>
          <button onClick={publicar} style={{padding:"9px 14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:9,color:B.white,fontSize:13,fontWeight:700}}>↑</button>
        </div>
      </div>
    </div>
  );
}

// ─── MÓDULO REWARDS ───────────────────────────────────────────────────────────
function ModRewards({user,onBack}){
  const [tab,setTab]=useState("ranking");
  const [catFilter,setCatFilter]=useState("all");
  const cats=["all","efectivo","merch","regalo","experiencia","luxury","tech","viaje"];
  const CATS_ITEMS={
    efectivo:[0],merch:[1],regalo:[2,3],experiencia:[4],luxury:[5,6],tech:[7,8,9],viaje:[10,11]
  };
  const filtrados=catFilter==="all"?DESTELLOS_REWARDS:DESTELLOS_REWARDS.filter((_,i)=>(CATS_ITEMS[catFilter]||[]).includes(i));
  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <div style={{background:B.white,padding:"0 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.08)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10,padding:"13px 0 10px"}}>
          <button onClick={onBack} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>← OS</button>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:700,color:B.text}}>✨ Niki Rewards</div>
            <div style={{fontSize:8,color:B.mid}}>1 Destello = $1.000</div>
          </div>
        </div>
        <div style={{display:"flex",borderTop:`1px solid ${B.coolGray}`}}>
          {[{id:"ranking",l:"Ranking"},{id:"catalogo",l:"Catálogo"}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"8px 0 10px",background:"transparent",borderBottom:`2.5px solid ${tab===t.id?B.gold:"transparent"}`,color:tab===t.id?"#CAA150":B.mid,fontSize:9,fontWeight:tab===t.id?700:400,letterSpacing:.5,transition:"all .2s"}}>{t.l.toUpperCase()}</button>
          ))}
        </div>
      </div>
      {tab==="ranking"&&(
        <div style={{padding:"14px 14px 40px"}}>
          {/* Hero */}
          <div style={{background:`linear-gradient(135deg,#1a1008,#2A1A06)`,borderRadius:14,padding:"18px",marginBottom:14,position:"relative",overflow:"hidden",border:"1px solid rgba(202,161,80,0.2)"}}>
            <PatternBg opacity={0.08} id="rew-p"/>
            <div style={{position:"relative",display:"flex",gap:10,alignItems:"center",justifyContent:"space-between"}}>
              <div>
                <div style={{fontSize:8,color:"rgba(255,255,255,0.4)",letterSpacing:2,marginBottom:4}}>TUS DESTELLOS</div>
                <div style={{fontFamily:"Georgia,serif",fontSize:32,color:"#CAA150",fontWeight:300,lineHeight:1}}>—</div>
                <div style={{fontSize:9,color:"rgba(255,255,255,0.4)",marginTop:2}}>Iniciá sesión para ver tus destellos</div>
              </div>
              <Destello size={40} color="#CAA150" style={{opacity:.6,animation:"destelloSpin 8s linear infinite"}}/>
            </div>
          </div>
          {/* Ranking */}
          <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:10}}>RANKING DE DESTELLOS ✨</div>
          {[...REWARDS_PERSONAS].sort((a,b)=>b.destellos-a.destellos).map((r,i)=>{
            const next=DESTELLOS_REWARDS.find(c=>c.d>r.destellos);
            const pct=next?Math.min((r.destellos/next.d)*100,100):100;
            return(
              <div key={r.id} style={{background:B.white,borderRadius:12,marginBottom:8,border:`1px solid ${B.pinkLight}`,padding:"13px 14px",animation:`fadeUp .25s ease ${i*.05}s both`,boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
                <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:8}}>
                  <div style={{width:36,height:36,borderRadius:"50%",background:`${"#CAA150"}15`,border:`1.5px solid ${"#CAA150"}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>{i===0?"🥇":i===1?"🥈":i===2?"🥉":"✨"}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:12,fontWeight:700,color:B.text,marginBottom:2}}>{r.nombre}</div>
                    <div style={{fontSize:9,color:B.mid}}>📍 {r.local} · +{r.mes} este mes</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontFamily:"Georgia,serif",fontSize:22,color:"#CAA150",fontWeight:300,lineHeight:1}}>{r.destellos}</div>
                    <div style={{fontSize:7,color:B.mid}}>destellos</div>
                  </div>
                </div>
                {next&&(<>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}>
                    <div style={{fontSize:8,color:B.mid}}>Próximo: {next.emoji} {next.premio.substring(0,22)}...</div>
                    <div style={{fontSize:8,color:"#CAA150",fontWeight:700}}>{r.destellos}/{next.d}</div>
                  </div>
                  <div style={{height:5,background:B.coolGray,borderRadius:2,overflow:"hidden"}}>
                    <div style={{width:`${pct}%`,height:"100%",background:`linear-gradient(90deg,${"#CAA150"}80,${"#CAA150"})`,borderRadius:2}}/>
                  </div>
                </>)}
              </div>
            );
          })}
        </div>
      )}
      {tab==="catalogo"&&(
        <div style={{padding:"14px 14px 40px"}}>
          <div style={{display:"flex",gap:5,overflowX:"auto",scrollbarWidth:"none",marginBottom:14}}>
            {cats.map(c=>(
              <button key={c} onClick={()=>setCatFilter(c)} style={{padding:"5px 11px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:catFilter===c?B.text:B.white,color:catFilter===c?B.white:B.mid,border:`1px solid ${catFilter===c?B.text:B.glacier}`,transition:"all .2s"}}>{c==="all"?"TODOS":c.toUpperCase()}</button>
            ))}
          </div>
          {filtrados.map((p,i)=>(
            <div key={i} style={{background:B.white,borderRadius:10,marginBottom:7,padding:"12px 14px",border:`1px solid ${B.pinkLight}`,display:"flex",gap:12,alignItems:"center",animation:`fadeUp .2s ease ${i*.02}s both`}}>
              <div style={{width:44,height:44,borderRadius:10,background:`${"#CAA150"}15`,border:`1px solid ${"#CAA150"}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>{p.emoji}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:11,fontWeight:700,color:B.text,lineHeight:1.3,marginBottom:3}}>{p.premio}</div>
                <div style={{fontSize:9,color:B.mid}}>{fmt(p.p)}</div>
              </div>
              <div style={{textAlign:"right",flexShrink:0}}>
                <div style={{fontFamily:"Georgia,serif",fontSize:18,color:"#CAA150",fontWeight:300,lineHeight:1}}>{p.d.toLocaleString()}</div>
                <div style={{fontSize:7,color:B.mid}}>destellos</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── MÓDULO COTIZADOR ─────────────────────────────────────────────────────────
function ModCotizador({user,onBack}){
  const [local,setLocal]=useState(null);
  const [pago,setPago]=useState(null);
  const [image,setImage]=useState(null);
  const [imgB64,setImgB64]=useState(null);
  const [loading,setLoading]=useState(false);
  const [result,setResult]=useState(null);
  const [error,setError]=useState(null);
  const [step,setStep]=useState(1);
  const fileRef=useRef();

  const handleImg=e=>{
    const f=e.target.files[0];if(!f)return;
    setImage(URL.createObjectURL(f));setResult(null);setError(null);
    const r=new FileReader();r.onload=ev=>setImgB64(ev.target.result.split(",")[1]);r.readAsDataURL(f);
  };

  const cotizar=async()=>{
    if(!imgB64||!local||!pago)return;
    setLoading(true);setError(null);setResult(null);
    const lKey=local==="estandar"?"estandar":"premium";
    const prompt=`Sos la asistente de Niki Beauty Bar. Analizá esta imagen de nail art y clasificala:
- INCLUIDO ($0): Francesita, líneas, baby shine, chromas 1 tono, papel oro, strass, flores/corazones (2 total), french 4 uñas
- SIMPLE x2 ($${PRECIOS_NAILART.simple[lKey][pago]}): Baby boomer esponja/pincel, 1 por mano
- COMPLEJO ($${PRECIOS_NAILART.complejo[lKey][pago]}): Baby boomer/aura todas las uñas, diseños elaborados
Local: ${local==="estandar"?"ESTÁNDAR":"PREMIUM"} | Pago: ${pago==="efectivo"?"EFECTIVO":"TARJETA"}
Respondé SOLO JSON: {"nivel":"incluido"|"simple"|"complejo","precio":número,"diseno":"descripción breve","justificacion":"1-2 oraciones","elementos":["el1","el2"],"tip":"consejo profesional"}`;
    try{
      const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:600,messages:[{role:"user",content:[{type:"image",source:{type:"base64",media_type:"image/jpeg",data:imgB64}},{type:"text",text:prompt}]}]})});
      const data=await res.json();
      const parsed=JSON.parse(data.content?.[0]?.text?.replace(/```json|```/g,"").trim()||"{}");
      setResult(parsed);setStep(3);
    }catch(e){setError("No pude analizar la imagen. Intentá con otra foto más clara. 💅");}
    finally{setLoading(false);}
  };

  const reset=()=>{setImage(null);setImgB64(null);setResult(null);setError(null);setStep(1);setLocal(null);setPago(null);};
  const nD=result?PRECIOS_NAILART[result.nivel]:null;

  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <div style={{background:B.white,padding:"13px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.08)",display:"flex",alignItems:"center",gap:10}}>
        <button onClick={onBack} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>← OS</button>
        <div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:B.text}}>💅 Cotizador IA</div><div style={{fontSize:8,color:B.mid}}>Subí foto → precio exacto</div></div>
        <div style={{display:"flex",gap:6}}>
          {[1,2,3].map(s=><div key={s} style={{width:24,height:24,borderRadius:"50%",background:step>=s?B.pink:B.coolGray,border:`2px solid ${step>=s?B.pink:B.glacier}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,fontWeight:700,color:step>=s?B.white:B.mid,transition:"all .3s"}}>{step>s?"✓":s}</div>)}
        </div>
      </div>
      <div style={{padding:"14px",paddingBottom:40}}>
        {step===1&&(
          <div style={{animation:"fadeUp .3s ease forwards"}}>
            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:9}}>TIPO DE LOCAL</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
                {[{k:"estandar",l:"ESTÁNDAR",s:"Lomas · Canning · Adrogue"},{k:"premium",l:"PREMIUM ✦",s:"Puerto Madero · Recoleta"}].map(o=>(
                  <button key={o.k} onClick={()=>setLocal(o.k)} style={{padding:"13px 10px",background:local===o.k?`${B.pink}12`:B.white,border:`2px solid ${local===o.k?B.pink:B.pinkLight}`,borderRadius:11,textAlign:"left",transition:"all .2s"}}>
                    <div style={{fontSize:9,fontWeight:700,color:local===o.k?B.pink:B.text,letterSpacing:1,marginBottom:3}}>{o.l}</div>
                    <div style={{fontSize:8,color:B.mid}}>{o.s}</div>
                  </button>
                ))}
              </div>
            </div>
            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:9}}>FORMA DE PAGO</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
                {[{k:"efectivo",l:"💵 EFECTIVO"},{k:"tarjeta",l:"💳 TARJETA"}].map(o=>(
                  <button key={o.k} onClick={()=>setPago(o.k)} style={{padding:"12px",background:pago===o.k?`${"#CAA150"}12`:B.white,border:`2px solid ${pago===o.k?"#CAA150":B.pinkLight}`,borderRadius:11,fontSize:10,fontWeight:700,color:pago===o.k?"#CAA150":B.mid,transition:"all .2s"}}>{o.l}</button>
                ))}
              </div>
            </div>
            {/* Tabla precios */}
            <div style={{background:B.white,borderRadius:11,border:`1px solid ${B.pinkLight}`,overflow:"hidden",marginBottom:14}}>
              <div style={{padding:"9px 14px",background:B.goldPale,borderBottom:`1px solid ${B.pinkLight}`,fontSize:8,letterSpacing:2,color:"#CAA150",fontWeight:700}}>✦ REFERENCIA DE PRECIOS</div>
              {Object.entries(PRECIOS_NAILART).map(([k,p])=>{
                const precio=local&&pago?p[local==="estandar"?"estandar":"premium"][pago]:null;
                return(
                  <div key={k} style={{padding:"10px 14px",borderBottom:`1px solid ${B.coolGray}`,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                    <div>
                      <div style={{display:"inline-block",padding:"2px 8px",borderRadius:20,background:`${p.color}15`,border:`1px solid ${p.color}40`,fontSize:7,color:p.color,fontWeight:700,letterSpacing:1,marginBottom:2}}>{p.label}</div>
                      <div style={{fontSize:9,color:B.mid}}>{p.desc}</div>
                    </div>
                    <div style={{fontSize:precio!==null?15:11,fontWeight:700,color:k==="incluido"?B.green:B.text,fontFamily:"serif"}}>{precio!==null?(precio===0?"GRATIS":`${fmt(precio)}`):"-"}</div>
                  </div>
                );
              })}
            </div>
            <button onClick={()=>setStep(2)} disabled={!local||!pago} style={{width:"100%",padding:"13px",background:local&&pago?`linear-gradient(135deg,${B.pink},${B.pinkDeep})`:B.glacier,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,transition:"all .3s",boxShadow:local&&pago?`0 5px 16px ${B.pink}30`:"none"}}>
              CONTINUAR →
            </button>
          </div>
        )}
        {step===2&&(
          <div style={{animation:"fadeUp .3s ease forwards"}}>
            <div style={{display:"flex",justifyContent:"center",gap:8,marginBottom:12}}>
              <div style={{padding:"4px 11px",borderRadius:20,background:`${B.pink}15`,border:`1px solid ${B.pink}40`,fontSize:9,color:B.pinkDeep,fontWeight:700}}>{local==="estandar"?"ESTÁNDAR":"✦ PREMIUM"}</div>
              <div style={{padding:"4px 11px",borderRadius:20,background:`${"#CAA150"}15`,border:`1px solid ${"#CAA150"}40`,fontSize:9,color:"#CAA150",fontWeight:700}}>{pago==="efectivo"?"💵 EFECTIVO":"💳 TARJETA"}</div>
            </div>
            <div onClick={()=>fileRef.current?.click()} style={{border:`2px dashed ${image?B.pink:B.glacier}`,borderRadius:13,overflow:"hidden",background:image?"transparent":B.white,cursor:"pointer",marginBottom:12,minHeight:200,display:"flex",alignItems:"center",justifyContent:"center",position:"relative"}}>
              {image?(<><img src={image} alt="nail" style={{width:"100%",maxHeight:280,objectFit:"cover",display:"block"}}/><div style={{position:"absolute",bottom:10,right:10,padding:"4px 11px",background:"rgba(255,255,255,0.92)",borderRadius:20,fontSize:8,color:B.pink,fontWeight:700}}>CAMBIAR FOTO</div></>):(
                <div style={{textAlign:"center",padding:24}}>
                  <div style={{fontSize:38,marginBottom:9}}>💅</div>
                  <div style={{fontSize:12,fontWeight:700,color:B.text,marginBottom:5}}>Subí la foto del diseño</div>
                  <div style={{fontSize:10,color:B.mid,lineHeight:1.5}}>La IA analiza la complejidad<br/>y devuelve el precio exacto</div>
                  <div style={{marginTop:12,padding:"6px 18px",background:B.pinkBg,border:`1px solid ${B.pinkLight}`,borderRadius:20,display:"inline-block",fontSize:9,color:B.pinkDeep,fontWeight:700}}>ELEGIR FOTO</div>
                </div>
              )}
              <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={handleImg} style={{display:"none"}}/>
            </div>
            {error&&<div style={{padding:"9px 12px",background:B.redPale,border:`1px solid ${B.red}30`,borderRadius:8,fontSize:11,color:B.red,marginBottom:10}}>{error}</div>}
            <button onClick={cotizar} disabled={!image||loading} style={{width:"100%",padding:"13px",background:image&&!loading?`linear-gradient(135deg,${"#CAA150"},${"#E8C840"})`:B.glacier,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:10,transition:"all .3s",boxShadow:image&&!loading?`0 5px 16px ${"#CAA150"}30`:"none"}}>
              {loading?<><div style={{width:15,height:15,borderRadius:"50%",border:"2px solid rgba(255,255,255,0.3)",borderTop:"2px solid white",animation:"spin .7s linear infinite"}}/>ANALIZANDO...</>:<><Destello size={10} color={B.white}/>COTIZAR</>}
            </button>
            <button onClick={()=>setStep(1)} style={{width:"100%",marginTop:7,padding:"9px",background:"transparent",color:B.mid,fontSize:10}}>← Volver</button>
          </div>
        )}
        {step===3&&result&&nD&&(
          <div style={{animation:"fadeUp .4s ease forwards"}}>
            <div style={{background:B.white,borderRadius:14,overflow:"hidden",marginBottom:12,border:`2px solid ${nD.color}40`,boxShadow:`0 6px 20px rgba(221,164,174,0.15)`}}>
              {image&&(<div style={{position:"relative"}}><img src={image} alt="" style={{width:"100%",maxHeight:200,objectFit:"cover",display:"block"}}/><div style={{position:"absolute",inset:0,background:"linear-gradient(to bottom,transparent 50%,rgba(42,32,32,0.6)"}}/><div style={{position:"absolute",bottom:10,left:14}}><div style={{padding:"2px 9px",borderRadius:20,background:nD.color,fontSize:8,color:B.white,fontWeight:700,marginBottom:3}}>NAIL ART {nD.label}</div><div style={{fontSize:11,color:B.white,fontWeight:700}}>{result.diseno}</div></div></div>)}
              <div style={{padding:"18px",background:result.nivel==="incluido"?"linear-gradient(135deg,#f0f9f0,#e8f5e8)":`linear-gradient(135deg,${B.pinkBg},${B.goldPale})`,textAlign:"center",position:"relative",overflow:"hidden"}}>
                <PatternBg opacity={0.05} id="cot-r"/>
                <div style={{position:"relative"}}>
                  <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:5}}>PRECIO COTIZADO</div>
                  <div style={{fontFamily:"Georgia,serif",fontSize:result.precio===0?30:44,fontWeight:300,color:result.nivel==="incluido"?B.green:"#CAA150",lineHeight:1,marginBottom:3}}>{result.precio===0?"INCLUIDO":fmt(result.precio)}</div>
                  <div style={{fontSize:9,color:B.mid}}>{local==="estandar"?"Estándar":"Premium"} · {pago==="efectivo"?"Efectivo":"Tarjeta"}</div>
                </div>
              </div>
            </div>
            <div style={{background:B.white,borderRadius:11,padding:"13px",marginBottom:9,border:`1px solid ${B.pinkLight}`}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>¿POR QUÉ ESTE NIVEL?</div>
              <div style={{fontSize:12,color:B.text,lineHeight:1.6}}>{result.justificacion}</div>
            </div>
            {result.elementos?.length>0&&(
              <div style={{background:B.white,borderRadius:11,padding:"13px",marginBottom:9,border:`1px solid ${B.pinkLight}`}}>
                <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>ELEMENTOS DETECTADOS</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{result.elementos.map((el,i)=><div key={i} style={{padding:"3px 9px",background:`${nD.color}12`,border:`1px solid ${nD.color}30`,borderRadius:20,fontSize:10,color:nD.color,fontWeight:700}}>{el}</div>)}</div>
              </div>
            )}
            {result.tip&&(
              <div style={{background:B.goldPale,borderRadius:11,padding:"12px 13px",marginBottom:14,border:`1px solid ${"#CAA150"}30`,display:"flex",gap:9}}>
                <Destello size={12} color="#CAA150" style={{flexShrink:0,marginTop:1}}/>
                <div><div style={{fontSize:8,letterSpacing:1,color:"#CAA150",fontWeight:700,marginBottom:3}}>TIP ✨</div><div style={{fontSize:11,color:B.text,lineHeight:1.5}}>{result.tip}</div></div>
              </div>
            )}
            <button onClick={reset} style={{width:"100%",padding:"13px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:`0 5px 16px ${B.pink}30`}}>
              <Destello size={10} color={B.white}/>COTIZAR OTRO
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── MÓDULO NIKI LAB ──────────────────────────────────────────────────────────
function ModLab({user,onBack}){
  const [ideas,setIdeas]=useState(IDEAS_INIT);
  const [view,setView]=useState("lista");
  const [openId,setOpenId]=useState(null);
  const [filterCat,setFilterCat]=useState("all");
  const [draft,setDraft]=useState({titulo:"",categoria:"colores",descripcion:""});
  const [coment,setComent]=useState("");
  const isCM=user.perfil==="casa_matriz";
  const ideaAbierta=openId?ideas.find(i=>i.id===openId):null;
  const totalV=i=>Object.values(i.votos).reduce((a,b)=>a+b,0);
  const votar=id=>setIdeas(p=>p.map(i=>i.id!==id?i:{...i,votos:{...i.votos,[user.perfil]:i.votos[user.perfil]===1?0:1}}));
  const comentar=id=>{if(!coment.trim())return;setIdeas(p=>p.map(i=>i.id!==id?i:{...i,comentarios:[...i.comentarios,{perfil:user.perfil,emoji:user.emoji,texto:coment.trim(),fecha:"Ahora"}]}));setComent("");};
  const cambiarEstado=(id,est)=>setIdeas(p=>p.map(i=>i.id!==id?i:{...i,estado:est}));
  const publicar=()=>{if(!draft.titulo.trim()||!draft.descripcion.trim())return;setIdeas(p=>[{id:`i_${Date.now()}`,perfil:user.perfil,emoji:user.emoji,...draft,estado:"nueva",votos:{casa_matriz:0,franquiciada:0,encargada:0,manicura:0,inversor:0},comentarios:[],fecha:"Ahora"},...p]);setDraft({titulo:"",categoria:"colores",descripcion:""});setView("lista");};

  if(view==="nueva")return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <div style={{background:B.white,padding:"13px 18px",borderBottom:`1px solid ${B.pinkLight}`,display:"flex",alignItems:"center",gap:10,position:"sticky",top:0,zIndex:100}}>
        <button onClick={()=>setView("lista")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
        <div style={{flex:1,fontSize:13,fontWeight:700,color:B.text}}>Nueva idea 🧪</div>
      </div>
      <div style={{padding:"14px",paddingBottom:90}}>
        <div style={{marginBottom:11}}>
          <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>CATEGORÍA</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:7}}>
            {CATS_LAB.map(c=><button key={c.id} onClick={()=>setDraft(d=>({...d,categoria:c.id}))} style={{padding:"10px 6px",background:draft.categoria===c.id?`${c.color}15`:B.white,border:`2px solid ${draft.categoria===c.id?c.color:B.glacier}`,borderRadius:10,fontSize:9,color:draft.categoria===c.id?c.color:B.mid,fontWeight:700,textAlign:"center",transition:"all .2s"}}><div style={{fontSize:18,marginBottom:3}}>{c.emoji}</div>{c.label}</button>)}
          </div>
        </div>
        <div style={{marginBottom:11}}>
          <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>TÍTULO *</div>
          <input value={draft.titulo} onChange={e=>setDraft(d=>({...d,titulo:e.target.value}))} placeholder="¿De qué se trata?" style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:13,color:B.text,background:B.white}}/>
        </div>
        <div style={{marginBottom:16}}>
          <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>DESCRIPCIÓN *</div>
          <textarea value={draft.descripcion} onChange={e=>setDraft(d=>({...d,descripcion:e.target.value}))} placeholder="Explicá tu idea en detalle..." rows={5} style={{width:"100%",padding:"12px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,lineHeight:1.6,resize:"none",background:B.white}}/>
        </div>
      </div>
      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,padding:"10px 14px 22px",background:B.white,borderTop:`1px solid ${B.pinkLight}`,boxShadow:"0 -2px 12px rgba(221,164,174,0.08)"}}>
        <button onClick={publicar} disabled={!draft.titulo.trim()||!draft.descripcion.trim()} style={{width:"100%",padding:"13px",background:draft.titulo.trim()&&draft.descripcion.trim()?`linear-gradient(135deg,${B.green},${B.green}cc)`:B.glacier,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,transition:"all .3s",display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>🧪 PUBLICAR IDEA</button>
      </div>
    </div>
  );

  if(view==="detalle"&&ideaAbierta){
    const cat=CATS_LAB.find(c=>c.id===ideaAbierta.categoria);
    const est=ESTADOS_LAB[ideaAbierta.estado];
    const yaV=ideaAbierta.votos[user.perfil]===1;
    return(
      <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
        <div style={{background:B.white,padding:"13px 18px",borderBottom:`1px solid ${B.pinkLight}`,display:"flex",alignItems:"center",gap:10,position:"sticky",top:0,zIndex:100}}>
          <button onClick={()=>setView("lista")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
          <div style={{flex:1,fontSize:12,fontWeight:700,color:B.text,lineHeight:1.3,paddingRight:8}}>{ideaAbierta.titulo}</div>
          <div style={{padding:"3px 9px",borderRadius:20,background:est.bg,border:`1px solid ${est.color}40`,fontSize:8,color:est.color,fontWeight:700,flexShrink:0}}>{est.icon} {est.label}</div>
        </div>
        <div style={{paddingBottom:40}}>
          <div style={{background:B.white,padding:"15px 16px",borderBottom:`1px solid ${B.pinkLight}`}}>
            <div style={{display:"flex",gap:6,marginBottom:9,flexWrap:"wrap"}}>
              <div style={{padding:"3px 9px",borderRadius:20,background:`${cat.color}15`,border:`1px solid ${cat.color}40`,fontSize:8,color:cat.color,fontWeight:700}}>{cat.emoji} {cat.label}</div>
              <div style={{padding:"3px 9px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:8,color:B.mid}}>{PERFILES[ideaAbierta.perfil]?.label} · {ideaAbierta.fecha}</div>
            </div>
            <div style={{fontSize:13,color:B.text,lineHeight:1.7,marginBottom:13}}>{ideaAbierta.descripcion}</div>
            <button onClick={()=>votar(ideaAbierta.id)} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 15px",background:yaV?`${B.pink}15`:B.white,border:`2px solid ${yaV?B.pink:B.glacier}`,borderRadius:10,transition:"all .2s"}}>
              <span style={{fontSize:16}}>{yaV?"💖":"🤍"}</span>
              <span style={{fontSize:11,fontWeight:700,color:yaV?B.pink:B.mid}}>{totalV(ideaAbierta)} votos</span>
            </button>
          </div>
          {isCM&&(
            <div style={{margin:"12px 14px 0",padding:"13px",background:B.goldPale,borderRadius:11,border:`1px solid ${"#CAA150"}30`}}>
              <div style={{fontSize:8,letterSpacing:2,color:"#CAA150",fontWeight:700,marginBottom:9}}>✦ DECISIÓN CM</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:7}}>
                {[["analisis","🔍","Análisis"],["aprobada","✅","Aprobar"],["descartada","✕","Descartar"]].map(([e,ic,lb])=>(
                  <button key={e} onClick={()=>cambiarEstado(ideaAbierta.id,e)} style={{padding:"9px 5px",background:ideaAbierta.estado===e?ESTADOS_LAB[e].bg:B.white,border:`2px solid ${ideaAbierta.estado===e?ESTADOS_LAB[e].color:B.glacier}`,borderRadius:9,fontSize:9,color:ideaAbierta.estado===e?ESTADOS_LAB[e].color:B.mid,fontWeight:700,transition:"all .2s",textAlign:"center"}}>
                    <div style={{fontSize:15,marginBottom:2}}>{ic}</div>{lb}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div style={{padding:"12px 14px 0"}}>
            <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:9}}>COMENTARIOS ({ideaAbierta.comentarios.length})</div>
            {ideaAbierta.comentarios.length===0&&<div style={{padding:"14px",background:B.white,borderRadius:10,border:`1px solid ${B.pinkLight}`,textAlign:"center",fontSize:10,color:B.mid}}>Sé la primera en comentar ✨</div>}
            {ideaAbierta.comentarios.map((c,i)=>(
              <div key={i} style={{background:B.white,borderRadius:10,padding:"11px 13px",marginBottom:7,border:`1px solid ${B.pinkLight}`}}>
                <div style={{display:"flex",gap:7,alignItems:"center",marginBottom:4}}>
                  <div style={{width:22,height:22,borderRadius:"50%",background:`${PERFILES[c.perfil]?.color}15`,border:`1px solid ${PERFILES[c.perfil]?.color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11}}>{c.emoji||"✨"}</div>
                  <div style={{fontSize:9,fontWeight:700,color:PERFILES[c.perfil]?.color}}>{PERFILES[c.perfil]?.label}</div>
                  <div style={{fontSize:8,color:B.mid,marginLeft:"auto"}}>{c.fecha}</div>
                </div>
                <div style={{fontSize:12,color:B.text,lineHeight:1.5}}>{c.texto}</div>
              </div>
            ))}
            <div style={{display:"flex",gap:7,marginTop:5}}>
              <input value={coment} onChange={e=>setComent(e.target.value)} onKeyDown={e=>e.key==="Enter"&&comentar(ideaAbierta.id)} placeholder="Tu comentario..." style={{flex:1,padding:"9px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:8,fontSize:12,color:B.text,background:B.white}}/>
              <button onClick={()=>comentar(ideaAbierta.id)} style={{padding:"9px 14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:8,color:B.white,fontSize:12,fontWeight:700}}>↑</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const filtradas=[...ideas].filter(i=>filterCat==="all"||i.categoria===filterCat).sort((a,b)=>totalV(b)-totalV(a));
  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <div style={{background:B.white,padding:"13px 18px 0",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:9}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <button onClick={onBack} style={{background:"transparent",color:B.mid,fontSize:10,fontWeight:700,padding:0}}>← OS</button>
            <div style={{width:1,height:13,background:B.glacier}}/>
            <div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,color:B.text,fontWeight:300,letterSpacing:2}}>Niki Lab 🧪</div><div style={{fontSize:7,letterSpacing:2,color:B.mid}}>IDEAS DEL EQUIPO</div></div>
          </div>
          <button onClick={()=>setView("nueva")} style={{padding:"7px 13px",background:`linear-gradient(135deg,${B.green},${B.green}cc)`,borderRadius:8,color:B.white,fontSize:9,fontWeight:700,boxShadow:`0 3px 10px ${B.green}25`}}>+ IDEA</button>
        </div>
        <div style={{display:"flex",gap:5,overflowX:"auto",scrollbarWidth:"none",paddingBottom:10}}>
          <button onClick={()=>setFilterCat("all")} style={{padding:"4px 11px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:filterCat==="all"?B.text:B.white,color:filterCat==="all"?B.white:B.mid,border:`1px solid ${filterCat==="all"?B.text:B.glacier}`,transition:"all .2s"}}>TODAS</button>
          {CATS_LAB.map(c=><button key={c.id} onClick={()=>setFilterCat(c.id)} style={{padding:"4px 10px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:filterCat===c.id?c.color:B.white,color:filterCat===c.id?B.white:B.mid,border:`1px solid ${filterCat===c.id?c.color:B.glacier}`,transition:"all .2s"}}>{c.emoji} {c.label}</button>)}
        </div>
      </div>
      <div style={{padding:"12px 14px 40px"}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:7,marginBottom:12}}>
          {[{l:"Total",v:ideas.length,c:B.pink},{l:"Análisis",v:ideas.filter(i=>i.estado==="analisis").length,c:"#CAA150"},{l:"Aprobadas",v:ideas.filter(i=>i.estado==="aprobada").length,c:B.green},{l:"Votos",v:ideas.reduce((a,i)=>a+totalV(i),0),c:B.purple}].map((s,i)=>(
            <div key={i} style={{background:B.white,borderRadius:11,padding:"10px 6px",border:`1px solid ${B.pinkLight}`,textAlign:"center",boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
              <div style={{fontFamily:"Georgia,serif",fontSize:19,color:s.c,fontWeight:300,lineHeight:1}}>{s.v}</div>
              <div style={{fontSize:7,color:B.mid,marginTop:2}}>{s.l}</div>
            </div>
          ))}
        </div>
        {filtradas.map((idea,i)=>{
          const cat=CATS_LAB.find(c=>c.id===idea.categoria);
          const est=ESTADOS_LAB[idea.estado];
          const yaV=idea.votos[user.perfil]===1;
          return(
            <div key={idea.id} style={{background:B.white,borderRadius:13,marginBottom:9,border:`1.5px solid ${B.pinkLight}`,overflow:"hidden",boxShadow:"0 2px 7px rgba(221,164,174,0.06)",animation:`fadeUp .3s ease ${i*.04}s both`}}>
              <div style={{height:3,background:`linear-gradient(90deg,${cat.color}60,${cat.color})`}}/>
              <div style={{padding:"13px 15px"}}>
                <div style={{display:"flex",gap:9,alignItems:"flex-start",marginBottom:7}}>
                  <div style={{width:34,height:34,borderRadius:9,flexShrink:0,background:`${cat.color}12`,border:`1px solid ${cat.color}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:17}}>{cat.emoji}</div>
                  <div style={{flex:1,cursor:"pointer"}} onClick={()=>{setOpenId(idea.id);setView("detalle");}}>
                    <div style={{fontSize:12,fontWeight:700,color:B.text,lineHeight:1.3,marginBottom:3}}>{idea.titulo}</div>
                    <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                      <div style={{padding:"2px 7px",borderRadius:20,background:`${cat.color}12`,border:`1px solid ${cat.color}35`,fontSize:7,color:cat.color,fontWeight:700}}>{cat.label}</div>
                      <div style={{padding:"2px 7px",borderRadius:20,background:est.bg,border:`1px solid ${est.color}40`,fontSize:7,color:est.color,fontWeight:700}}>{est.icon} {est.label}</div>
                    </div>
                  </div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:8,borderTop:`1px solid ${B.coolGray}`,paddingTop:8}}>
                  <button onClick={()=>votar(idea.id)} style={{display:"flex",alignItems:"center",gap:4,padding:"4px 11px",background:yaV?`${B.pink}15`:B.coolGray,border:`1.5px solid ${yaV?B.pink:B.glacier}`,borderRadius:20,fontSize:10,color:yaV?B.pink:B.mid,fontWeight:700,transition:"all .2s"}}>
                    {yaV?"💖":"🤍"} {totalV(idea)}
                  </button>
                  <button onClick={()=>{setOpenId(idea.id);setView("detalle");}} style={{display:"flex",alignItems:"center",gap:3,padding:"4px 9px",background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:20,fontSize:9,color:B.mid}}>
                    💬 {idea.comentarios.length}
                  </button>
                  <div style={{marginLeft:"auto",fontSize:8,color:B.mid}}>{idea.fecha}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── MÓDULO STAY TUNED ────────────────────────────────────────────────────────
function ModBlog({user,onBack}){
  const [open,setOpen]=useState(null);
  const countdown=useCountdown("2026-05-17T10:00:00");
  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <div style={{background:B.white,padding:"13px 18px 16px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)",position:"relative",overflow:"hidden"}}>
        <PatternBg opacity={0.04} id="blog-p"/>
        <div style={{position:"relative",display:"flex",alignItems:"center",gap:10}}>
          <button onClick={onBack} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>← OS</button>
          <div><div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:B.text,fontWeight:300,letterSpacing:2}}>Stay Tuned ✨</div><div style={{fontSize:9,color:B.mid}}>Novedades y eventos de Niki BB</div></div>
        </div>
      </div>
      <div style={{padding:"14px 14px 40px"}}>
        {BLOG_POSTS.map((p,i)=>(
          <div key={p.id} onClick={()=>setOpen(open===p.id?null:p.id)} style={{background:B.white,borderRadius:14,marginBottom:10,border:`1.5px solid ${open===p.id?p.color:B.pinkLight}`,overflow:"hidden",cursor:"pointer",transition:"all .2s",boxShadow:open===p.id?`0 5px 20px ${p.color}15`:"0 2px 6px rgba(221,164,174,0.06)",animation:`fadeUp .3s ease ${i*.06}s both`}}>
            <div style={{height:3,background:`linear-gradient(90deg,${p.color}70,${p.color})`}}/>
            <div style={{padding:"14px 15px"}}>
              <div style={{display:"flex",gap:11,alignItems:"flex-start"}}>
                <div style={{width:44,height:44,borderRadius:11,flexShrink:0,background:`${p.color}12`,border:`1px solid ${p.color}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:21}}>{p.emoji}</div>
                <div style={{flex:1}}>
                  <div style={{display:"inline-block",padding:"2px 8px",borderRadius:20,background:`${p.color}12`,border:`1px solid ${p.color}35`,fontSize:7,color:p.color,fontWeight:700,letterSpacing:1,marginBottom:5}}>{p.tag}</div>
                  <div style={{fontSize:13,fontWeight:700,color:B.text,lineHeight:1.3,marginBottom:2}}>{p.titulo}</div>
                  <div style={{fontSize:9,color:B.mid}}>{p.sub}</div>
                </div>
                <div style={{textAlign:"right",flexShrink:0}}>
                  <div style={{fontSize:8,color:B.mid}}>{p.fecha}</div>
                  <div style={{fontSize:12,color:B.glacier,marginTop:6}}>{open===p.id?"↑":"›"}</div>
                </div>
              </div>
              {open===p.id&&(
                <div style={{marginTop:13,animation:"fadeUp .25s ease forwards"}}>
                  <div style={{height:1,background:B.coolGray,marginBottom:11}}/>
                  {p.countdown&&!countdown.expired&&countdown.dias!==undefined&&(
                    <div style={{display:"flex",gap:7,marginBottom:12,padding:"12px",background:B.pinkBg,borderRadius:10,border:`1px solid ${B.pinkLight}`}}>
                      {[{v:countdown.dias,l:"DÍAS"},{v:countdown.horas,l:"HORAS"},{v:countdown.min,l:"MIN"},{v:countdown.seg,l:"SEG"}].map((c,ci)=>(
                        <div key={ci} style={{flex:1,textAlign:"center"}}>
                          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:21,color:ci===0?B.pink:B.text,fontWeight:300,lineHeight:1}}>{String(c.v).padStart(2,"0")}</div>
                          <div style={{fontSize:7,color:B.mid,letterSpacing:1,marginTop:2}}>{c.l}</div>
                        </div>
                      ))}
                    </div>
                  )}
                  {p.link?(
                    <a href={p.link} target="_blank" rel="noopener noreferrer" style={{textDecoration:"none"}}>
                      <div style={{padding:"11px",borderRadius:9,background:`linear-gradient(135deg,${p.color},${p.color}cc)`,textAlign:"center",fontSize:9,color:B.white,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:7}}>
                        <Destello size={9} color={B.white}/>{p.cta}
                      </div>
                    </a>
                  ):(
                    <div style={{padding:"11px",borderRadius:9,background:`${p.color}10`,border:`1px solid ${p.color}35`,textAlign:"center",fontSize:9,color:p.color,fontWeight:700,letterSpacing:2}}>{p.cta}</div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        <div style={{textAlign:"center",padding:"14px 0 6px"}}>
          <Destello size={12} color="#CAA150"/>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:10,color:B.glacier,fontStyle:"italic",letterSpacing:2,marginTop:7}}>Niki Beauty Bar · Buenos Aires · Miami · 2026</div>
        </div>
      </div>
    </div>
  );
}

// ─── MÓDULO FRASES DEL CAFÉ ───────────────────────────────────────────────────
const FRASES_DATA = [
  { id:1,  frase:"A mal día, lindas uñas.",                                            cat:"actitud",   color:B.pinkDeep  },
  { id:2,  frase:"Ella no espera que la arreglen. Ella se arregla sola.",              cat:"poder",     color:"#CAA150"   },
  { id:3,  frase:"Tus uñas son el accesorio que siempre llevás puesto.",               cat:"belleza",   color:B.pink      },
  { id:4,  frase:"Una mujer con las uñas lindas tiene todo bajo control.",             cat:"actitud",   color:B.pinkDeep  },
  { id:5,  frase:"El autocuidado no es un lujo. Es una necesidad.",                    cat:"bienestar", color:B.green     },
  { id:6,  frase:"Sé tu propia razón para sonreír.",                                  cat:"poder",     color:"#CAA150"   },
  { id:7,  frase:"Manicura hecha, semana ganada.",                                    cat:"humor",     color:B.pink      },
  { id:8,  frase:"No sé quién lo necesita escuchar, pero merecés mimarte hoy.",       cat:"bienestar", color:B.green     },
  { id:9,  frase:"Las chicas que se cuidan son las que más cuidan a los demás.",       cat:"poder",     color:"#CAA150"   },
  { id:10, frase:"Viniste por las uñas y te vas renovada. Eso se llama magia.",       cat:"belleza",   color:B.pink      },
  { id:11, frase:"Tu tiempo acá es tuyo. Desconectate.",                               cat:"bienestar", color:B.green     },
  { id:12, frase:"Los detalles dicen todo de una persona.",                            cat:"belleza",   color:B.pinkDeep  },
  { id:13, frase:"Ser delicada no significa ser frágil.",                              cat:"poder",     color:"#CAA150"   },
  { id:14, frase:"Café, uñas y buena vibra. El plan perfecto.",                        cat:"humor",     color:B.pink      },
  { id:15, frase:"Hay cosas que no se heredan. Se eligen. Esta es una de ellas.",     cat:"actitud",   color:B.pinkDeep  },
  { id:16, frase:"Una vez que te tratás bien, no hay vuelta atrás.",                  cat:"bienestar", color:B.green     },
  { id:17, frase:"No necesitás permiso para brillar.",                                cat:"poder",     color:"#CAA150"   },
  { id:18, frase:"Ponete linda por vos, no para nadie más.",                          cat:"actitud",   color:B.pinkDeep  },
  { id:19, frase:"El color que elegís hoy dice algo de cómo te sentís.",              cat:"belleza",   color:B.pink      },
  { id:20, frase:"Que tu energía facture más que tu agenda.",                          cat:"humor",     color:"#CAA150"   },
  { id:21, frase:"Tu peor enemiga ya se rindió. Seguís acá.",                         cat:"actitud",   color:B.pinkDeep  },
  { id:22, frase:"Ser una girl boss empieza en los detalles.",                        cat:"poder",     color:"#CAA150"   },
  { id:23, frase:"Hoy no hay problema que no pueda esperar a que me sequen las uñas.",cat:"humor",     color:B.pink      },
  { id:24, frase:"La confianza en una misma es el mejor outfit.",                     cat:"poder",     color:"#CAA150"   },
  { id:25, frase:"No siempre podés controlar todo. Pero el color de tus uñas, sí.",  cat:"humor",     color:B.pinkDeep  },
  { id:26, frase:"El mundo se ve diferente con las manos recién hechas.",             cat:"belleza",   color:B.pink      },
  { id:27, frase:"Sos más fuerte de lo que creés. Y más linda también.",             cat:"actitud",   color:B.pinkDeep  },
  { id:28, frase:"Porque sí. Porque querés. Porque podés. Basta con eso.",           cat:"poder",     color:"#CAA150"   },
  { id:29, frase:"El mejor momento del día es este. El tuyo.",                        cat:"bienestar", color:B.green     },
  { id:30, frase:"Elegí el color como elegís tu humor: sin culpa.",                   cat:"belleza",   color:B.pink      },
];
const CATS_FRASES = [
  {id:"all",label:"Todas",emoji:"✨"},{id:"actitud",label:"Actitud",emoji:"🔥"},
  {id:"poder",label:"Poder",emoji:"👑"},{id:"belleza",label:"Belleza",emoji:"💅"},
  {id:"bienestar",label:"Bienestar",emoji:"🌸"},{id:"humor",label:"Humor",emoji:"😏"},
];

function ModFrases({onBack}){
  const [cat,setCat]=useState("all");
  const [favs,setFavs]=useState([1,7,23]);
  const [copied,setCopied]=useState(null);
  const [tab,setTab]=useState("todas");
  const [busq,setBusq]=useState("");
  const fraseDia=FRASES_DATA[new Date().getDate()%FRASES_DATA.length];
  const toggleFav=id=>setFavs(p=>p.includes(id)?p.filter(f=>f!==id):[...p,id]);
  const copiar=(texto,id)=>{
    navigator.clipboard?.writeText(`"${texto}" ✨`).catch(()=>{});
    setCopied(id);setTimeout(()=>setCopied(null),2000);
  };
  const filtradas=FRASES_DATA
    .filter(f=>tab==="favoritas"?favs.includes(f.id):true)
    .filter(f=>cat==="all"||f.cat===cat)
    .filter(f=>!busq.trim()||f.frase.toLowerCase().includes(busq.toLowerCase()));
  const col1=filtradas.filter((_,i)=>i%2===0);
  const col2=filtradas.filter((_,i)=>i%2!==0);

  return(
    <div style={{minHeight:"100vh",background:B.pinkBg,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      {/* Header */}
      <div style={{background:B.white,padding:"0 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
        <div style={{padding:"13px 0 10px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <button onClick={onBack} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>← OS</button>
            <div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:B.pink,fontWeight:300,letterSpacing:2}}>Frases del Café ☕</div>
              <div style={{fontSize:7,letterSpacing:2,color:B.mid}}>PARA COMPARTIR CON LAS CLIENTAS</div>
            </div>
          </div>
          <div style={{textAlign:"right"}}><div style={{fontFamily:"Georgia,serif",fontSize:22,color:"#CAA150",fontWeight:300,lineHeight:1}}>{FRASES_DATA.length}</div><div style={{fontSize:7,color:B.mid}}>frases</div></div>
        </div>
        <div style={{position:"relative",marginBottom:9}}>
          <input value={busq} onChange={e=>setBusq(e.target.value)} placeholder="Buscá una frase..." style={{width:"100%",padding:"8px 13px 8px 32px",border:`1.5px solid ${B.pinkLight}`,borderRadius:20,fontSize:12,color:B.text,background:B.coolGray}}/>
          <div style={{position:"absolute",left:11,top:"50%",transform:"translateY(-50%)",fontSize:12,color:B.mid}}>🔍</div>
        </div>
        <div style={{display:"flex",borderTop:`1px solid ${B.coolGray}`}}>
          {[{id:"todas",l:"Todas"},{id:"favoritas",l:`💖 Favoritas (${favs.length})`}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"7px 0 9px",background:"transparent",borderBottom:`2.5px solid ${tab===t.id?B.pink:"transparent"}`,color:tab===t.id?B.pink:B.mid,fontSize:9,fontWeight:tab===t.id?700:400,letterSpacing:.5,transition:"all .2s"}}>{t.l.toUpperCase()}</button>
          ))}
        </div>
      </div>

      <div style={{padding:"12px 13px 40px"}}>
        {/* Frase del día */}
        {tab==="todas"&&!busq&&(
          <div style={{background:`linear-gradient(135deg,${B.pinkDeep},#A05065)`,borderRadius:14,padding:"16px",marginBottom:14,position:"relative",overflow:"hidden",boxShadow:`0 5px 20px ${B.pinkDeep}30`}}>
            <svg style={{position:"absolute",inset:0,width:"100%",height:"100%",opacity:.06}} viewBox="0 0 120 80">
              <circle cx="20" cy="20" r="15" fill="none" stroke="white" strokeWidth="1"/>
              <circle cx="100" cy="60" r="20" fill="none" stroke="white" strokeWidth="1"/>
              <circle cx="60" cy="40" r="28" fill="none" stroke="white" strokeWidth=".6"/>
            </svg>
            <Destello size={24} color="rgba(255,255,255,0.2)" style={{position:"absolute",top:10,right:12,animation:"destelloSpin 10s linear infinite"}}/>
            <div style={{position:"relative"}}>
              <div style={{fontSize:7,letterSpacing:3,color:"rgba(255,255,255,0.6)",fontWeight:700,marginBottom:9}}>✦ FRASE DEL DÍA</div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,fontWeight:300,color:B.white,lineHeight:1.55,fontStyle:"italic",marginBottom:12}}>"{fraseDia.frase}"</div>
              <button onClick={()=>copiar(fraseDia.frase,`dia`)} style={{display:"flex",alignItems:"center",gap:6,padding:"6px 13px",background:"rgba(255,255,255,0.2)",borderRadius:20,fontSize:9,color:B.white,fontWeight:700,transition:"all .2s"}}>
                {copied==="dia"?"✓ COPIADA":"⧉ COPIAR"}
              </button>
            </div>
          </div>
        )}

        {/* Filtros */}
        <div style={{display:"flex",gap:5,overflowX:"auto",scrollbarWidth:"none",marginBottom:12}}>
          {CATS_FRASES.map(c=>(
            <button key={c.id} onClick={()=>setCat(c.id)} style={{padding:"4px 10px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:cat===c.id?B.text:B.white,color:cat===c.id?B.white:B.mid,border:`1px solid ${cat===c.id?B.text:B.glacier}`,transition:"all .2s"}}>
              {c.emoji} {c.label.toUpperCase()}
            </button>
          ))}
        </div>

        {filtradas.length===0&&(
          <div style={{textAlign:"center",padding:"36px 20px"}}>
            <div style={{fontSize:34,marginBottom:9}}>💭</div>
            <div style={{fontSize:13,fontWeight:700,color:B.text,marginBottom:4}}>{tab==="favoritas"?"Aún no guardaste favoritas":"Sin resultados"}</div>
            <div style={{fontSize:10,color:B.mid}}>{tab==="favoritas"?"Tocá el 💖 en cualquier frase":"Probá con otra búsqueda"}</div>
          </div>
        )}

        {/* Masonry 2 columnas */}
        {filtradas.length>0&&(
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9,alignItems:"start"}}>
            {[col1,col2].map((col,ci)=>(
              <div key={ci} style={{marginTop:ci===1?18:0}}>
                {col.map((f,i)=>{
                  const isFav=favs.includes(f.id);
                  const isLong=f.frase.length>55;
                  const heights=[125,110,140,115,130];
                  return(
                    <div key={f.id} style={{borderRadius:14,overflow:"hidden",background:`linear-gradient(135deg,${f.color},${f.color}dd)`,minHeight:heights[(i+ci)%heights.length],display:"flex",flexDirection:"column",justifyContent:"space-between",boxShadow:`0 4px 14px ${f.color}30`,position:"relative",marginBottom:9,animation:`fadeUp .25s ease ${((i*2+ci)%6)*.04}s both`}}>
                      {/* Pattern */}
                      <svg style={{position:"absolute",inset:0,width:"100%",height:"100%",opacity:.07,pointerEvents:"none"}} viewBox="0 0 80 80">
                        {i%3===0?<><circle cx="15" cy="15" r="12" fill="none" stroke="white" strokeWidth="1"/><circle cx="65" cy="65" r="10" fill="none" stroke="white" strokeWidth="0.8"/></>
                        :i%3===1?<><line x1="0" y1="20" x2="20" y2="0" stroke="white" strokeWidth="1"/><line x1="20" y1="80" x2="80" y2="20" stroke="white" strokeWidth="0.8"/></>
                        :<>{[10,30,50,70].slice(0,2).map(x=>[10,30,50,70].slice(0,2).map(y=><circle key={`${x}${y}`} cx={x} cy={y} r="1.5" fill="white"/>))}</>}
                      </svg>
                      <Destello size={i%2===0?20:14} color="rgba(255,255,255,0.18)" style={{position:"absolute",top:8,right:9,animation:"destelloSpin 14s linear infinite",pointerEvents:"none"}}/>
                      {/* Texto */}
                      <div style={{padding:"14px 13px 8px",position:"relative",flex:1,display:"flex",alignItems:"center"}}>
                        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:isLong?13:15,fontWeight:300,color:B.white,lineHeight:1.5,fontStyle:"italic",textShadow:"0 1px 3px rgba(0,0,0,0.1)"}}>"{f.frase}"</div>
                      </div>
                      {/* Actions */}
                      <div style={{padding:"4px 10px 9px",display:"flex",alignItems:"center",justifyContent:"space-between",position:"relative"}}>
                        <div style={{padding:"2px 7px",borderRadius:20,background:"rgba(255,255,255,0.18)",fontSize:6,color:"rgba(255,255,255,0.9)",fontWeight:700,letterSpacing:.5}}>
                          {CATS_FRASES.find(c=>c.id===f.cat)?.emoji} {CATS_FRASES.find(c=>c.id===f.cat)?.label.toUpperCase()}
                        </div>
                        <div style={{display:"flex",gap:5}}>
                          <button onClick={()=>toggleFav(f.id)} style={{width:26,height:26,borderRadius:"50%",background:isFav?"rgba(255,255,255,0.35)":"rgba(255,255,255,0.15)",border:"none",fontSize:12,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"all .2s"}}>{isFav?"💖":"🤍"}</button>
                          <button onClick={()=>copiar(f.frase,f.id)} style={{width:26,height:26,borderRadius:"50%",background:copied===f.id?"rgba(255,255,255,0.35)":"rgba(255,255,255,0.15)",border:"none",fontSize:11,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"all .2s"}}>{copied===f.id?"✓":"⧉"}</button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        )}
        <div style={{textAlign:"center",padding:"16px 0 4px"}}>
          <Destello size={11} color="#CAA150"/>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:9,color:B.glacier,fontStyle:"italic",letterSpacing:2,marginTop:6}}>Niki Beauty Bar · Frases para compartir</div>
        </div>
      </div>
    </div>
  );
}


// ─── MODAUDITORIAS ───────────────────────────────────────────────────────────
const CATEGORIAS = [
  { id:"estado_general",    label:"Estado General",      icon:"🏠", color:"#A67A2E", desc:"Orden, limpieza y funcionamiento general",    items:["Limpieza general","Orden en mesas y estaciones","Estado de mobiliario","Iluminación","Ambientación general"] },
  { id:"operacion_personal",label:"Operación y Personal", icon:"👥", color:"#DDA4AE", desc:"Dotación, actitud y liderazgo del equipo",    items:["Dotación completa según turno","Uniforme y presentación","Actitud y predisposición","Liderazgo de encargada","Gestión de agenda"] },
  { id:"imagen_marca",      label:"Imagen y Marca",       icon:"✨", color:"#C4808C", desc:"Alineación visual con los estándares Niki",   items:["Coherencia visual del espacio","Elementos decorativos acordes","Ausencia de objetos fuera de estética","Presentación del café","Música y aromas"] },
  { id:"equipamiento",      label:"Equipamiento",          icon:"🔧", color:"#7A9E9F", desc:"Estado de herramientas, mobiliario e insumos", items:["Estado del mobiliario","Stock de insumos","Organización del área","Estado de equipos","Presentación de materiales"] },
  { id:"experiencia_cliente",label:"Experiencia del Cliente",icon:"💅",color:"#A67A2E", desc:"Calidad de atención y protocolo de servicio", items:["Bienvenida y recepción","Tiempos de espera","Comunicación durante el servicio","Oferta de adicionales","Despedida y cierre"] },
  { id:"bioseguridad",      label:"Bioseguridad",           icon:"🛡️",color:"#5A9E6E", desc:"Cumplimiento de protocolos de higiene",       items:["Esterilización de herramientas","Uso de descartables","Protocolo de hongos","Higiene de manicuras","Limpieza entre clientas"] },
];

const LOCALES = ["Belgrano","Saavedra","Cañitas","Recoleta I","Recoleta II","Bella Vista","Banfield","Lomas","Canning","Puerto Madero","Adrogue","MdP Centro","MdP Güemes"];

const INIT_AUDITORIAS = [
  { id:1, local:"Belgrano", fecha:"21 Abr 2026", tipo:"casa_matriz", auditor:"Bárbara López", auditor_visible:true, puntaje_total:7.2,
    categorias:{ estado_general:{puntaje:8,obs:"Buenas condiciones generales. Orden y funcionamiento correcto.",fotos:[]}, operacion_personal:{puntaje:6,obs:"3 manicuras presentes. Encargada con actitud algo pasiva. Reforzar liderazgo.",fotos:[]}, imagen_marca:{puntaje:5,obs:"Colgante azul con elefantes. Difusor sahumerio. Bandejas plásticas blancas. Organizadores rosas en mesas.",fotos:[]}, equipamiento:{puntaje:7,obs:"Alto stock top coat Sally. Apoyamanos rosa con desgaste visible.",fotos:[]}, experiencia_cliente:{puntaje:8,obs:"Atención cordial. Bienvenida correcta. Reforzar oferta de adicionales.",fotos:[]}, bioseguridad:{puntaje:9,obs:"Protocolo aplicado correctamente. Sin observaciones críticas.",fotos:[]} },
    conclusiones:"Local operativo con desvíos en imagen y criterio estético. Ajustar elementos decorativos y reforzar rol de encargada.",
    puntos_mejora:["Reemplazar elementos decorativos fuera de estética","Reforzar liderazgo de encargada","Actualizar apoyamanos desgastados","Validar canal de toma de turnos"] },
  { id:2, local:"Saavedra", fecha:"15 Abr 2026", tipo:"misterioso_shopper", auditor:"Misterioso Shopper", auditor_visible:false, puntaje_total:8.5,
    categorias:{ estado_general:{puntaje:9,obs:"Excelente estado general.",fotos:[]}, operacion_personal:{puntaje:8,obs:"Equipo completo. Buen liderazgo.",fotos:[]}, imagen_marca:{puntaje:9,obs:"Buena alineación visual.",fotos:[]}, equipamiento:{puntaje:9,obs:"Todo en orden.",fotos:[]}, experiencia_cliente:{puntaje:8,obs:"Atención muy buena.",fotos:[]}, bioseguridad:{puntaje:8,obs:"Protocolos correctamente aplicados.",fotos:[]} },
    conclusiones:"Local en excelente estado. Referencia para la red.",
    puntos_mejora:["Mantener los estándares actuales"] },
];



function PBadge({p,size="md"}) {
  const c=p>=8?B.green:p>=6?B.gold:B.red;
  const bg=p>=8?B.greenPale:p>=6?B.goldPale:B.redPale;
  const fs=size==="lg"?28:size==="md"?18:13;
  return <div style={{padding:size==="lg"?"10px 20px":"4px 10px",borderRadius:20,background:bg,border:`1.5px solid ${c}40`,display:"inline-flex",alignItems:"center",gap:4}}>
    <span style={{fontFamily:"Georgia,serif",fontSize:fs,color:c,fontWeight:300,lineHeight:1}}>{p}</span>
    {size!=="sm"&&<span style={{fontSize:size==="lg"?12:9,color:c,fontWeight:700}}>/10</span>}
  </div>;
}

function SBar({p}) {
  const c=p>=8?B.green:p>=6?B.gold:B.red;
  return <div style={{height:5,background:B.coolGray,borderRadius:3,overflow:"hidden",flex:1}}>
    <div style={{width:`${p*10}%`,height:"100%",background:`linear-gradient(90deg,${c}80,${c})`,borderRadius:3}}/>
  </div>;
}

function NuevaAuditoria({onSave,onCancel}) {
  const [step,setStep]=useState(1);
  const [config,setConfig]=useState({local:"Belgrano",tipo:"casa_matriz",fecha:new Date().toISOString().split("T")[0]});
  const [scores,setScores]=useState(()=>Object.fromEntries(CATEGORIAS.map(c=>[c.id,{puntaje:7,obs:"",fotos:[]}])));
  const [conclusiones,setConclusiones]=useState("");
  const [puntosMejora,setPuntosMejora]=useState("");
  const [activecat,setActivecat]=useState(CATEGORIAS[0].id);
  const fileRefs=useRef({});

  const total=Math.round(Object.values(scores).reduce((a,s)=>a+s.puntaje,0)/CATEGORIAS.length*10)/10;

  const handleFoto=(catId,e)=>{
    Array.from(e.target.files).forEach(file=>{
      const r=new FileReader();
      r.onload=ev=>setScores(prev=>({...prev,[catId]:{...prev[catId],fotos:[...(prev[catId].fotos||[]),{url:ev.target.result,name:file.name}]}}));
      r.readAsDataURL(file);
    });
  };

  const save=()=>onSave({id:Date.now(),...config,auditor:config.tipo==="misterioso_shopper"?"Misterioso Shopper":"Casa Matriz",auditor_visible:config.tipo!=="misterioso_shopper",puntaje_total:total,categorias:scores,conclusiones,puntos_mejora:puntosMejora.split("\n").filter(p=>p.trim())});

  const CSS=`@import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300&display=swap');*{box-sizing:border-box;margin:0;padding:0;}::-webkit-scrollbar{width:3px;}::-webkit-scrollbar-thumb{background:${B.pinkLight};}@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}button{cursor:pointer;border:none;font-family:inherit;}input,textarea,select{font-family:inherit;outline:none;}`;

  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif"}}>
      <style>{CSS}</style>
      <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,display:"flex",alignItems:"center",gap:10,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
        <button onClick={onCancel} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>← Cancelar</button>
        <div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:B.text}}>Nueva Auditoría ✨</div><div style={{fontSize:8,color:B.mid}}>PASO {step} DE 3</div></div>
        <div style={{display:"flex",gap:5}}>{[1,2,3].map(s=><div key={s} style={{width:8,height:8,borderRadius:"50%",background:step>=s?B.pink:B.glacier}}/>)}</div>
      </div>

      <div style={{padding:"16px",paddingBottom:100}}>
        {step===1&&(
          <div>
            <div style={{fontFamily:"Georgia,serif",fontSize:20,color:B.text,fontWeight:300,marginBottom:16}}>Configurar auditoría</div>
            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>LOCAL AUDITADO</div>
              <select value={config.local} onChange={e=>setConfig(c=>({...c,local:e.target.value}))} style={{width:"100%",padding:"12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:13,color:B.text,background:B.white}}>
                {LOCALES.map(l=><option key={l}>{l}</option>)}
              </select>
            </div>
            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>FECHA DE VISITA</div>
              <input type="date" value={config.fecha} onChange={e=>setConfig(c=>({...c,fecha:e.target.value}))} style={{width:"100%",padding:"12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:13,color:B.text,background:B.white}}/>
            </div>
            <div style={{marginBottom:20}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:10}}>TIPO DE AUDITORÍA</div>
              {[{key:"casa_matriz",label:"Casa Matriz / Directora",icon:"✦",desc:"Franquiciado verá quién auditó",color:B.gold},{key:"misterioso_shopper",label:"Misterioso Shopper",icon:"🕵️",desc:"Identidad oculta para el franquiciado",color:B.pinkDeep}].map(opt=>(
                <button key={opt.key} onClick={()=>setConfig(c=>({...c,tipo:opt.key}))} style={{width:"100%",padding:"14px 16px",background:config.tipo===opt.key?B.white:"rgba(255,255,255,0.6)",border:`2px solid ${config.tipo===opt.key?opt.color:B.pinkLight}`,borderRadius:12,display:"flex",alignItems:"center",gap:14,marginBottom:8,transition:"all .2s",boxShadow:config.tipo===opt.key?`0 4px 14px ${opt.color}15`:"none"}}>
                  <div style={{width:38,height:38,borderRadius:"50%",background:`${opt.color}15`,border:`1.5px solid ${opt.color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>{opt.icon}</div>
                  <div style={{textAlign:"left",flex:1}}><div style={{fontSize:12,fontWeight:700,color:B.text,marginBottom:2}}>{opt.label}</div><div style={{fontSize:9,color:B.mid}}>{opt.desc}</div></div>
                  {config.tipo===opt.key&&<Star size={10} color={opt.color}/>}
                </button>
              ))}
            </div>
            <button onClick={()=>setStep(2)} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,boxShadow:`0 6px 16px ${B.pink}30`,display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
              <Star size={10} color={B.white}/>COMENZAR EVALUACIÓN
            </button>
          </div>
        )}

        {step===2&&(
          <div>
            <div style={{background:B.white,borderRadius:12,padding:"14px",marginBottom:14,border:`1px solid ${B.pinkLight}`,position:"relative",overflow:"hidden"}}>
              <PatternBg opacity={0.04} id="ap"/>
              <div style={{position:"relative",display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                <div><div style={{fontSize:12,fontWeight:700,color:B.text}}>{config.local}</div><div style={{fontSize:9,color:B.mid}}>{config.fecha}</div></div>
                <PBadge p={total} size="lg"/>
              </div>
              <div style={{height:5,background:B.coolGray,borderRadius:3,overflow:"hidden"}}>
                <div style={{width:`${total*10}%`,height:"100%",background:`linear-gradient(90deg,${total>=8?B.green:total>=6?B.gold:B.red}80,${total>=8?B.green:total>=6?B.gold:B.red})`,borderRadius:3,transition:"width .5s"}}/>
              </div>
            </div>

            <div style={{display:"flex",gap:7,overflowX:"auto",marginBottom:14,scrollbarWidth:"none"}}>
              {CATEGORIAS.map(c=>{
                const s=scores[c.id];const active=activecat===c.id;
                return <button key={c.id} onClick={()=>setActivecat(c.id)} style={{flexShrink:0,padding:"6px 12px",borderRadius:20,fontSize:8,fontWeight:700,background:active?c.color:B.white,color:active?B.white:B.mid,border:`1px solid ${active?c.color:B.pinkLight}`,transition:"all .2s",display:"flex",alignItems:"center",gap:5}}>
                  <span>{c.icon}</span><span style={{whiteSpace:"nowrap"}}>{c.label}</span>
                  <span style={{padding:"1px 6px",borderRadius:10,background:active?"rgba(255,255,255,0.25)":`${s.puntaje>=8?B.green:s.puntaje>=6?B.gold:B.red}20`,fontSize:7,color:active?B.white:s.puntaje>=8?B.green:s.puntaje>=6?B.gold:B.red,fontWeight:700}}>{s.puntaje}</span>
                </button>;
              })}
            </div>

            {CATEGORIAS.filter(c=>c.id===activecat).map(cat=>{
              const s=scores[cat.id];
              return <div key={cat.id} style={{background:B.white,borderRadius:14,overflow:"hidden",border:`1.5px solid ${cat.color}30`,marginBottom:14}}>
                <div style={{height:3,background:`linear-gradient(90deg,${cat.color}60,${cat.color})`}}/>
                <div style={{padding:"16px"}}>
                  <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14}}>
                    <div style={{fontSize:24}}>{cat.icon}</div>
                    <div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:B.text}}>{cat.label}</div><div style={{fontSize:9,color:B.mid}}>{cat.desc}</div></div>
                    <PBadge p={s.puntaje} size="md"/>
                  </div>
                  <div style={{marginBottom:14}}>
                    <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>PUNTAJE</div>
                    <div style={{display:"flex",gap:5}}>
                      {[1,2,3,4,5,6,7,8,9,10].map(n=>(
                        <button key={n} onClick={()=>setScores(p=>({...p,[cat.id]:{...p[cat.id],puntaje:n}}))} style={{flex:1,aspectRatio:"1",borderRadius:7,fontSize:10,fontWeight:700,background:s.puntaje>=n?(n>=8?B.green:n>=6?B.gold:B.red):`${n>=8?B.green:n>=6?B.gold:B.red}15`,color:s.puntaje>=n?B.white:(n>=8?B.green:n>=6?B.gold:B.red),border:`1px solid ${n>=8?B.green:n>=6?B.gold:B.red}${s.puntaje>=n?"":"40"}`,transition:"all .15s"}}>{n}</button>
                      ))}
                    </div>
                  </div>
                  <div style={{marginBottom:12}}>
                    <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:6}}>ITEMS</div>
                    {cat.items.map((item,i)=><div key={i} style={{display:"flex",gap:8,padding:"6px 0",borderBottom:`1px solid ${B.coolGray}`}}>
                      <div style={{width:15,height:15,borderRadius:4,background:`${cat.color}15`,border:`1px solid ${cat.color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:7,color:cat.color,flexShrink:0,marginTop:1}}>✓</div>
                      <div style={{fontSize:11,color:B.text,lineHeight:1.4}}>{item}</div>
                    </div>)}
                  </div>
                  <div style={{marginBottom:12}}>
                    <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:6}}>OBSERVACIONES</div>
                    <textarea value={s.obs} onChange={e=>setScores(p=>({...p,[cat.id]:{...p[cat.id],obs:e.target.value}}))} placeholder={`Observaciones de ${cat.label.toLowerCase()}...`} rows={3} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,lineHeight:1.5,resize:"none",background:B.pinkBg,fontFamily:"'Lato',sans-serif"}}/>
                  </div>
                  <div>
                    <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:6}}>FOTOS DE EVIDENCIA</div>
                    <div onClick={()=>fileRefs.current[cat.id]?.click()} style={{border:`2px dashed ${s.fotos?.length>0?cat.color:B.glacier}`,borderRadius:9,padding:"12px",textAlign:"center",cursor:"pointer",background:B.pinkBg,marginBottom:s.fotos?.length>0?8:0}}>
                      <div style={{fontSize:18,marginBottom:4}}>📸</div><div style={{fontSize:9,color:B.mid}}>Agregar fotos de evidencia</div>
                      <input ref={el=>fileRefs.current[cat.id]=el} type="file" accept="image/*" multiple capture="environment" onChange={e=>handleFoto(cat.id,e)} style={{display:"none"}}/>
                    </div>
                    {s.fotos?.length>0&&<div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6}}>
                      {s.fotos.map((f,i)=><div key={i} style={{borderRadius:8,overflow:"hidden",aspectRatio:"1",position:"relative"}}>
                        <img src={f.url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                        <button onClick={()=>setScores(p=>({...p,[cat.id]:{...p[cat.id],fotos:p[cat.id].fotos.filter((_,fi)=>fi!==i)}}))} style={{position:"absolute",top:3,right:3,width:18,height:18,borderRadius:"50%",background:"rgba(0,0,0,0.6)",color:B.white,fontSize:10,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
                      </div>)}
                    </div>}
                  </div>
                </div>
              </div>;
            })}

            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setStep(1)} style={{flex:1,padding:"13px",background:B.white,border:`1px solid ${B.glacier}`,borderRadius:10,fontSize:10,color:B.mid,fontWeight:700}}>← Volver</button>
              <button onClick={()=>setStep(3)} style={{flex:2,padding:"13px",background:`linear-gradient(135deg,${B.gold},${B.goldLight})`,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:2,boxShadow:`0 6px 14px ${B.gold}25`,display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
                <Star size={10} color={B.white}/>CONCLUSIONES ›
              </button>
            </div>
          </div>
        )}

        {step===3&&(
          <div>
            <div style={{background:B.white,borderRadius:14,overflow:"hidden",marginBottom:14,border:`1px solid ${B.pinkLight}`,position:"relative"}}>
              <div style={{height:4,background:`linear-gradient(90deg,${B.pink},${B.gold})`}}/>
              <PatternBg opacity={0.04} id="sp"/>
              <div style={{padding:"16px",position:"relative"}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
                  <div><div style={{fontSize:14,fontWeight:700,color:B.text}}>{config.local}</div><div style={{fontSize:9,color:B.mid}}>{config.fecha}</div></div>
                  <PBadge p={total} size="lg"/>
                </div>
                {CATEGORIAS.map(c=><div key={c.id} style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
                  <div style={{fontSize:14,width:20}}>{c.icon}</div>
                  <div style={{fontSize:10,color:B.text,flex:1,fontWeight:500}}>{c.label}</div>
                  <SBar p={scores[c.id].puntaje}/>
                  <PBadge p={scores[c.id].puntaje} size="sm"/>
                </div>)}
              </div>
            </div>
            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:6}}>CONCLUSIÓN GENERAL</div>
              <textarea value={conclusiones} onChange={e=>setConclusiones(e.target.value)} placeholder="Conclusión general de la auditoría..." rows={4} style={{width:"100%",padding:"11px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,lineHeight:1.6,resize:"none",background:B.pinkBg,fontFamily:"'Lato',sans-serif"}}/>
            </div>
            <div style={{marginBottom:22}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:6}}>PUNTOS DE MEJORA (uno por línea)</div>
              <textarea value={puntosMejora} onChange={e=>setPuntosMejora(e.target.value)} placeholder={"Reemplazar decoración fuera de estética\nReforzar liderazgo de encargada"} rows={4} style={{width:"100%",padding:"11px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,lineHeight:1.7,resize:"none",background:B.pinkBg,fontFamily:"'Lato',sans-serif"}}/>
            </div>
            <div style={{display:"flex",gap:10}}>
              <button onClick={()=>setStep(2)} style={{flex:1,padding:"13px",background:B.white,border:`1px solid ${B.glacier}`,borderRadius:10,fontSize:10,color:B.mid,fontWeight:700}}>← Volver</button>
              <button onClick={save} style={{flex:2,padding:"13px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:2,boxShadow:`0 6px 14px ${B.pink}25`,display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
                <Star size={10} color={B.white}/>GUARDAR AUDITORÍA
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function DetalleAuditoria({auditoria,rolVisor,onBack}) {
  const [activecat,setActivecat]=useState(null);
  const [activeImg,setActiveImg]=useState(null);
  const mostrarAuditor=auditoria.auditor_visible||rolVisor==="casa_matriz";

  if(activeImg) return <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.92)",zIndex:999,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"}} onClick={()=>setActiveImg(null)}>
    <img src={activeImg} style={{maxWidth:"95vw",maxHeight:"85vh",objectFit:"contain",borderRadius:8}}/>
    <div style={{color:"rgba(255,255,255,0.4)",fontSize:10,marginTop:12}}>TOCA PARA CERRAR</div>
  </div>;

  return <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif"}}>
    <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,display:"flex",alignItems:"center",gap:10,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
      <button onClick={onBack} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>← Volver</button>
      <div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:B.text}}>{auditoria.local}</div><div style={{fontSize:8,color:B.mid}}>{auditoria.fecha}</div></div>
    </div>
    <div style={{padding:"16px",paddingBottom:40}}>
      <div style={{background:B.white,borderRadius:16,overflow:"hidden",marginBottom:14,border:`1px solid ${B.pinkLight}`,position:"relative"}}>
        <div style={{height:4,background:`linear-gradient(90deg,${B.pink},${B.gold})`}}/>
        <PatternBg opacity={0.04} id="dp"/>
        <div style={{padding:"18px",position:"relative"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:14}}>
            <div>
              <div style={{fontFamily:"Georgia,serif",fontSize:20,color:B.text,fontWeight:300,marginBottom:4}}>{auditoria.local}</div>
              <div style={{fontSize:10,color:B.mid,marginBottom:8}}>{auditoria.fecha}</div>
              <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                <div style={{padding:"2px 10px",borderRadius:20,background:auditoria.tipo==="misterioso_shopper"?`${B.pinkDeep}15`:B.goldPale,border:`1px solid ${auditoria.tipo==="misterioso_shopper"?B.pinkDeep:B.gold}40`,fontSize:7,color:auditoria.tipo==="misterioso_shopper"?B.pinkDeep:B.gold,fontWeight:700}}>
                  {auditoria.tipo==="misterioso_shopper"?"🕵️ Misterioso Shopper":"✦ Casa Matriz"}
                </div>
                {mostrarAuditor&&auditoria.tipo!=="misterioso_shopper"&&<div style={{padding:"2px 10px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:7,color:B.mid,fontWeight:700}}>{auditoria.auditor}</div>}
              </div>
            </div>
            <PBadge p={auditoria.puntaje_total} size="lg"/>
          </div>
          <div style={{height:6,background:B.coolGray,borderRadius:3,overflow:"hidden"}}>
            <div style={{width:`${auditoria.puntaje_total*10}%`,height:"100%",background:`linear-gradient(90deg,${auditoria.puntaje_total>=8?B.green:auditoria.puntaje_total>=6?B.gold:B.red}80,${auditoria.puntaje_total>=8?B.green:auditoria.puntaje_total>=6?B.gold:B.red})`,borderRadius:3}}/>
          </div>
        </div>
      </div>

      <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:12}}>CATEGORÍAS</div>
      {CATEGORIAS.map((cat,i)=>{
        const s=auditoria.categorias[cat.id];const open=activecat===cat.id;
        return <div key={cat.id} style={{background:B.white,borderRadius:12,marginBottom:8,overflow:"hidden",border:`1.5px solid ${open?cat.color:B.pinkLight}`,transition:"all .2s",animation:`fadeUp .3s ease ${i*.05}s both`}}>
          <div style={{height:3,background:`linear-gradient(90deg,${cat.color}60,${cat.color})`}}/>
          <div onClick={()=>setActivecat(open?null:cat.id)} style={{padding:"12px 14px",cursor:"pointer",display:"flex",alignItems:"center",gap:10}}>
            <div style={{fontSize:18}}>{cat.icon}</div>
            <div style={{flex:1}}><div style={{fontSize:11,fontWeight:700,color:B.text,marginBottom:5}}>{cat.label}</div><SBar p={s.puntaje}/></div>
            <PBadge p={s.puntaje} size="sm"/>
            <div style={{color:B.glacier,fontSize:11,marginLeft:4}}>{open?"↑":"›"}</div>
          </div>
          {open&&<div style={{padding:"0 14px 14px"}}>
            <div style={{height:1,background:B.coolGray,marginBottom:10}}/>
            {s.obs&&<div style={{fontSize:12,color:B.text,lineHeight:1.6,marginBottom:s.fotos?.length>0?12:0}}>{s.obs}</div>}
            {s.fotos?.length>0&&<div>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:6}}>FOTOS ({s.fotos.length})</div>
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6}}>
                {s.fotos.map((f,fi)=><div key={fi} onClick={()=>setActiveImg(f.url)} style={{borderRadius:8,overflow:"hidden",aspectRatio:"1",cursor:"pointer"}}>
                  <img src={f.url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                </div>)}
              </div>
            </div>}
          </div>}
        </div>;
      })}

      {auditoria.conclusiones&&<div style={{background:B.white,borderRadius:12,padding:"14px",marginBottom:10,border:`1px solid ${B.pinkLight}`}}>
        <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:6}}>CONCLUSIÓN GENERAL</div>
        <div style={{fontSize:12,color:B.text,lineHeight:1.7}}>{auditoria.conclusiones}</div>
      </div>}

      {auditoria.puntos_mejora?.length>0&&<div style={{background:B.goldPale,borderRadius:12,padding:"14px",border:`1px solid ${B.goldLight}40`}}>
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}><Star size={12} color={B.gold}/><div style={{fontSize:8,letterSpacing:2,color:B.gold,fontWeight:700}}>PUNTOS DE MEJORA</div></div>
        {auditoria.puntos_mejora.map((p,i)=><div key={i} style={{display:"flex",gap:8,alignItems:"flex-start",marginBottom:6}}>
          <div style={{width:15,height:15,borderRadius:"50%",background:B.gold,display:"flex",alignItems:"center",justifyContent:"center",fontSize:7,color:B.white,flexShrink:0,marginTop:1}}>{i+1}</div>
          <div style={{fontSize:11,color:B.text,lineHeight:1.4}}>{p}</div>
        </div>)}
      </div>}
    </div>
  </div>;
}

function ModAuditorias({user,onBack}) {
  const [role]=useState("casa_matriz");
  const [auditorias,setAuditorias]=useState(INIT_AUDITORIAS);
  const [view,setView]=useState("list");
  const [selected,setSelected]=useState(null);
  const [filtro,setFiltro]=useState("all");

  const filtered=auditorias.filter(a=>filtro==="all"||a.local===filtro);
  const promedio=auditorias.length?Math.round(auditorias.reduce((a,au)=>a+au.puntaje_total,0)/auditorias.length*10)/10:0;

  if(view==="nueva") return <NuevaAuditoria onSave={a=>{setAuditorias(p=>[a,...p]);setView("list");}} onCancel={()=>setView("list")}/>;
  if(view==="detalle"&&selected) return <DetalleAuditoria auditoria={selected} rolVisor={role} onBack={()=>{setView("list");setSelected(null);}}/>;

  return <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
    <style>{`@import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300&display=swap');*{box-sizing:border-box;margin:0;padding:0;}::-webkit-scrollbar{width:3px;}::-webkit-scrollbar-thumb{background:${B.pinkLight};}@keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}button{cursor:pointer;border:none;font-family:inherit;}input,textarea,select{font-family:inherit;outline:none;}.card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(221,164,174,0.16)!important;}`}</style>

    <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:4}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <Star size={12} color={B.gold}/>
          <div>
            <div style={{display:"flex",alignItems:"baseline",gap:6}}>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:17,fontWeight:300,letterSpacing:5,color:B.pink,lineHeight:1}}>NIKI</div>
              <div style={{padding:"2px 8px",borderRadius:5,background:B.goldPale,border:`1px solid ${B.goldLight}50`,fontSize:8,color:B.gold,fontWeight:700,letterSpacing:3}}>OS</div>
            </div>
            <div style={{fontSize:7,letterSpacing:3,color:B.mid,marginTop:1}}>AUDITORÍAS ✨</div>
          </div>
        </div>
        <button onClick={()=>setView("nueva")} style={{padding:"8px 16px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:1,boxShadow:`0 4px 12px ${B.pink}25`}}>+ NUEVA</button>
      </div>
    </div>

    <div style={{padding:"16px",paddingBottom:40}}>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:14}}>
        {[{l:"Total",v:auditorias.length,c:B.pink},{l:"Promedio",v:promedio,c:promedio>=8?B.green:promedio>=6?B.gold:B.red},{l:"Este mes",v:auditorias.filter(a=>a.fecha.includes("Abr")).length,c:B.gold}].map((s,i)=>(
          <div key={i} style={{background:B.white,borderRadius:12,padding:"13px 10px",border:`1px solid ${B.pinkLight}`,textAlign:"center",boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
            <div style={{fontFamily:"Georgia,serif",fontSize:24,color:s.c,fontWeight:300,lineHeight:1}}>{s.v}</div>
            <div style={{fontSize:8,color:B.mid,marginTop:3}}>{s.l}</div>
          </div>
        ))}
      </div>

      <div style={{display:"flex",gap:7,overflowX:"auto",marginBottom:14,scrollbarWidth:"none"}}>
        {["all",...new Set(auditorias.map(a=>a.local))].map(l=>(
          <button key={l} onClick={()=>setFiltro(l)} style={{padding:"5px 12px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:filtro===l?B.pink:B.white,color:filtro===l?B.white:B.mid,border:`1px solid ${filtro===l?B.pink:B.pinkLight}`,transition:"all .2s"}}>
            {l==="all"?"TODOS":l.toUpperCase()}
          </button>
        ))}
      </div>

      <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:12}}>HISTORIAL DE VISITAS</div>
      {filtered.map((a,i)=>{
        const sc=a.puntaje_total>=8?B.green:a.puntaje_total>=6?B.gold:B.red;
        const sb=a.puntaje_total>=8?B.greenPale:a.puntaje_total>=6?B.goldPale:B.redPale;
        return <div key={a.id} className="card" onClick={()=>{setSelected(a);setView("detalle");}} style={{background:B.white,borderRadius:14,marginBottom:10,border:`1.5px solid ${B.pinkLight}`,cursor:"pointer",overflow:"hidden",transition:"all .2s",boxShadow:"0 2px 8px rgba(221,164,174,0.07)",animation:`fadeUp .3s ease ${i*.06}s both`}}>
          <div style={{height:3,background:`linear-gradient(90deg,${sc}60,${sc})`}}/>
          <div style={{padding:"14px 16px"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
              <div>
                <div style={{fontSize:14,fontWeight:700,color:B.text,marginBottom:3}}>{a.local}</div>
                <div style={{fontSize:10,color:B.mid,marginBottom:6}}>{a.fecha}</div>
                <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                  <div style={{padding:"2px 8px",borderRadius:20,background:a.tipo==="misterioso_shopper"?`${B.pinkDeep}12`:B.goldPale,border:`1px solid ${a.tipo==="misterioso_shopper"?B.pinkDeep:B.gold}40`,fontSize:7,color:a.tipo==="misterioso_shopper"?B.pinkDeep:B.gold,fontWeight:700}}>
                    {a.tipo==="misterioso_shopper"?"🕵️ Misterioso Shopper":"✦ Casa Matriz"}
                  </div>
                  {(a.auditor_visible||role==="casa_matriz")&&a.tipo!=="misterioso_shopper"&&<div style={{padding:"2px 8px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:7,color:B.mid,fontWeight:700}}>{a.auditor}</div>}
                </div>
              </div>
              <div style={{textAlign:"center",padding:"10px 16px",background:sb,borderRadius:12,border:`1.5px solid ${sc}40`}}>
                <div style={{fontFamily:"Georgia,serif",fontSize:26,color:sc,fontWeight:300,lineHeight:1}}>{a.puntaje_total}</div>
                <div style={{fontSize:7,color:sc,fontWeight:700,marginTop:2}}>/10</div>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:5,marginBottom:10}}>
              {CATEGORIAS.map(cat=>{
                const s=a.categorias[cat.id];const c=s.puntaje>=8?B.green:s.puntaje>=6?B.gold:B.red;
                return <div key={cat.id} style={{display:"flex",gap:4,alignItems:"center"}}>
                  <div style={{fontSize:10}}>{cat.icon}</div>
                  <div style={{height:4,flex:1,background:B.coolGray,borderRadius:2,overflow:"hidden"}}><div style={{width:`${s.puntaje*10}%`,height:"100%",background:c,borderRadius:2}}/></div>
                  <div style={{fontSize:8,color:c,fontWeight:700,minWidth:12}}>{s.puntaje}</div>
                </div>;
              })}
            </div>
            {a.conclusiones&&<div style={{fontSize:10,color:B.mid,lineHeight:1.5,overflow:"hidden",display:"-webkit-box",WebkitLineClamp:2,WebkitBoxOrient:"vertical",paddingTop:8,borderTop:`1px solid ${B.coolGray}`}}>{a.conclusiones}</div>}
          </div>
        </div>;
      })}
    </div>
  </div>;
}

// ─── MODOBRAS ───────────────────────────────────────────────────────────
const ETAPAS = [
  { id:"contrato",     label:"Firma de Contrato",        icon:"📋", color:"#9B8EA6", desc:"Firma del contrato de franquicia y/o local"          },
  { id:"busqueda",     label:"Búsqueda de Local",        icon:"🔍", color:B.gold,    desc:"Scouting, visitas y selección del espacio"          },
  { id:"obra_civil",   label:"Obra Civil",               icon:"🏗️", color:"#7A9E9F", desc:"Construcción, tabiques, instalaciones, electricidad"  },
  { id:"obra_niki",    label:"Obra Niki Beauty Bar",     icon:"✦",  color:B.pink,    desc:"Identidad visual, mobiliario y equipamiento Niki"    },
  { id:"etapa_1",      label:"Etapa de Obra 1",          icon:"1️⃣", color:B.pinkDeep,desc:"Primera etapa de obra específica"                    },
  { id:"etapa_2",      label:"Etapa de Obra 2",          icon:"2️⃣", color:B.gold,    desc:"Segunda etapa de obra específica"                   },
  { id:"etapa_3",      label:"Etapa de Obra 3",          icon:"3️⃣", color:"#7A9E9F", desc:"Tercera etapa de obra específica"                    },
  { id:"inauguracion", label:"Fecha de Inauguración",   icon:"🎉", color:B.green,   desc:"Apertura oficial del local al público"               },
];

const ESTADOS = [
  { id:"pendiente",   label:"Pendiente",    color:B.glacier  },
  { id:"en_curso",    label:"En curso",     color:B.gold     },
  { id:"completada",  label:"Completada",   color:B.green    },
  { id:"demorada",    label:"Demorada",     color:"#C0392B"  },
];

const INIT_OBRAS = [
  {
    id: 1,
    nombre: "Miami — Flagship USA",
    ubicacion: "Miami, Florida",
    responsable: "Casa Matriz",
    presupuesto_total: 85000,
    presupuesto_ejecutado: 32000,
    fecha_inicio: "2026-03-01",
    fecha_inauguracion_estimada: "2026-07-15",
    etapa_actual: "obra_civil",
    etapas: {
      contrato:   { estado:"completada", fecha_real:"2026-02-10", fecha_estimada:"2026-02-10", notas:"Contrato firmado con franquicia Miami LLC.", updates:[ { texto:"Contrato firmado correctamente. Documentación enviada a legal.", fecha:"10 Feb", autor:"Casa Matriz", fotos:[] } ] },
      busqueda:   { estado:"completada", fecha_real:"2026-03-05", fecha_estimada:"2026-03-01", notas:"Local en Brickell seleccionado. 180m2.", updates:[ { texto:"Se visitaron 4 locales. El de Brickell Ave es el elegido.", fecha:"28 Feb", autor:"Casa Matriz", fotos:[] }, { texto:"Local confirmado y señado. ¡Arrancamos! 🎉", fecha:"05 Mar", autor:"Casa Matriz", fotos:[] } ] },
      obra_civil: { estado:"en_curso",   fecha_real:null,         fecha_estimada:"2026-05-20", notas:"Empresa constructora: BuildMiami Co.", updates:[ { texto:"Demolición completada. Comenzaron las instalaciones eléctricas.", fecha:"15 Abr", autor:"Casa Matriz", fotos:[] }, { texto:"Avance de tabiques al 60%. Plomería instalada.", fecha:"20 Abr", autor:"Casa Matriz", fotos:[] } ] },
      obra_niki:  { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-06-10", notas:"",                                          updates:[] },
      etapa_1:    { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-06-01", notas:"",                                          updates:[] },
      etapa_2:    { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-06-20", notas:"",                                          updates:[] },
      etapa_3:    { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-07-01", notas:"",                                          updates:[] },
      inauguracion:{ estado:"pendiente", fecha_real:null,         fecha_estimada:"2026-07-15", notas:"Grand Opening planeado.",                    updates:[] },
    },
  },
  {
    id: 2,
    nombre: "Recoleta II",
    ubicacion: "Recoleta, Buenos Aires",
    responsable: "Franquiciada Norte",
    presupuesto_total: 4200000,
    presupuesto_ejecutado: 1800000,
    fecha_inicio: "2026-04-01",
    fecha_inauguracion_estimada: "2026-08-01",
    etapa_actual: "busqueda",
    etapas: {
      contrato:   { estado:"completada", fecha_real:"2026-03-20", fecha_estimada:"2026-03-20", notas:"Firmado.", updates:[ { texto:"Contrato de franquicia firmado. ¡Bienvenida al equipo Niki!", fecha:"20 Mar", autor:"Casa Matriz", fotos:[] } ] },
      busqueda:   { estado:"en_curso",   fecha_real:null,         fecha_estimada:"2026-04-30", notas:"Buscando local en Av. Santa Fe o Callao.", updates:[ { texto:"Se visitaron 2 locales. Evaluando propuestas.", fecha:"05 Abr", autor:"Casa Matriz", fotos:[] } ] },
      obra_civil: { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-05-15", notas:"", updates:[] },
      obra_niki:  { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-06-30", notas:"", updates:[] },
      etapa_1:    { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-06-15", notas:"", updates:[] },
      etapa_2:    { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-07-01", notas:"", updates:[] },
      etapa_3:    { estado:"pendiente",  fecha_real:null,         fecha_estimada:"2026-07-15", notas:"", updates:[] },
      inauguracion:{ estado:"pendiente", fecha_real:null,         fecha_estimada:"2026-08-01", notas:"", updates:[] },
    },
  },
];



function EstadoBadge({ estado }) {
  const e = ESTADOS.find(s=>s.id===estado) || ESTADOS[0];
  return (
    <div style={{padding:"2px 9px",borderRadius:20,background:`${e.color}18`,border:`1px solid ${e.color}50`,fontSize:8,color:e.color,fontWeight:700,letterSpacing:1,display:"inline-block"}}>
      {e.label.toUpperCase()}
    </div>
  );
}

function ProgressBar({ obra }) {
  const total = ETAPAS.length;
  const done  = ETAPAS.filter(e => obra.etapas[e.id]?.estado === "completada").length;
  const pct   = Math.round((done / total) * 100);
  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
        <div style={{fontSize:8,color:B.mid,letterSpacing:1}}>{done} DE {total} ETAPAS</div>
        <div style={{fontSize:8,color:B.gold,fontWeight:700}}>{pct}%</div>
      </div>
      <div style={{height:4,background:B.coolGray,borderRadius:2,overflow:"hidden"}}>
        <div style={{width:`${pct}%`,height:"100%",background:`linear-gradient(90deg,${B.pink},${B.gold})`,borderRadius:2,transition:"width 1s ease"}}/>
      </div>
    </div>
  );
}

function formatMoney(n, currency="$") {
  if(!n) return "—";
  return `${currency}${n.toLocaleString()}`;
}

function ModObras({user,onBack}) {
  const [obras, setObras]           = useState(INIT_OBRAS);
  const [view,  setView]            = useState("list");      // list | detail | etapa
  const [selectedObra, setSelectedObra] = useState(null);
  const [selectedEtapa, setSelectedEtapa] = useState(null);
  const [showNewObra,   setShowNewObra]   = useState(false);
  const [showNewUpdate, setShowNewUpdate] = useState(false);
  const [showEditEtapa, setShowEditEtapa] = useState(false);
  const [newUpdate, setNewUpdate]   = useState({ texto:"", fecha:"", fotos:[] });
  const [editEtapa, setEditEtapa]   = useState({ estado:"pendiente", fecha_estimada:"", notas:"" });
  const [draftObra, setDraftObra]   = useState({ nombre:"", ubicacion:"", responsable:"", presupuesto_total:"", fecha_inicio:"", fecha_inauguracion_estimada:"" });
  const [activeImg, setActiveImg]   = useState(null);
  const fileRef = useRef();

  const obra = selectedObra ? obras.find(o=>o.id===selectedObra) : null;
  const etapaData = selectedEtapa && obra ? obra.etapas[selectedEtapa] : null;
  const etapaMeta = selectedEtapa ? ETAPAS.find(e=>e.id===selectedEtapa) : null;

  const handleImgUpload = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        setNewUpdate(u => ({ ...u, fotos: [...u.fotos, { url: ev.target.result, name: file.name }] }));
      };
      reader.readAsDataURL(file);
    });
  };

  const publishUpdate = () => {
    if (!newUpdate.texto.trim()) return;
    setObras(prev => prev.map(o => {
      if (o.id !== selectedObra) return o;
      const updated = { ...o };
      updated.etapas = { ...updated.etapas };
      updated.etapas[selectedEtapa] = {
        ...updated.etapas[selectedEtapa],
        updates: [...updated.etapas[selectedEtapa].updates, {
          texto: newUpdate.texto,
          fecha: newUpdate.fecha || "Hoy",
          autor: "Casa Matriz",
          fotos: newUpdate.fotos,
        }],
      };
      return updated;
    }));
    setNewUpdate({ texto:"", fecha:"", fotos:[] });
    setShowNewUpdate(false);
  };

  const saveEtapa = () => {
    setObras(prev => prev.map(o => {
      if (o.id !== selectedObra) return o;
      const updated = { ...o };
      updated.etapas = { ...updated.etapas };
      updated.etapas[selectedEtapa] = {
        ...updated.etapas[selectedEtapa],
        estado: editEtapa.estado,
        fecha_estimada: editEtapa.fecha_estimada || updated.etapas[selectedEtapa].fecha_estimada,
        notas: editEtapa.notas,
        fecha_real: editEtapa.estado === "completada" ? (editEtapa.fecha_real || new Date().toISOString().split("T")[0]) : updated.etapas[selectedEtapa].fecha_real,
      };
      // update etapa_actual
      const inCurso = ETAPAS.find(e => updated.etapas[e.id]?.estado === "en_curso");
      if (inCurso) updated.etapa_actual = inCurso.id;
      return updated;
    }));
    setShowEditEtapa(false);
  };

  const addObra = () => {
    if (!draftObra.nombre.trim()) return;
    const newObra = {
      id: Date.now(),
      ...draftObra,
      presupuesto_total: draftObra.presupuesto_total ? parseInt(draftObra.presupuesto_total) : 0,
      presupuesto_ejecutado: 0,
      etapa_actual: "contrato",
      etapas: Object.fromEntries(ETAPAS.map(e => [e.id, { estado:"pendiente", fecha_real:null, fecha_estimada:"", notas:"", updates:[] }])),
    };
    setObras(prev => [newObra, ...prev]);
    setDraftObra({ nombre:"", ubicacion:"", responsable:"", presupuesto_total:"", fecha_inicio:"", fecha_inauguracion_estimada:"" });
    setShowNewObra(false);
  };

  // ── LIGHT BOX ────────────────────────────────────────────────────────────────
  if (activeImg) return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.92)",zIndex:999,display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column"}} onClick={()=>setActiveImg(null)}>
      <img src={activeImg} alt="obra" style={{maxWidth:"95vw",maxHeight:"85vh",objectFit:"contain",borderRadius:8}}/>
      <div style={{color:"rgba(255,255,255,0.5)",fontSize:10,marginTop:12,letterSpacing:2}}>TOCA PARA CERRAR</div>
    </div>
  );

  return (
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:3px;}
        ::-webkit-scrollbar-thumb{background:${B.pinkLight};}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
        @keyframes slideRight{from{transform:translateX(100%)}to{transform:translateX(0)}}
        button{cursor:pointer;border:none;font-family:inherit;}
        input,textarea{font-family:inherit;outline:none;}
        .card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(221,164,174,0.18)!important;}
      `}</style>

      {/* ── HEADER ── */}
      <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.1)",display:"flex",alignItems:"center",gap:10}}>
        {view!=="list" && (
          <button onClick={()=>{ if(view==="etapa"){setView("detail");}else{setView("list");setSelectedObra(null);} }} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 12px",fontSize:11,color:B.mid,fontWeight:700}}>←</button>
        )}
        <div style={{flex:1}}>
          <div style={{display:"flex",alignItems:"center",gap:6}}>
            <Star size={12} color={B.gold}/>
            <div style={{fontSize:14,fontWeight:300,letterSpacing:5,color:B.pink}}>NIKI BB</div>
          </div>
          <div style={{fontSize:7,letterSpacing:3,color:B.mid}}>
            {view==="list" ? "MÓDULO DE OBRAS" : view==="detail" ? obra?.nombre.toUpperCase() : etapaMeta?.label.toUpperCase()}
          </div>
        </div>
        {view==="list" && (
          <button onClick={()=>setShowNewObra(true)} style={{padding:"7px 14px",background:B.pink,border:"none",borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:2}}>+ NUEVA OBRA</button>
        )}
        {view==="detail" && (
          <button onClick={()=>setShowNewUpdate(true)} style={{padding:"7px 14px",background:B.gold,border:"none",borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:1}}>+ ACTUALIZAR</button>
        )}
      </div>

      {/* ══════════ LIST VIEW ══════════ */}
      {view==="list" && (
        <div style={{padding:"16px",paddingBottom:40,animation:"fadeUp .4s ease forwards"}}>
          {/* Summary */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginBottom:16}}>
            {[
              {label:"Obras activas", value:obras.length, icon:"🏗️"},
              {label:"En curso",      value:obras.filter(o=>Object.values(o.etapas).some(e=>e.estado==="en_curso")).length, icon:"⚡"},
              {label:"Inauguraciones",value:obras.filter(o=>o.etapas.inauguracion?.estado==="completada").length, icon:"🎉"},
            ].map((s,i)=>(
              <div key={i} style={{background:B.white,borderRadius:12,padding:"12px",border:`1px solid ${B.pinkLight}`,textAlign:"center"}}>
                <div style={{fontSize:18,marginBottom:4}}>{s.icon}</div>
                <div style={{fontFamily:"Georgia,serif",fontSize:22,color:B.text,fontWeight:300}}>{s.value}</div>
                <div style={{fontSize:8,color:B.mid,marginTop:2,letterSpacing:.5}}>{s.label}</div>
              </div>
            ))}
          </div>

          {obras.map((o,i) => {
            const etapaActual = ETAPAS.find(e=>e.id===o.etapa_actual);
            const pctPresup = o.presupuesto_total ? Math.round((o.presupuesto_ejecutado/o.presupuesto_total)*100) : 0;
            return (
              <div key={o.id} className="card" onClick={()=>{setSelectedObra(o.id);setView("detail");}} style={{background:B.white,borderRadius:14,marginBottom:12,border:`1.5px solid ${B.pinkLight}`,cursor:"pointer",overflow:"hidden",transition:"all .2s",boxShadow:"0 2px 8px rgba(221,164,174,0.07)",animation:`fadeUp .3s ease ${i*.08}s both`}}>
                {/* Color top */}
                <div style={{height:4,background:`linear-gradient(90deg,${etapaActual?.color||B.pink},${B.goldLight})`}}/>
                <div style={{padding:"16px"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                    <div>
                      <div style={{fontSize:15,fontWeight:700,color:B.text,marginBottom:3}}>{o.nombre}</div>
                      <div style={{fontSize:10,color:B.mid}}>📍 {o.ubicacion}</div>
                    </div>
                    <div style={{padding:"3px 10px",borderRadius:20,background:`${etapaActual?.color||B.pink}15`,border:`1px solid ${etapaActual?.color||B.pink}40`,fontSize:8,color:etapaActual?.color||B.pink,fontWeight:700,textAlign:"right",letterSpacing:1,flexShrink:0,maxWidth:110}}>
                      {etapaActual?.icon} {etapaActual?.label.toUpperCase()}
                    </div>
                  </div>

                  {/* Progress */}
                  <ProgressBar obra={o}/>

                  {/* Dates + budget */}
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginTop:12,padding:"10px",background:B.coolGray,borderRadius:8}}>
                    <div>
                      <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:3}}>INAUGURACIÓN EST.</div>
                      <div style={{fontSize:11,fontWeight:700,color:B.text}}>{o.fecha_inauguracion_estimada}</div>
                    </div>
                    <div>
                      <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:3}}>PRESUPUESTO</div>
                      <div style={{fontSize:11,fontWeight:700,color:B.gold}}>{pctPresup}% ejecutado</div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ══════════ DETAIL VIEW ══════════ */}
      {view==="detail" && obra && (
        <div style={{paddingBottom:80,animation:"slideRight .3s ease forwards"}}>
          {/* Hero */}
          <div style={{background:`linear-gradient(135deg,${B.dark},#1a1008)`,padding:"20px 18px",position:"relative",overflow:"hidden"}}>
            <PatternBg opacity={0.08}/>
            <div style={{position:"relative"}}>
              <div style={{fontSize:20,fontWeight:700,color:B.white,marginBottom:4}}>{obra.nombre}</div>
              <div style={{fontSize:11,color:B.mid,marginBottom:14}}>📍 {obra.ubicacion} · 👤 {obra.responsable}</div>
              {/* Budget */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
                <div style={{background:"rgba(255,255,255,0.06)",borderRadius:10,padding:"12px"}}>
                  <div style={{fontSize:8,color:B.glacier,letterSpacing:1,marginBottom:4}}>PRESUPUESTO TOTAL</div>
                  <div style={{fontFamily:"Georgia,serif",fontSize:20,color:B.goldLight,fontWeight:300}}>{formatMoney(obra.presupuesto_total)}</div>
                </div>
                <div style={{background:"rgba(255,255,255,0.06)",borderRadius:10,padding:"12px"}}>
                  <div style={{fontSize:8,color:B.glacier,letterSpacing:1,marginBottom:4}}>EJECUTADO</div>
                  <div style={{fontFamily:"Georgia,serif",fontSize:20,color:obra.presupuesto_ejecutado/obra.presupuesto_total>0.8?"#E88":"#5A9E6E",fontWeight:300}}>
                    {formatMoney(obra.presupuesto_ejecutado)}
                  </div>
                </div>
              </div>
              <ProgressBar obra={obra}/>
            </div>
          </div>

          {/* Timeline */}
          <div style={{padding:"18px 16px"}}>
            <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:16}}>LÍNEA DE TIEMPO</div>
            <div style={{position:"relative"}}>
              {/* Vertical line */}
              <div style={{position:"absolute",left:19,top:0,bottom:0,width:2,background:B.pinkLight,zIndex:0}}/>

              {ETAPAS.map((etapa, idx) => {
                const ed = obra.etapas[etapa.id];
                const isActual = obra.etapa_actual === etapa.id;
                const isDone   = ed.estado === "completada";
                const isDelayed = ed.estado === "demorada";
                const circleColor = isDone ? B.green : isActual ? etapa.color : isDelayed ? "#C0392B" : B.glacier;

                return (
                  <div key={etapa.id} style={{display:"flex",gap:14,marginBottom:0,position:"relative",zIndex:1}}>
                    {/* Circle */}
                    <div style={{
                      width:40,height:40,borderRadius:"50%",flexShrink:0,
                      background:isDone?B.greenPale:isActual?`${etapa.color}18`:`rgba(255,255,255,0.8)`,
                      border:`2.5px solid ${circleColor}`,
                      display:"flex",alignItems:"center",justifyContent:"center",
                      fontSize:isDone?16:14,
                      boxShadow:isActual?`0 0 0 4px ${etapa.color}20`:"none",
                      transition:"all .3s",
                      zIndex:2,position:"relative",
                    }}>
                      {isDone ? "✓" : etapa.icon}
                    </div>

                    {/* Content */}
                    <div style={{flex:1,paddingBottom:idx<ETAPAS.length-1?20:0}}>
                      <button
                        onClick={()=>{setSelectedEtapa(etapa.id);setEditEtapa({estado:ed.estado,fecha_estimada:ed.fecha_estimada,notas:ed.notas,fecha_real:ed.fecha_real||""});setView("etapa");}}
                        style={{width:"100%",background:isActual?B.white:"transparent",border:isActual?`1.5px solid ${etapa.color}40`:`1px solid ${isDone?B.green+"30":"transparent"}`,borderRadius:12,padding:"12px 14px",textAlign:"left",transition:"all .2s",cursor:"pointer",boxShadow:isActual?`0 4px 14px ${etapa.color}15`:"none"}}
                      >
                        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:6}}>
                          <div style={{fontSize:12,fontWeight:isActual?700:500,color:isActual?etapa.color:isDone?B.green:B.text}}>{etapa.label}</div>
                          <EstadoBadge estado={ed.estado}/>
                          {isActual && <div style={{fontSize:8,color:etapa.color,fontWeight:700,letterSpacing:1,marginLeft:"auto"}}>ACTUAL ›</div>}
                        </div>
                        <div style={{display:"flex",gap:16}}>
                          {ed.fecha_estimada && (
                            <div>
                              <div style={{fontSize:7,color:B.mid,letterSpacing:1}}>ESTIMADA</div>
                              <div style={{fontSize:10,color:B.text,marginTop:1}}>{ed.fecha_estimada}</div>
                            </div>
                          )}
                          {ed.fecha_real && (
                            <div>
                              <div style={{fontSize:7,color:B.green,letterSpacing:1}}>REAL</div>
                              <div style={{fontSize:10,color:B.green,fontWeight:700,marginTop:1}}>{ed.fecha_real}</div>
                            </div>
                          )}
                          {ed.updates.length>0 && (
                            <div style={{marginLeft:"auto",fontSize:9,color:B.mid}}>💬 {ed.updates.length} actualizaciones</div>
                          )}
                        </div>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Onboarding notice */}
            <div style={{marginTop:8,padding:"14px 16px",background:B.goldPale,borderRadius:12,border:`1px solid ${B.goldLight}40`,display:"flex",gap:10,alignItems:"flex-start"}}>
              <div style={{fontSize:20,flexShrink:0}}>🎓</div>
              <div>
                <div style={{fontSize:10,fontWeight:700,color:B.gold,letterSpacing:1,marginBottom:4}}>PRÓXIMA ETAPA POST-INAUGURACIÓN</div>
                <div style={{fontSize:11,color:B.text,lineHeight:1.5}}>Una vez inaugurado el local, arranca automáticamente el circuito de <strong>Onboarding & Capacitación</strong> con el equipo de RRHH.</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════ ETAPA DETAIL VIEW ══════════ */}
      {view==="etapa" && obra && etapaData && etapaMeta && (
        <div style={{paddingBottom:100,animation:"slideRight .3s ease forwards"}}>
          {/* Etapa hero */}
          <div style={{background:B.white,padding:"16px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"relative",overflow:"hidden"}}>
            <PatternBg opacity={0.04}/>
            <div style={{position:"relative"}}>
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                <div style={{width:42,height:42,borderRadius:"50%",background:`${etapaMeta.color}15`,border:`2px solid ${etapaMeta.color}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20}}>{etapaMeta.icon}</div>
                <div>
                  <div style={{fontSize:15,fontWeight:700,color:B.text}}>{etapaMeta.label}</div>
                  <div style={{fontSize:10,color:B.mid,marginTop:2}}>{obra.nombre}</div>
                </div>
                <div style={{marginLeft:"auto"}}><EstadoBadge estado={etapaData.estado}/></div>
              </div>
              <div style={{display:"flex",gap:12}}>
                {etapaData.fecha_estimada && <div><div style={{fontSize:7,color:B.mid,letterSpacing:1}}>FECHA ESTIMADA</div><div style={{fontSize:10,color:B.text,marginTop:1}}>{etapaData.fecha_estimada}</div></div>}
                {etapaData.fecha_real     && <div><div style={{fontSize:7,color:B.green,letterSpacing:1}}>FECHA REAL</div><div style={{fontSize:10,color:B.green,fontWeight:700,marginTop:1}}>{etapaData.fecha_real}</div></div>}
              </div>
              {etapaData.notas && <div style={{marginTop:8,fontSize:11,color:B.mid,fontStyle:"italic"}}>{etapaData.notas}</div>}
            </div>
          </div>

          <div style={{padding:"16px"}}>
            {/* Edit estado */}
            <button onClick={()=>setShowEditEtapa(true)} style={{width:"100%",marginBottom:16,padding:"12px",background:B.goldPale,border:`1px solid ${B.goldLight}40`,borderRadius:10,display:"flex",alignItems:"center",justifyContent:"space-between",color:B.gold,fontSize:10,fontWeight:700,letterSpacing:1}}>
              <span>✦ EDITAR ESTADO Y FECHAS</span><span>›</span>
            </button>

            {/* Updates timeline */}
            <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:14}}>
              ACTUALIZACIONES ({etapaData.updates.length})
            </div>

            {etapaData.updates.length===0 && (
              <div style={{textAlign:"center",padding:"40px 20px",color:B.mid}}>
                <div style={{fontSize:32,marginBottom:10}}>📸</div>
                <div style={{fontSize:12}}>Aún no hay actualizaciones para esta etapa</div>
                <div style={{fontSize:10,marginTop:4,color:B.glacier}}>Cargá la primera foto o novedad</div>
              </div>
            )}

            {[...etapaData.updates].reverse().map((u, i) => (
              <div key={i} style={{background:B.white,borderRadius:14,marginBottom:12,border:`1px solid ${B.pinkLight}`,overflow:"hidden",animation:`fadeUp .3s ease ${i*.05}s both`}}>
                <div style={{padding:"13px 15px"}}>
                  <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
                    <div style={{width:26,height:26,borderRadius:"50%",background:`${B.gold}15`,border:`1.5px solid ${B.gold}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:B.gold}}>✦</div>
                    <div>
                      <div style={{fontSize:10,fontWeight:700,color:B.text}}>{u.autor}</div>
                      <div style={{fontSize:8,color:B.mid}}>{u.fecha}</div>
                    </div>
                  </div>
                  <div style={{fontSize:13,color:B.text,lineHeight:1.6,marginBottom: u.fotos?.length>0?12:0}}>{u.texto}</div>
                  {/* Fotos */}
                  {u.fotos?.length>0 && (
                    <div style={{display:"grid",gridTemplateColumns:u.fotos.length===1?"1fr":"1fr 1fr",gap:6}}>
                      {u.fotos.map((f,fi)=>(
                        <div key={fi} onClick={()=>setActiveImg(f.url)} style={{borderRadius:8,overflow:"hidden",cursor:"pointer",aspectRatio:"4/3",position:"relative"}}>
                          <img src={f.url} alt={f.name} style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}}/>
                          <div style={{position:"absolute",inset:0,background:"rgba(0,0,0,0)",transition:"background .2s"}}/>
                          <div style={{position:"absolute",bottom:4,right:6,fontSize:8,color:"rgba(255,255,255,0.7)"}}>🔍</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* FAB agregar update */}
          <button onClick={()=>setShowNewUpdate(true)} style={{position:"fixed",bottom:24,right:"calc(50% - 197px)",padding:"12px 20px",borderRadius:28,background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,boxShadow:`0 6px 20px ${B.pink}55`,color:B.white,fontSize:10,fontWeight:700,letterSpacing:2,display:"flex",alignItems:"center",gap:8,zIndex:100}}>
            <Star size={10} color={B.white}/> CARGAR ACTUALIZACIÓN
          </button>
        </div>
      )}

      {/* ══════════ MODALS ══════════ */}

      {/* New Update */}
      {showNewUpdate && (
        <div style={{position:"fixed",inset:0,zIndex:300,background:"rgba(42,32,32,0.55)",display:"flex",alignItems:"flex-end"}} onClick={()=>setShowNewUpdate(false)}>
          <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:430,margin:"0 auto",background:B.white,borderRadius:"20px 20px 0 0",padding:"22px 18px 36px",animation:"slideUp .3s ease",maxHeight:"92vh",overflowY:"auto"}}>
            <div style={{display:"flex",alignItems:"center",marginBottom:18}}>
              <Star size={12} color={B.gold}/>
              <div style={{fontSize:12,fontWeight:700,color:B.text,letterSpacing:2,marginLeft:8}}>NUEVA ACTUALIZACIÓN</div>
              <button onClick={()=>setShowNewUpdate(false)} style={{marginLeft:"auto",background:"transparent",color:B.mid,fontSize:20}}>×</button>
            </div>

            {/* Etapa selector si estamos en detail */}
            {view==="detail" && (
              <div style={{marginBottom:14}}>
                <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>ETAPA</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                  {ETAPAS.map(e=>(
                    <button key={e.id} onClick={()=>setSelectedEtapa(e.id)} style={{padding:"4px 12px",borderRadius:20,fontSize:8,fontWeight:700,letterSpacing:1,background:selectedEtapa===e.id?e.color:B.coolGray,color:selectedEtapa===e.id?B.white:B.mid,border:`1px solid ${selectedEtapa===e.id?e.color:B.glacier}`,transition:"all .2s"}}>{e.label}</button>
                  ))}
                </div>
              </div>
            )}

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>DESCRIPCIÓN</div>
              <textarea value={newUpdate.texto} onChange={e=>setNewUpdate(u=>({...u,texto:e.target.value}))} placeholder="¿Qué pasó en esta etapa? Describí el avance..." rows={4} style={{width:"100%",padding:"11px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:13,color:B.text,lineHeight:1.6,resize:"none",background:B.pinkBg}}/>
            </div>

            <div style={{marginBottom:14}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>FECHA</div>
              <input type="date" value={newUpdate.fecha} onChange={e=>setNewUpdate(u=>({...u,fecha:e.target.value}))} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:13,color:B.text,background:B.pinkBg}}/>
            </div>

            {/* Fotos */}
            <div style={{marginBottom:18}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>FOTOS</div>
              <div onClick={()=>fileRef.current?.click()} style={{border:`2px dashed ${newUpdate.fotos.length>0?B.pink:B.glacier}`,borderRadius:10,padding:"16px",textAlign:"center",cursor:"pointer",background:B.pinkBg,marginBottom:8}}>
                <div style={{fontSize:20,marginBottom:4}}>📸</div>
                <div style={{fontSize:10,color:B.mid}}>Tocá para agregar fotos de la obra</div>
                <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleImgUpload} style={{display:"none"}}/>
              </div>
              {newUpdate.fotos.length>0 && (
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:6}}>
                  {newUpdate.fotos.map((f,i)=>(
                    <div key={i} style={{borderRadius:8,overflow:"hidden",aspectRatio:"1",position:"relative"}}>
                      <img src={f.url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                      <button onClick={()=>setNewUpdate(u=>({...u,fotos:u.fotos.filter((_,fi)=>fi!==i)}))} style={{position:"absolute",top:3,right:3,width:18,height:18,borderRadius:"50%",background:"rgba(0,0,0,0.6)",color:"white",fontSize:10,display:"flex",alignItems:"center",justifyContent:"center"}}>×</button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <button onClick={publishUpdate} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:`0 5px 16px ${B.pink}40`}}>
              <Star size={10} color={B.white}/> PUBLICAR ACTUALIZACIÓN
            </button>
          </div>
        </div>
      )}

      {/* Edit Etapa */}
      {showEditEtapa && (
        <div style={{position:"fixed",inset:0,zIndex:300,background:"rgba(42,32,32,0.55)",display:"flex",alignItems:"flex-end"}} onClick={()=>setShowEditEtapa(false)}>
          <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:430,margin:"0 auto",background:B.white,borderRadius:"20px 20px 0 0",padding:"22px 18px 36px",animation:"slideUp .3s ease"}}>
            <div style={{display:"flex",alignItems:"center",marginBottom:18}}>
              <Star size={12} color={B.gold}/>
              <div style={{fontSize:12,fontWeight:700,color:B.text,letterSpacing:2,marginLeft:8}}>EDITAR ETAPA</div>
              <button onClick={()=>setShowEditEtapa(false)} style={{marginLeft:"auto",background:"transparent",color:B.mid,fontSize:20}}>×</button>
            </div>

            <div style={{marginBottom:14}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>ESTADO</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                {ESTADOS.map(s=>(
                  <button key={s.id} onClick={()=>setEditEtapa(e=>({...e,estado:s.id}))} style={{padding:"10px",background:editEtapa.estado===s.id?`${s.color}18`:B.coolGray,border:`2px solid ${editEtapa.estado===s.id?s.color:B.glacier}`,borderRadius:9,fontSize:10,color:editEtapa.estado===s.id?s.color:B.mid,fontWeight:700,transition:"all .2s"}}>{s.label}</button>
                ))}
              </div>
            </div>

            <div style={{marginBottom:14}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>FECHA ESTIMADA</div>
              <input type="date" value={editEtapa.fecha_estimada} onChange={e=>setEditEtapa(ed=>({...ed,fecha_estimada:e.target.value}))} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:13,color:B.text,background:B.pinkBg}}/>
            </div>

            {editEtapa.estado==="completada" && (
              <div style={{marginBottom:14}}>
                <div style={{fontSize:8,letterSpacing:2,color:B.green,fontWeight:700,marginBottom:7}}>FECHA REAL DE COMPLETADO</div>
                <input type="date" value={editEtapa.fecha_real||""} onChange={e=>setEditEtapa(ed=>({...ed,fecha_real:e.target.value}))} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.green}50`,borderRadius:9,fontSize:13,color:B.text,background:B.greenPale}}/>
              </div>
            )}

            <div style={{marginBottom:18}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>NOTAS</div>
              <textarea value={editEtapa.notas} onChange={e=>setEditEtapa(ed=>({...ed,notas:e.target.value}))} placeholder="Notas sobre esta etapa..." rows={2} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,lineHeight:1.5,resize:"none",background:B.pinkBg}}/>
            </div>

            <button onClick={saveEtapa} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.gold},${B.goldLight})`,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:`0 5px 16px ${B.gold}40`}}>
              <Star size={10} color={B.white}/> GUARDAR CAMBIOS
            </button>
          </div>
        </div>
      )}

      {/* New Obra */}
      {showNewObra && (
        <div style={{position:"fixed",inset:0,zIndex:300,background:"rgba(42,32,32,0.55)",display:"flex",alignItems:"flex-end"}} onClick={()=>setShowNewObra(false)}>
          <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:430,margin:"0 auto",background:B.white,borderRadius:"20px 20px 0 0",padding:"22px 18px 36px",animation:"slideUp .3s ease",maxHeight:"92vh",overflowY:"auto"}}>
            <div style={{display:"flex",alignItems:"center",marginBottom:18}}>
              <Star size={12} color={B.gold}/>
              <div style={{fontSize:12,fontWeight:700,color:B.text,letterSpacing:2,marginLeft:8}}>NUEVA OBRA</div>
              <button onClick={()=>setShowNewObra(false)} style={{marginLeft:"auto",background:"transparent",color:B.mid,fontSize:20}}>×</button>
            </div>

            {[
              {key:"nombre",       label:"NOMBRE DEL LOCAL",       placeholder:"Ej: Palermo Soho II"},
              {key:"ubicacion",    label:"UBICACIÓN",              placeholder:"Ej: Palermo, Buenos Aires"},
              {key:"responsable",  label:"RESPONSABLE",            placeholder:"Ej: Casa Matriz / Franquiciada"},
            ].map(f=>(
              <div key={f.key} style={{marginBottom:12}}>
                <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>{f.label}</div>
                <input value={draftObra[f.key]} onChange={e=>setDraftObra(d=>({...d,[f.key]:e.target.value}))} placeholder={f.placeholder} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,background:B.pinkBg}}/>
              </div>
            ))}

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>PRESUPUESTO TOTAL</div>
              <div style={{display:"flex",alignItems:"center"}}>
                <div style={{padding:"10px 11px",background:B.goldPale,border:`1.5px solid ${B.pinkLight}`,borderRadius:"9px 0 0 9px",fontSize:12,color:B.gold,fontWeight:700,borderRight:"none"}}>$</div>
                <input type="number" value={draftObra.presupuesto_total} onChange={e=>setDraftObra(d=>({...d,presupuesto_total:e.target.value}))} placeholder="0" style={{flex:1,padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:"0 9px 9px 0",fontSize:12,color:B.text,background:B.pinkBg}}/>
              </div>
            </div>

            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:18}}>
              <div>
                <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>INICIO</div>
                <input type="date" value={draftObra.fecha_inicio} onChange={e=>setDraftObra(d=>({...d,fecha_inicio:e.target.value}))} style={{width:"100%",padding:"9px 10px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:11,color:B.text,background:B.pinkBg}}/>
              </div>
              <div>
                <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>INAUGURACIÓN EST.</div>
                <input type="date" value={draftObra.fecha_inauguracion_estimada} onChange={e=>setDraftObra(d=>({...d,fecha_inauguracion_estimada:e.target.value}))} style={{width:"100%",padding:"9px 10px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:11,color:B.text,background:B.pinkBg}}/>
              </div>
            </div>

            <button onClick={addObra} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:`0 5px 16px ${B.pink}40`}}>
              <Star size={10} color={B.white}/> CREAR OBRA
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MODRRHH ───────────────────────────────────────────────────────────
const TURNOS = [
  { id:"manana", label:"Mañana", horario:"10:00 - 15:00", hs:5, color:B.gold    },
  { id:"tarde",  label:"Tarde",  horario:"15:00 - 20:00", hs:5, color:B.pink    },
];

const DIAS = ["Lun","Mar","Mié","Jue","Vie","Sáb"];
const DIAS_FULL = ["Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"];

const LOCALES_RRHH = ["Puerto Madero","Lomas","Palermo","Recoleta","Belgrano","Saavedra","Cañitas","Mendoza","Canning","Banfield"];

const MESES = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

// Mes actual = Abril (idx 3), carga para Mayo (idx 4)
const MES_ACTUAL = 3;
const MES_CARGA  = 4;

// ─── DATA INICIAL ─────────────────────────────────────────────────────────────
const INIT_VACANTES = [
  { id:1, local:"Puerto Madero", turno:"tarde",  puesto:"Manicura Senior",   descripcion:"Buscamos manicura con experiencia en técnicas de gel y nail art. Excelente presentación.", requisitos:["2+ años de experiencia","Conocimiento en gel y acrílico","Disponibilidad tarde"], estado:"activa",  fecha:"15 Apr", postulantes:3 },
  { id:2, local:"Lomas",         turno:"manana", puesto:"Manicura",          descripcion:"Incorporamos manicura para turno mañana en local de Lomas. Capacitación incluida.",         requisitos:["Experiencia básica","Disponibilidad mañana","Compromiso con la marca"], estado:"activa",  fecha:"18 Apr", postulantes:1 },
  { id:3, local:"Palermo",       turno:"tarde",  puesto:"Manicura Nail Art", descripcion:"Especialista en nail art para nuestro local de Palermo. Portfolio requerido.",              requisitos:["Portfolio de diseños","Experiencia en nail art","Redes activas"], estado:"activa",  fecha:"20 Apr", postulantes:5 },
  { id:4, local:"Belgrano",      turno:"manana", puesto:"Manicura",          descripcion:"Búsqueda para cubrir licencia maternal. 3 meses con posibilidad de continuar.",            requisitos:["Flexibilidad horaria","Buena energía","Trabajo en equipo"], estado:"cubierta",fecha:"01 Apr", postulantes:7 },
];

const INIT_PERSONAS = [
  { id:1, nombre:"Valentina Ríos",   local:"Puerto Madero", rol:"manicura",    foto:null, turno_pref:"tarde",  activa:true  },
  { id:2, nombre:"Camila Torres",    local:"Lomas",         rol:"manicura",    foto:null, turno_pref:"manana", activa:true  },
  { id:3, nombre:"Sofía Méndez",     local:"Palermo",       rol:"manicura",    foto:null, turno_pref:"tarde",  activa:true  },
  { id:4, nombre:"Lucía Fernández",  local:"Puerto Madero", rol:"manicura",    foto:null, turno_pref:"manana", activa:true  },
  { id:5, nombre:"Martina López",    local:"Lomas",         rol:"encargada",   foto:null, turno_pref:"manana", activa:true  },
  { id:6, nombre:"Agustina Ruiz",    local:"Palermo",       rol:"manicura",    foto:null, turno_pref:"tarde",  activa:true  },
];

// Semanas de Mayo 2026 (simplificado: 4 semanas, 6 días c/u)
const SEMANAS_MAYO = [
  { id:1, label:"Semana 1", dias:["May 4","May 5","May 6","May 7","May 8","May 9"]   },
  { id:2, label:"Semana 2", dias:["May 11","May 12","May 13","May 14","May 15","May 16"] },
  { id:3, label:"Semana 3", dias:["May 18","May 19","May 20","May 21","May 22","May 23"] },
  { id:4, label:"Semana 4", dias:["May 25","May 26","May 27","May 28","May 29","May 30"] },
];

// Turnos cargados para Mayo (persona_id → {semana_dia: turno_id})
const INIT_TURNOS_CARGADOS = {
  1: { "1-0":"tarde","1-1":"tarde","1-3":"tarde","1-4":"tarde","2-0":"tarde","2-2":"tarde","2-4":"tarde","3-1":"tarde","3-3":"tarde","3-5":"tarde","4-0":"tarde","4-2":"tarde","4-4":"tarde" },
  2: { "1-0":"manana","1-2":"manana","1-4":"manana","2-1":"manana","2-3":"manana","2-5":"manana","3-0":"manana","3-2":"manana","3-4":"manana","4-1":"manana","4-3":"manana","4-5":"manana" },
  4: { "1-1":"manana","1-3":"manana","2-0":"manana","2-2":"manana","2-4":"manana","3-1":"manana","3-3":"manana" },
};

const ADHESION_HIST = [
  { mes:"Enero",    total:6, cumplieron:6, promedio_hs:38 },
  { mes:"Febrero",  total:6, cumplieron:5, promedio_hs:36 },
  { mes:"Marzo",    total:6, cumplieron:6, promedio_hs:39 },
  { mes:"Abril",    total:6, cumplieron:4, promedio_hs:35 },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────


function Avatar({ persona, size=36, onClick }) {
  return (
    <div onClick={onClick} style={{
      width:size, height:size, borderRadius:"50%", flexShrink:0,
      background: persona.foto ? "transparent" : `${B.pink}20`,
      border:`2px solid ${B.pinkLight}`,
      overflow:"hidden", cursor:onClick?"pointer":"default",
      display:"flex", alignItems:"center", justifyContent:"center",
      fontSize:size*0.38, color:B.pink, fontWeight:700,
    }}>
      {persona.foto
        ? <img src={persona.foto} alt={persona.nombre} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
        : persona.nombre.split(" ").map(n=>n[0]).slice(0,2).join("")
      }
    </div>
  );
}

function calcHoras(turnosCargados) {
  return Object.values(turnosCargados || {}).length * 5;
}

function calcHorasSemanales(turnosCargados, semanaId) {
  return Object.entries(turnosCargados || {}).filter(([k]) => k.startsWith(`${semanaId}-`)).length * 5;
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
function ModRRHH({user,onBack}) {
  const [tab,          setTab]          = useState("vacantes");
  const [vacantes,     setVacantes]     = useState(INIT_VACANTES);
  const [personas,     setPersonas]     = useState(INIT_PERSONAS);
  const [turnosCarg,   setTurnosCarg]   = useState(INIT_TURNOS_CARGADOS);
  const [localFilter,  setLocalFilter]  = useState("Puerto Madero");
  const [semanaView,   setSemanaView]   = useState(1);
  const [selectedP,    setSelectedP]    = useState(null);
  const [showPerfil,   setShowPerfil]   = useState(false);
  const [showNuevaVac, setShowNuevaVac] = useState(false);
  const [showNuevaP,   setShowNuevaP]   = useState(false);
  const [draftVac,     setDraftVac]     = useState({local:"Puerto Madero",turno:"tarde",puesto:"",descripcion:"",requisitos:""});
  const [draftP,       setDraftP]       = useState({nombre:"",local:"Puerto Madero",rol:"manicura",turno_pref:"tarde"});
  const [editFoto,     setEditFoto]     = useState(null);
  const fotoRef = useRef();
  const fotoNuevaRef = useRef();

  // Carga abierta del 1 al 5 del mes
  const hoy = new Date();
  const diaHoy = hoy.getDate();
  const cargaAbierta = diaHoy >= 1 && diaHoy <= 5;

  const personasLocal = personas.filter(p => p.local === localFilter && p.activa);
  const semana = SEMANAS_MAYO.find(s => s.id === semanaView);

  const toggleTurno = (personaId, semanaId, diaIdx, turnoId) => {
    const key = `${semanaId}-${diaIdx}`;
    setTurnosCarg(prev => {
      const curr = { ...(prev[personaId] || {}) };
      if (curr[key] === turnoId) {
        delete curr[key];
      } else {
        curr[key] = turnoId;
      }
      return { ...prev, [personaId]: curr };
    });
  };

  const handleFotoUpload = (e, personaId) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setPersonas(prev => prev.map(p => p.id === personaId ? { ...p, foto: ev.target.result } : p));
    };
    reader.readAsDataURL(file);
  };

  const addVacante = () => {
    if (!draftVac.puesto.trim()) return;
    setVacantes(prev => [{
      id: Date.now(), ...draftVac,
      requisitos: draftVac.requisitos.split("\n").filter(r => r.trim()),
      estado: "activa", fecha: "Hoy", postulantes: 0,
    }, ...prev]);
    setDraftVac({local:"Puerto Madero",turno:"tarde",puesto:"",descripcion:"",requisitos:""});
    setShowNuevaVac(false);
  };

  const addPersona = () => {
    if (!draftP.nombre.trim()) return;
    setPersonas(prev => [...prev, { id: Date.now(), ...draftP, foto: null, activa: true }]);
    setDraftP({nombre:"",local:"Puerto Madero",rol:"manicura",turno_pref:"tarde"});
    setShowNuevaP(false);
  };

  const personaSelec = selectedP ? personas.find(p => p.id === selectedP) : null;

  const TABS = [
    { id:"vacantes",  label:"Vacantes",  icon:"🔍" },
    { id:"calendario",label:"Calendario",icon:"📅" },
    { id:"adhesion",  label:"Adhesión",  icon:"📊" },
    { id:"equipo",    label:"Equipo",    icon:"👥" },
  ];

  return (
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        ::-webkit-scrollbar{width:3px;}
        ::-webkit-scrollbar-thumb{background:${B.pinkLight};}
        @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        @keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
        button{cursor:pointer;border:none;font-family:inherit;}
        input,textarea,select{font-family:inherit;outline:none;}
        .card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(221,164,174,0.18)!important;}
        .turno-cell:hover{opacity:.85;}
      `}</style>

      {/* ── HEADER ── */}
      <div style={{background:B.white,padding:"14px 18px 0",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.1)"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <Star size={13} color={B.gold}/>
            <div>
              <div style={{fontSize:14,fontWeight:300,letterSpacing:5,color:B.pink,lineHeight:1}}>NIKI OS</div>
              <div style={{fontSize:7,letterSpacing:3,color:B.mid}}>RRHH & TURNOS</div>
            </div>
          </div>
          <div style={{display:"flex",gap:8}}>
            {tab==="vacantes" && <button onClick={()=>setShowNuevaVac(true)} style={{padding:"6px 12px",background:B.pink,borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:1}}>+ VACANTE</button>}
            {tab==="equipo"   && <button onClick={()=>setShowNuevaP(true)}   style={{padding:"6px 12px",background:B.gold,borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:1}}>+ PERSONA</button>}
          </div>
        </div>
        <div style={{display:"flex"}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"8px 0 10px",background:"transparent",borderBottom:`2.5px solid ${tab===t.id?B.pink:"transparent"}`,color:tab===t.id?B.pink:B.mid,fontSize:8,fontWeight:tab===t.id?700:400,letterSpacing:.5,transition:"all .2s"}}>
              <div style={{fontSize:12,marginBottom:2}}>{t.icon}</div>
              {t.label.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* ══════════ VACANTES ══════════ */}
      {tab==="vacantes" && (
        <div style={{padding:"14px 14px 40px",animation:"fadeUp .4s ease forwards"}}>
          {/* Summary */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:14}}>
            {[
              {label:"Activas",   value:vacantes.filter(v=>v.estado==="activa").length,   color:B.pink,  icon:"🔍"},
              {label:"Cubiertas", value:vacantes.filter(v=>v.estado==="cubierta").length, color:B.green, icon:"✅"},
              {label:"Postulantes",value:vacantes.reduce((a,v)=>a+v.postulantes,0),       color:B.gold,  icon:"👩"},
            ].map((s,i)=>(
              <div key={i} style={{background:B.white,borderRadius:12,padding:"12px 10px",border:`1px solid ${B.pinkLight}`,textAlign:"center"}}>
                <div style={{fontSize:16,marginBottom:4}}>{s.icon}</div>
                <div style={{fontFamily:"Georgia,serif",fontSize:22,color:s.color,fontWeight:300}}>{s.value}</div>
                <div style={{fontSize:8,color:B.mid,marginTop:2}}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Activas */}
          <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:10}}>BÚSQUEDAS ACTIVAS</div>
          {vacantes.filter(v=>v.estado==="activa").map((v,i)=>{
            const t = TURNOS.find(t=>t.id===v.turno);
            return (
              <div key={v.id} className="card" style={{background:B.white,borderRadius:14,marginBottom:10,border:`1.5px solid ${B.pinkLight}`,overflow:"hidden",transition:"all .2s",boxShadow:"0 2px 8px rgba(221,164,174,0.07)",animation:`fadeUp .3s ease ${i*.06}s both`}}>
                <div style={{height:3,background:`linear-gradient(90deg,${t.color},${B.goldLight})`}}/>
                <div style={{padding:"14px 16px"}}>
                  <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",marginBottom:8}}>
                    <div>
                      <div style={{fontSize:14,fontWeight:700,color:B.text,marginBottom:3}}>{v.puesto}</div>
                      <div style={{fontSize:10,color:B.mid}}>📍 {v.local}</div>
                    </div>
                    <div style={{display:"flex",flexDirection:"column",gap:4,alignItems:"flex-end"}}>
                      <div style={{padding:"3px 10px",borderRadius:20,background:`${t.color}15`,border:`1px solid ${t.color}40`,fontSize:8,color:t.color,fontWeight:700}}>{t.label.toUpperCase()} · {t.horario}</div>
                      <div style={{padding:"3px 10px",borderRadius:20,background:B.greenPale,border:`1px solid ${B.green}40`,fontSize:8,color:B.green,fontWeight:700}}>ACTIVA</div>
                    </div>
                  </div>
                  <div style={{fontSize:12,color:B.mid,lineHeight:1.5,marginBottom:10}}>{v.descripcion}</div>
                  {v.requisitos.length>0 && (
                    <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:10}}>
                      {v.requisitos.map((r,ri)=>(
                        <div key={ri} style={{padding:"3px 10px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:9,color:B.mid}}>✓ {r}</div>
                      ))}
                    </div>
                  )}
                  <div style={{display:"flex",alignItems:"center",paddingTop:8,borderTop:`1px solid ${B.coolGray}`}}>
                    <div style={{fontSize:9,color:B.mid}}>Publicada {v.fecha}</div>
                    <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:6}}>
                      <div style={{fontSize:9,color:B.mid}}>👩 {v.postulantes} postulantes</div>
                      <button onClick={()=>setVacantes(prev=>prev.map(vv=>vv.id===v.id?{...vv,estado:"cubierta"}:vv))} style={{padding:"4px 10px",background:B.greenPale,border:`1px solid ${B.green}40`,borderRadius:20,fontSize:8,color:B.green,fontWeight:700}}>CUBRIR</button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Cubiertas */}
          {vacantes.filter(v=>v.estado==="cubierta").length>0 && (
            <>
              <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,margin:"16px 0 10px"}}>CUBIERTAS</div>
              {vacantes.filter(v=>v.estado==="cubierta").map((v,i)=>(
                <div key={v.id} style={{background:B.white,borderRadius:12,marginBottom:8,border:`1px solid ${B.glacier}`,padding:"12px 14px",opacity:.7}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <div>
                      <div style={{fontSize:12,fontWeight:700,color:B.text}}>{v.puesto}</div>
                      <div style={{fontSize:10,color:B.mid}}>📍 {v.local}</div>
                    </div>
                    <div style={{padding:"3px 10px",borderRadius:20,background:B.coolGray,fontSize:8,color:B.mid,fontWeight:700}}>CUBIERTA ✓</div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      )}

      {/* ══════════ CALENDARIO ══════════ */}
      {tab==="calendario" && (
        <div style={{animation:"fadeUp .4s ease forwards"}}>
          {/* Carga status */}
          <div style={{padding:"12px 14px",background:cargaAbierta?B.greenPale:B.goldPale,borderBottom:`1px solid ${cargaAbierta?B.green+"30":B.goldLight+"40"}`,display:"flex",alignItems:"center",gap:10}}>
            <div style={{fontSize:16}}>{cargaAbierta?"✅":"🔒"}</div>
            <div>
              <div style={{fontSize:10,fontWeight:700,color:cargaAbierta?B.green:B.gold,letterSpacing:1}}>
                {cargaAbierta?"CARGA ABIERTA — Mayo 2026":"CARGA CERRADA"}
              </div>
              <div style={{fontSize:9,color:B.mid,marginTop:1}}>
                {cargaAbierta?"Del 1 al 5 de cada mes. ¡Completá tus turnos!":"La carga se abre del 1 al 5 de cada mes"}
              </div>
            </div>
          </div>

          {/* Local selector */}
          <div style={{padding:"10px 14px",background:B.white,borderBottom:`1px solid ${B.pinkLight}`}}>
            <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:8}}>LOCAL</div>
            <div style={{display:"flex",gap:7,overflowX:"auto",scrollbarWidth:"none"}}>
              {LOCALES_RRHH.map(l=>(
                <button key={l} onClick={()=>setLocalFilter(l)} style={{padding:"5px 12px",borderRadius:20,fontSize:9,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:localFilter===l?B.pink:B.coolGray,color:localFilter===l?B.white:B.mid,border:`1px solid ${localFilter===l?B.pink:B.glacier}`,transition:"all .2s"}}>{l}</button>
              ))}
            </div>
          </div>

          {/* Semana selector */}
          <div style={{padding:"10px 14px",background:B.white,borderBottom:`1px solid ${B.pinkLight}`,display:"flex",gap:8}}>
            {SEMANAS_MAYO.map(s=>(
              <button key={s.id} onClick={()=>setSemanaView(s.id)} style={{flex:1,padding:"7px 4px",borderRadius:8,fontSize:9,fontWeight:semanaView===s.id?700:400,background:semanaView===s.id?B.pink:B.coolGray,color:semanaView===s.id?B.white:B.mid,border:`1px solid ${semanaView===s.id?B.pink:B.glacier}`,transition:"all .2s"}}>{s.label}</button>
            ))}
          </div>

          <div style={{padding:"14px",paddingBottom:40}}>
            {/* Mayo header */}
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
              <div style={{fontSize:13,fontWeight:700,color:B.text}}>Mayo 2026 — {semana?.label}</div>
              <div style={{fontSize:9,color:B.mid}}>{semana?.dias[0]} al {semana?.dias[5]}</div>
            </div>

            {/* Días header */}
            <div style={{display:"grid",gridTemplateColumns:"80px repeat(6,1fr)",gap:3,marginBottom:6}}>
              <div/>
              {DIAS.map((d,i)=>(
                <div key={i} style={{textAlign:"center",fontSize:8,fontWeight:700,color:B.mid,letterSpacing:.5}}>
                  <div>{d}</div>
                  <div style={{fontSize:7,color:B.glacier,marginTop:1}}>{semana?.dias[i].split(" ")[1]}</div>
                </div>
              ))}
            </div>

            {/* Personas del local */}
            {personasLocal.length===0 && (
              <div style={{textAlign:"center",padding:"40px 20px",color:B.mid}}>
                <div style={{fontSize:28,marginBottom:8}}>👥</div>
                <div style={{fontSize:12}}>No hay personas en este local</div>
              </div>
            )}

            {personasLocal.map((persona,pi)=>{
              const pturnos = turnosCarg[persona.id] || {};
              const hsSemanales = calcHorasSemanales(pturnos, semanaView);
              const okMinimo = hsSemanales >= 25; // 5 días × 5hs mínimo semanal
              return (
                <div key={persona.id} style={{marginBottom:14}}>
                  {/* Persona row */}
                  <div style={{display:"grid",gridTemplateColumns:"80px repeat(6,1fr)",gap:3,marginBottom:3}}>
                    {/* Avatar + nombre */}
                    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4,padding:"4px 0"}}>
                      <div style={{position:"relative"}}>
                        <Avatar persona={persona} size={32} onClick={()=>{setSelectedP(persona.id);setShowPerfil(true);}}/>
                        <div style={{position:"absolute",bottom:-2,right:-2,width:10,height:10,borderRadius:"50%",background:okMinimo?B.green:"#E88",border:`1.5px solid ${B.white}`}}/>
                      </div>
                      <div style={{fontSize:7,color:B.text,textAlign:"center",fontWeight:700,lineHeight:1.2,maxWidth:72}}>{persona.nombre.split(" ")[0]}</div>
                      <div style={{fontSize:7,color:okMinimo?B.green:"#C0392B",fontWeight:700}}>{hsSemanales}hs</div>
                    </div>

                    {/* Celdas por día */}
                    {DIAS.map((_,diaIdx)=>{
                      const key = `${semanaView}-${diaIdx}`;
                      const turnoAsig = pturnos[key];
                      const tData = turnoAsig ? TURNOS.find(t=>t.id===turnoAsig) : null;
                      return (
                        <div key={diaIdx} style={{display:"flex",flexDirection:"column",gap:2}}>
                          {TURNOS.map(t=>{
                            const selec = turnoAsig === t.id;
                            return (
                              <button key={t.id} className="turno-cell" onClick={()=>cargaAbierta&&toggleTurno(persona.id,semanaView,diaIdx,t.id)} style={{
                                padding:"4px 2px",borderRadius:5,fontSize:7,fontWeight:700,letterSpacing:.3,
                                background:selec?t.color:`${t.color}15`,
                                color:selec?B.white:t.color,
                                border:`1px solid ${selec?t.color:t.color+"40"}`,
                                transition:"all .15s",
                                cursor:cargaAbierta?"pointer":"default",
                                opacity:cargaAbierta||selec?1:.7,
                              }}>
                                {t.id==="manana"?"M":"T"}
                              </button>
                            );
                          })}
                        </div>
                      );
                    })}
                  </div>
                  {/* Separator */}
                  {pi < personasLocal.length-1 && <div style={{height:1,background:B.coolGray,margin:"8px 0"}}/>}
                </div>
              );
            })}

            {/* Leyenda */}
            <div style={{marginTop:16,padding:"12px 14px",background:B.white,borderRadius:10,border:`1px solid ${B.pinkLight}`}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:10}}>REFERENCIA</div>
              <div style={{display:"flex",gap:16,flexWrap:"wrap"}}>
                {TURNOS.map(t=>(
                  <div key={t.id} style={{display:"flex",alignItems:"center",gap:6}}>
                    <div style={{width:20,height:16,borderRadius:4,background:t.color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,color:B.white,fontWeight:700}}>{t.id==="manana"?"M":"T"}</div>
                    <div>
                      <div style={{fontSize:9,fontWeight:700,color:t.color}}>{t.label}</div>
                      <div style={{fontSize:8,color:B.mid}}>{t.horario}</div>
                    </div>
                  </div>
                ))}
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <div style={{width:10,height:10,borderRadius:"50%",background:B.green}}/>
                  <div style={{fontSize:9,color:B.mid}}>≥25hs semanales</div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <div style={{width:10,height:10,borderRadius:"50%",background:"#E88"}}/>
                  <div style={{fontSize:9,color:B.mid}}>Bajo mínimo</div>
                </div>
              </div>
              {!cargaAbierta && (
                <div style={{marginTop:10,padding:"8px 10px",background:B.goldPale,borderRadius:8,fontSize:9,color:B.gold,fontWeight:700}}>
                  🔒 La carga se habilita del 1 al 5 de cada mes para el mes siguiente
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ══════════ ADHESIÓN ══════════ */}
      {tab==="adhesion" && (
        <div style={{padding:"14px 14px 40px",animation:"fadeUp .4s ease forwards"}}>
          <div style={{padding:"16px",background:`linear-gradient(135deg,${B.dark},#1a1008)`,borderRadius:14,marginBottom:16,position:"relative",overflow:"hidden"}}>
            <PatternBg opacity={0.08}/>
            <div style={{position:"relative"}}>
              <div style={{fontSize:9,letterSpacing:3,color:B.gold,fontWeight:700,marginBottom:4}}>RESUMEN ANUAL</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginTop:10}}>
                {[
                  {label:"Promedio adhesión",value:"88%",color:B.goldLight},
                  {label:"Meta 36hs/sem",     value:"36hs",color:B.pink},
                  {label:"Equipo total",      value:`${personas.filter(p=>p.activa&&p.rol==="manicura").length}`,color:B.glacier},
                ].map((s,i)=>(
                  <div key={i} style={{background:"rgba(255,255,255,0.06)",borderRadius:8,padding:"10px",textAlign:"center"}}>
                    <div style={{fontFamily:"Georgia,serif",fontSize:18,color:s.color,fontWeight:300}}>{s.value}</div>
                    <div style={{fontSize:7,color:B.glacier,marginTop:3,lineHeight:1.3}}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Historial mensual */}
          <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:12}}>HISTORIAL 2026</div>
          {ADHESION_HIST.map((m,i)=>{
            const pct = Math.round((m.cumplieron/m.total)*100);
            const ok = m.promedio_hs >= 36;
            return (
              <div key={i} style={{background:B.white,borderRadius:12,marginBottom:8,padding:"14px 16px",border:`1px solid ${B.pinkLight}`,animation:`fadeUp .3s ease ${i*.06}s both`}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
                  <div style={{fontSize:13,fontWeight:700,color:B.text}}>{m.mes} 2026</div>
                  <div style={{display:"flex",gap:8,alignItems:"center"}}>
                    <div style={{padding:"3px 10px",borderRadius:20,background:ok?B.greenPale:`#FEE`,border:`1px solid ${ok?B.green+"40":"#FCC"}`,fontSize:8,color:ok?B.green:"#C0392B",fontWeight:700}}>
                      {m.promedio_hs}hs prom. {ok?"✓":"↓"}
                    </div>
                  </div>
                </div>
                <div style={{marginBottom:6}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                    <div style={{fontSize:9,color:B.mid}}>{m.cumplieron} de {m.total} cumplieron la meta</div>
                    <div style={{fontSize:9,color:pct>=80?B.green:pct>=60?B.gold:"#C0392B",fontWeight:700}}>{pct}%</div>
                  </div>
                  <div style={{height:6,background:B.coolGray,borderRadius:3,overflow:"hidden"}}>
                    <div style={{width:`${pct}%`,height:"100%",background:pct>=80?`linear-gradient(90deg,${B.green},#7EC88E)`:pct>=60?`linear-gradient(90deg,${B.gold},${B.goldLight})`:`linear-gradient(90deg,#E88,#C0392B)`,borderRadius:3,transition:"width 1s ease"}}/>
                  </div>
                </div>
                {/* Mini avatars */}
                <div style={{display:"flex",gap:4,marginTop:8}}>
                  {personas.filter(p=>p.rol==="manicura"&&p.activa).slice(0,6).map((p,pi)=>(
                    <Avatar key={pi} persona={p} size={24}/>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Mayo en curso */}
          <div style={{background:B.goldPale,borderRadius:12,padding:"14px 16px",border:`1px solid ${B.goldLight}40`,marginTop:4}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
              <div style={{animation:"pulse 2s ease infinite",fontSize:8,color:B.gold,fontWeight:700,letterSpacing:2}}>● EN CURSO</div>
              <div style={{fontSize:12,fontWeight:700,color:B.text}}>Mayo 2026</div>
            </div>
            <div style={{fontSize:11,color:B.mid,lineHeight:1.5}}>
              La carga de turnos se abre del <strong>1 al 5 de Mayo</strong>. El cierre es automático. Mínimo requerido: <strong>36hs semanales</strong>.
            </div>
          </div>
        </div>
      )}

      {/* ══════════ EQUIPO ══════════ */}
      {tab==="equipo" && (
        <div style={{padding:"14px 14px 40px",animation:"fadeUp .4s ease forwards"}}>
          {/* Summary por rol */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14}}>
            {[
              {label:"Manicuras",   value:personas.filter(p=>p.rol==="manicura"&&p.activa).length,   color:B.pink  },
              {label:"Encargadas",  value:personas.filter(p=>p.rol==="encargada"&&p.activa).length,  color:B.gold  },
            ].map((s,i)=>(
              <div key={i} style={{background:B.white,borderRadius:12,padding:"14px",border:`1px solid ${B.pinkLight}`,display:"flex",alignItems:"center",gap:12}}>
                <div style={{fontFamily:"Georgia,serif",fontSize:28,color:s.color,fontWeight:300}}>{s.value}</div>
                <div style={{fontSize:10,color:B.mid}}>{s.label}<br/>activas</div>
              </div>
            ))}
          </div>

          {/* Lista personas */}
          <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:12}}>EQUIPO COMPLETO</div>
          {personas.filter(p=>p.activa).map((p,i)=>{
            const hsTotal = calcHoras(turnosCarg[p.id]);
            const tPref = TURNOS.find(t=>t.id===p.turno_pref);
            return (
              <div key={p.id} className="card" onClick={()=>{setSelectedP(p.id);setShowPerfil(true);}} style={{background:B.white,borderRadius:12,marginBottom:8,padding:"13px 14px",border:`1px solid ${B.pinkLight}`,cursor:"pointer",transition:"all .2s",display:"flex",alignItems:"center",gap:12,animation:`fadeUp .3s ease ${i*.04}s both`}}>
                <div style={{position:"relative"}}>
                  <Avatar persona={p} size={44}/>
                  {!p.foto && (
                    <div style={{position:"absolute",bottom:-2,right:-2,width:16,height:16,borderRadius:"50%",background:B.gold,border:`1.5px solid ${B.white}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,color:B.white}}>📷</div>
                  )}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,fontWeight:700,color:B.text,marginBottom:2}}>{p.nombre}</div>
                  <div style={{fontSize:10,color:B.mid,marginBottom:4}}>📍 {p.local}</div>
                  <div style={{display:"flex",gap:6}}>
                    <div style={{padding:"2px 8px",borderRadius:20,background:`${B.purple}15`,border:`1px solid ${B.purple}40`,fontSize:8,color:B.purple,fontWeight:700}}>{p.rol.toUpperCase()}</div>
                    {tPref && <div style={{padding:"2px 8px",borderRadius:20,background:`${tPref.color}15`,border:`1px solid ${tPref.color}40`,fontSize:8,color:tPref.color,fontWeight:700}}>{tPref.label}</div>}
                  </div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:16,fontWeight:300,fontFamily:"Georgia,serif",color:hsTotal>=36?B.green:B.gold}}>{hsTotal}hs</div>
                  <div style={{fontSize:7,color:B.mid}}>Mayo</div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ══════════ MODAL PERFIL ══════════ */}
      {showPerfil && personaSelec && (
        <div style={{position:"fixed",inset:0,zIndex:300,background:"rgba(42,32,32,0.6)",display:"flex",alignItems:"flex-end"}} onClick={()=>setShowPerfil(false)}>
          <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:430,margin:"0 auto",background:B.white,borderRadius:"20px 20px 0 0",animation:"slideUp .3s ease",maxHeight:"88vh",overflow:"hidden",display:"flex",flexDirection:"column"}}>
            {/* Hero */}
            <div style={{padding:"24px 20px 20px",background:`linear-gradient(135deg,${B.pinkBg},${B.goldPale})`,position:"relative",overflow:"hidden"}}>
              <PatternBg opacity={0.05}/>
              <div style={{position:"relative"}}>
                <button onClick={()=>setShowPerfil(false)} style={{position:"absolute",top:0,right:0,background:"transparent",color:B.mid,fontSize:20}}>×</button>
                <div style={{display:"flex",gap:16,alignItems:"flex-end"}}>
                  <div style={{position:"relative"}}>
                    <Avatar persona={personaSelec} size={72}/>
                    <button onClick={()=>fotoRef.current?.click()} style={{position:"absolute",bottom:-2,right:-2,width:24,height:24,borderRadius:"50%",background:B.pink,border:`2px solid ${B.white}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,color:B.white}}>📷</button>
                    <input ref={fotoRef} type="file" accept="image/*" onChange={e=>handleFotoUpload(e,personaSelec.id)} style={{display:"none"}}/>
                  </div>
                  <div>
                    <div style={{fontSize:20,fontWeight:700,color:B.text,marginBottom:4}}>{personaSelec.nombre}</div>
                    <div style={{fontSize:11,color:B.mid,marginBottom:6}}>📍 {personaSelec.local}</div>
                    <div style={{display:"flex",gap:6}}>
                      <div style={{padding:"3px 10px",borderRadius:20,background:`${B.purple}15`,border:`1px solid ${B.purple}40`,fontSize:8,color:B.purple,fontWeight:700}}>{personaSelec.rol.toUpperCase()}</div>
                      <div style={{padding:"3px 10px",borderRadius:20,background:`${TURNOS.find(t=>t.id===personaSelec.turno_pref)?.color||B.pink}15`,border:`1px solid ${TURNOS.find(t=>t.id===personaSelec.turno_pref)?.color||B.pink}40`,fontSize:8,color:TURNOS.find(t=>t.id===personaSelec.turno_pref)?.color||B.pink,fontWeight:700}}>{TURNOS.find(t=>t.id===personaSelec.turno_pref)?.label||""}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div style={{flex:1,overflowY:"auto",padding:"16px"}}>
              {/* Horas Mayo */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:16}}>
                {SEMANAS_MAYO.map(s=>{
                  const hs = calcHorasSemanales(turnosCarg[personaSelec.id]||{}, s.id);
                  const ok = hs >= 25;
                  return (
                    <div key={s.id} style={{background:ok?B.greenPale:B.coolGray,borderRadius:10,padding:"10px",textAlign:"center",border:`1px solid ${ok?B.green+"30":B.glacier}`}}>
                      <div style={{fontFamily:"Georgia,serif",fontSize:20,color:ok?B.green:B.mid,fontWeight:300}}>{hs}</div>
                      <div style={{fontSize:7,color:B.mid,marginTop:2}}>hs {s.label.replace("Semana","Sem")}</div>
                    </div>
                  );
                })}
              </div>

              {/* Total Mayo */}
              <div style={{padding:"14px",background:B.goldPale,borderRadius:10,border:`1px solid ${B.goldLight}40`,marginBottom:16,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <div>
                  <div style={{fontSize:9,color:B.gold,fontWeight:700,letterSpacing:2}}>TOTAL MAYO 2026</div>
                  <div style={{fontSize:9,color:B.mid,marginTop:2}}>Mínimo requerido: 36hs/semana</div>
                </div>
                <div style={{fontFamily:"Georgia,serif",fontSize:32,color:B.gold,fontWeight:300}}>{calcHoras(turnosCarg[personaSelec.id]||{})}hs</div>
              </div>

              {/* Historial adhesión */}
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:10}}>HISTORIAL</div>
              {ADHESION_HIST.map((m,i)=>(
                <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 0",borderBottom:`1px solid ${B.coolGray}`}}>
                  <div style={{fontSize:11,color:B.text}}>{m.mes}</div>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <div style={{height:4,width:80,background:B.coolGray,borderRadius:2,overflow:"hidden"}}>
                      <div style={{width:`${Math.min((m.promedio_hs/40)*100,100)}%`,height:"100%",background:m.promedio_hs>=36?B.green:B.gold,borderRadius:2}}/>
                    </div>
                    <div style={{fontSize:10,fontWeight:700,color:m.promedio_hs>=36?B.green:B.gold,minWidth:36}}>{m.promedio_hs}hs</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════ MODAL NUEVA VACANTE ══════════ */}
      {showNuevaVac && (
        <div style={{position:"fixed",inset:0,zIndex:300,background:"rgba(42,32,32,0.55)",display:"flex",alignItems:"flex-end"}} onClick={()=>setShowNuevaVac(false)}>
          <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:430,margin:"0 auto",background:B.white,borderRadius:"20px 20px 0 0",padding:"22px 18px 36px",animation:"slideUp .3s ease",maxHeight:"92vh",overflowY:"auto"}}>
            <div style={{display:"flex",alignItems:"center",marginBottom:18}}>
              <Star size={12} color={B.gold}/>
              <div style={{fontSize:12,fontWeight:700,color:B.text,letterSpacing:2,marginLeft:8}}>NUEVA BÚSQUEDA</div>
              <button onClick={()=>setShowNuevaVac(false)} style={{marginLeft:"auto",background:"transparent",color:B.mid,fontSize:20}}>×</button>
            </div>

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>LOCAL</div>
              <select value={draftVac.local} onChange={e=>setDraftVac(d=>({...d,local:e.target.value}))} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,background:B.pinkBg}}>
                {LOCALES_RRHH.map(l=><option key={l}>{l}</option>)}
              </select>
            </div>

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>TURNO</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                {TURNOS.map(t=>(
                  <button key={t.id} onClick={()=>setDraftVac(d=>({...d,turno:t.id}))} style={{padding:"10px",background:draftVac.turno===t.id?`${t.color}15`:B.coolGray,border:`2px solid ${draftVac.turno===t.id?t.color:B.glacier}`,borderRadius:9,fontSize:10,color:draftVac.turno===t.id?t.color:B.mid,fontWeight:700,transition:"all .2s"}}>
                    {t.label}<br/><span style={{fontSize:8,fontWeight:400}}>{t.horario}</span>
                  </button>
                ))}
              </div>
            </div>

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>PUESTO</div>
              <input value={draftVac.puesto} onChange={e=>setDraftVac(d=>({...d,puesto:e.target.value}))} placeholder="Ej: Manicura Senior" style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,background:B.pinkBg}}/>
            </div>

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>DESCRIPCIÓN</div>
              <textarea value={draftVac.descripcion} onChange={e=>setDraftVac(d=>({...d,descripcion:e.target.value}))} placeholder="Describí el puesto..." rows={3} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,lineHeight:1.5,resize:"none",background:B.pinkBg}}/>
            </div>

            <div style={{marginBottom:18}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>REQUISITOS (uno por línea)</div>
              <textarea value={draftVac.requisitos} onChange={e=>setDraftVac(d=>({...d,requisitos:e.target.value}))} placeholder={"2+ años de experiencia\nDisponibilidad tarde\nConocimiento en gel"} rows={3} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,lineHeight:1.6,resize:"none",background:B.pinkBg}}/>
            </div>

            <button onClick={addVacante} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:`0 5px 16px ${B.pink}40`}}>
              <Star size={10} color={B.white}/> PUBLICAR BÚSQUEDA
            </button>
          </div>
        </div>
      )}

      {/* ══════════ MODAL NUEVA PERSONA ══════════ */}
      {showNuevaP && (
        <div style={{position:"fixed",inset:0,zIndex:300,background:"rgba(42,32,32,0.55)",display:"flex",alignItems:"flex-end"}} onClick={()=>setShowNuevaP(false)}>
          <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:430,margin:"0 auto",background:B.white,borderRadius:"20px 20px 0 0",padding:"22px 18px 36px",animation:"slideUp .3s ease",maxHeight:"92vh",overflowY:"auto"}}>
            <div style={{display:"flex",alignItems:"center",marginBottom:18}}>
              <Star size={12} color={B.gold}/>
              <div style={{fontSize:12,fontWeight:700,color:B.text,letterSpacing:2,marginLeft:8}}>AGREGAR PERSONA</div>
              <button onClick={()=>setShowNuevaP(false)} style={{marginLeft:"auto",background:"transparent",color:B.mid,fontSize:20}}>×</button>
            </div>

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>NOMBRE COMPLETO</div>
              <input value={draftP.nombre} onChange={e=>setDraftP(d=>({...d,nombre:e.target.value}))} placeholder="Nombre y apellido" style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,background:B.pinkBg}}/>
            </div>

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>LOCAL</div>
              <select value={draftP.local} onChange={e=>setDraftP(d=>({...d,local:e.target.value}))} style={{width:"100%",padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:12,color:B.text,background:B.pinkBg}}>
                {LOCALES_RRHH.map(l=><option key={l}>{l}</option>)}
              </select>
            </div>

            <div style={{marginBottom:12}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>ROL</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                {[{id:"manicura",label:"Manicura"},{id:"encargada",label:"Encargada"}].map(r=>(
                  <button key={r.id} onClick={()=>setDraftP(d=>({...d,rol:r.id}))} style={{padding:"10px",background:draftP.rol===r.id?`${B.purple}15`:B.coolGray,border:`2px solid ${draftP.rol===r.id?B.purple:B.glacier}`,borderRadius:9,fontSize:11,color:draftP.rol===r.id?B.purple:B.mid,fontWeight:700,transition:"all .2s"}}>{r.label}</button>
                ))}
              </div>
            </div>

            <div style={{marginBottom:18}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>TURNO PREFERIDO</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                {TURNOS.map(t=>(
                  <button key={t.id} onClick={()=>setDraftP(d=>({...d,turno_pref:t.id}))} style={{padding:"10px",background:draftP.turno_pref===t.id?`${t.color}15`:B.coolGray,border:`2px solid ${draftP.turno_pref===t.id?t.color:B.glacier}`,borderRadius:9,fontSize:10,color:draftP.turno_pref===t.id?t.color:B.mid,fontWeight:700,transition:"all .2s"}}>
                    {t.label}<br/><span style={{fontSize:8,fontWeight:400}}>{t.horario}</span>
                  </button>
                ))}
              </div>
            </div>

            <button onClick={addPersona} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.gold},${B.goldLight})`,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:`0 5px 16px ${B.gold}40`}}>
              <Star size={10} color={B.white}/> AGREGAR AL EQUIPO
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MODPROYECTOSSTOCK ───────────────────────────────────────────────────────────
// ─── PERFILES_PROY ─────────────────────────────────────────────────────────────────
const PERFILES_PROY = {
  nicole:    { nombre:"Nicole Ulloa",       rol:"owner",     color:B.gold,    icon:"✦", acceso:"total"    },
  barbara:   { nombre:"Bárbara López",      rol:"barbara",   color:B.teal,    icon:"◆", acceso:"total", area:"Obras y Stock" },
  agustina:  { nombre:"Agustina Quaglia",   rol:"directora", color:B.pink,    icon:"◈", area:"Marketing"  },
  laura:     { nombre:"Laura Felipetti",    rol:"directora", color:B.pinkDeep,icon:"◇", area:"RRHH"       },
  lucia:     { nombre:"Lucía Becker",       rol:"directora", color:B.purple,  icon:"✿", area:"Stock"      },
};

const puedeVerProyectos = (userId) =>
  ["nicole","barbara","agustina","laura","lucia"].includes(userId);

const puedeEditarProyecto = (userId, proyectoOwnerId) =>
  userId === "nicole" ||
  userId === "barbara" ||
  userId === proyectoOwnerId;

// ─── PRIORIDADES ──────────────────────────────────────────────────────────────
const PRIORIDADES = {
  alta:   { label:"Alta",   color:B.red,    bg:B.redPale,    dot:"🔴" },
  media:  { label:"Media",  color:B.gold,   bg:B.goldPale,   dot:"🟡" },
  baja:   { label:"Baja",   color:B.green,  bg:B.greenPale,  dot:"🟢" },
};

// ─── PROYECTOS DEMO ───────────────────────────────────────────────────────────
const PROYECTOS_INIT = [
  {
    id:"p1", owner:"agustina",
    nombre:"Lanzamiento Niki OS — Comunicación",
    fecha:"31 May 2026", prioridad:"alta",
    comentarios:"Coordinar con el equipo la comunicación interna del lanzamiento de NIKI OS a toda la red.",
    tareas:[
      { id:"t1", texto:"Redactar comunicado oficial para franquiciadas", done:true },
      { id:"t2", texto:"Diseñar piezas para Stay Tuned", done:true },
      { id:"t3", texto:"Tutorial en video para encargadas", done:false },
      { id:"t4", texto:"Capacitación presencial el 17/5", done:false },
    ],
  },
  {
    id:"p2", owner:"agustina",
    nombre:"Campaña Miami 2026",
    fecha:"15 Jun 2026", prioridad:"alta",
    comentarios:"Plan de contenido para el desembarco en Miami. Incluye reel de la obra, storie de cuenta regresiva y lanzamiento.",
    tareas:[
      { id:"t5", texto:"Reels de la obra en progreso", done:true },
      { id:"t6", texto:"Campaña de expectativa en Instagram", done:false },
      { id:"t7", texto:"Coordinación con equipo Miami para contenido local", done:false },
      { id:"t8", texto:"Plan de lanzamiento día inauguración", done:false },
    ],
  },
  {
    id:"p3", owner:"laura",
    nombre:"Sistema de Niveles — Implementación Junio",
    fecha:"01 Jun 2026", prioridad:"alta",
    comentarios:"Implementar el sistema Junior → Senior → Master en toda la red antes de Junio. Incluye comunicación, skill reviews y actualización de comisiones.",
    tareas:[
      { id:"t9",  texto:"Notificar a todas las manicuras del nuevo sistema", done:true },
      { id:"t10", texto:"Completar skill reviews de todas las sucursales propias", done:false },
      { id:"t11", texto:"Actualizar planilla de comisiones", done:false },
      { id:"t12", texto:"Capacitación para encargadas sobre el sistema", done:false },
      { id:"t13", texto:"Armar certificados de nivel", done:false },
    ],
  },
  {
    id:"p4", owner:"laura",
    nombre:"Dotación Q2 2026",
    fecha:"30 Apr 2026", prioridad:"media",
    comentarios:"Cubrir vacantes en Puerto Madero, Lomas y locales de franquicia. Meta: dotación ≥ 98%.",
    tareas:[
      { id:"t14", texto:"Postear convocatorias en Instagram", done:true },
      { id:"t15", texto:"Pruebas semana 14-18 Abril", done:true },
      { id:"t16", texto:"Ingresos confirmados para Mayo", done:false },
      { id:"t17", texto:"Seguimiento de período de prueba", done:false },
    ],
  },
  {
    id:"p5", owner:"lucia",
    nombre:"Insumos Q2 — Revisión de Stock",
    fecha:"30 Apr 2026", prioridad:"media",
    comentarios:"Revisar stock actual vs. proyección de servicios Q2. Generar orden de compra antes del 30/4.",
    tareas:[
      { id:"t18", texto:"Inventario físico de todos los locales", done:true },
      { id:"t19", texto:"Cruzar con facturación proyectada", done:false },
      { id:"t20", texto:"Orden de compra a proveedores", done:false },
    ],
  },
];

// ─── STOCK DEMO ───────────────────────────────────────────────────────────────
const STOCK_INIT = [
  { id:"s1",  nombre:"Mesas de manicura",           cantidad:4,  estado:"disponible", obs:"Nuevas, sin usar. Para Ramos Mejía o San Isidro." },
  { id:"s2",  nombre:"Tornos profesionales",        cantidad:6,  estado:"disponible", obs:"Modelo Pro 2024." },
  { id:"s3",  nombre:"Sillas de cliente",           cantidad:8,  estado:"disponible", obs:"Color blanco, aptas para cualquier local." },
  { id:"s4",  nombre:"Sillas de manicura",          cantidad:3,  estado:"disponible", obs:"" },
  { id:"s5",  nombre:"Lámparas UV LED",             cantidad:10, estado:"disponible", obs:"Cargadores compatibles con todos los modelos." },
  { id:"s6",  nombre:"Espejos de pared grandes",    cantidad:2,  estado:"disponible", obs:"140x60cm. Ideales para pared lateral." },
  { id:"s7",  nombre:"Recepción (módulo)",          cantidad:1,  estado:"disponible", obs:"Color blanco mate, Lomas lo devolvió." },
  { id:"s8",  nombre:"Cartelería con logo NIKI BB", cantidad:5,  estado:"disponible", obs:"Formato vinilo autoadhesivo." },
  { id:"s9",  nombre:"Apoyamanos acolchados",       cantidad:12, estado:"disponible", obs:"Rosa palo, nuevos." },
  { id:"s10", nombre:"Cabinas de manicura (mampara)",cantidad:2, estado:"en_uso",     obs:"Usadas en Canning." },
  { id:"s11", nombre:"Sillas apilables negras",     cantidad:6,  estado:"en_uso",     obs:"En depósito de Lomas." },
  { id:"s12", nombre:"Torno antiguo modelo 2021",   cantidad:2,  estado:"daniado",    obs:"Requieren reparación del motor." },
  { id:"s13", nombre:"Mesa de recepción vidrio",    cantidad:1,  estado:"daniado",    obs:"Vidrio rajado. Ver si se repara." },
];

const ESTADO_STOCK = {
  disponible: { label:"Disponible", color:B.green,  bg:B.greenPale, icon:"✅" },
  en_uso:     { label:"En uso",     color:B.gold,   bg:B.goldPale,  icon:"📦" },
  daniado:    { label:"Dañado",     color:B.red,    bg:B.redPale,   icon:"⚠️" },
};

// ─── HELPERS ──────────────────────────────────────────────────────────────────


function Avatar({perfil, size=38}) {
  return (
    <div style={{width:size,height:size,borderRadius:"50%",background:`${perfil.color}18`,border:`2px solid ${perfil.color}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.32,fontWeight:700,color:perfil.color,flexShrink:0}}>
      {perfil.icon}
    </div>
  );
}

function Avance({tareas}) {
  const total = tareas.length;
  const done  = tareas.filter(t=>t.done).length;
  const pct   = total > 0 ? Math.round((done/total)*100) : 0;
  const color = pct===100 ? B.green : pct>=50 ? B.gold : B.pink;
  return (
    <div>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
        <div style={{fontSize:8,color:B.mid}}>{done}/{total} tareas</div>
        <div style={{fontSize:8,color,fontWeight:700}}>{pct}%</div>
      </div>
      <div style={{height:5,background:B.coolGray,borderRadius:3,overflow:"hidden"}}>
        <div style={{width:`${pct}%`,height:"100%",background:`linear-gradient(90deg,${color}80,${color})`,borderRadius:3,transition:"width .6s ease"}}/>
      </div>
    </div>
  );
}

// ─── MAIN ──────────────────────────────────────────────────────────────────────
function ModProyectosStock({user,onBack}) {
  const [userId,    setUserId]    = useState("nicole");
  const [tab,       setTab]       = useState("proyectos"); // proyectos | stock
  const [proyectos, setProyectos] = useState(PROYECTOS_INIT);
  const [stock,     setStock]     = useState(STOCK_INIT);
  const [view,      setView]      = useState("lista");     // lista | detalle | nuevo_proy | nuevo_item
  const [openId,    setOpenId]    = useState(null);
  const [filterOwner, setFilterOwner] = useState("all");
  const [filterEstado, setFilterEstado] = useState("all");

  // Nuevo proyecto
  const [draftProy, setDraftProy] = useState({nombre:"",fecha:"",prioridad:"media",comentarios:"",tareas:[]});
  const [draftTarea, setDraftTarea] = useState("");

  // Nuevo item stock
  const [draftItem, setDraftItem] = useState({nombre:"",cantidad:1,estado:"disponible",obs:""});

  // Editar tarea inline
  const [editingTarea, setEditingTarea] = useState(null);
  const [newComentario, setNewComentario] = useState("");

  const perfil = PERFILES_PROY[userId];
  const proyectoAbierto = openId ? proyectos.find(p=>p.id===openId) : null;
  const ownerAbierto = proyectoAbierto ? PERFILES_PROY[proyectoAbierto.owner] : null;

  const proyectosFiltrados = proyectos.filter(p => {
    if (!puedeVerProyectos(userId)) return false;
    if (filterOwner !== "all" && p.owner !== filterOwner) return false;
    return true;
  });

  const stockFiltrado = stock.filter(s => {
    if (filterEstado !== "all" && s.estado !== filterEstado) return false;
    return true;
  });

  const toggleTarea = (proyId, tareaId) => {
    setProyectos(prev=>prev.map(p=>p.id===proyId?{...p,tareas:p.tareas.map(t=>t.id===tareaId?{...t,done:!t.done}:t)}:p));
  };

  const agregarTarea = (proyId, texto) => {
    if (!texto.trim()) return;
    setProyectos(prev=>prev.map(p=>p.id===proyId?{...p,tareas:[...p.tareas,{id:`t_${Date.now()}`,texto,done:false}]}:p));
  };

  const eliminarTarea = (proyId, tareaId) => {
    setProyectos(prev=>prev.map(p=>p.id===proyId?{...p,tareas:p.tareas.filter(t=>t.id!==tareaId)}:p));
  };

  const publicarProyecto = () => {
    if (!draftProy.nombre.trim()) return;
    const nuevo = {
      id:`p_${Date.now()}`,
      owner: userId,
      ...draftProy,
      tareas: draftProy.tareas,
    };
    setProyectos(prev=>[nuevo,...prev]);
    setDraftProy({nombre:"",fecha:"",prioridad:"media",comentarios:"",tareas:[]});
    setView("lista");
  };

  const publicarItem = () => {
    if (!draftItem.nombre.trim()) return;
    setStock(prev=>[{id:`s_${Date.now()}`,...draftItem},...prev]);
    setDraftItem({nombre:"",cantidad:1,estado:"disponible",obs:""});
    setView("lista");
  };

  const CSS = `
    @import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300&display=swap');
    *{box-sizing:border-box;margin:0;padding:0;}
    ::-webkit-scrollbar{width:3px;}::-webkit-scrollbar-thumb{background:${B.pinkLight};}
    @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
    @keyframes shimmer{0%,100%{opacity:.55}50%{opacity:1}}
    button{cursor:pointer;border:none;font-family:inherit;}
    input,textarea,select{font-family:inherit;outline:none;}
    .card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(221,164,174,0.14)!important;}
  `;

  // ── DETALLE PROYECTO ────────────────────────────────────────────────────────
  if (view==="detalle" && proyectoAbierto) {
    const canEdit = puedeEditarProyecto(userId, proyectoAbierto.owner);
    const prio    = PRIORIDADES[proyectoAbierto.prioridad];
    return (
      <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
        <style>{CSS}</style>
        <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)",display:"flex",alignItems:"center",gap:10}}>
          <button onClick={()=>setView("lista")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
          <div style={{flex:1}}>
            <div style={{fontSize:12,fontWeight:700,color:B.text,lineHeight:1.3}}>{proyectoAbierto.nombre}</div>
            <div style={{fontSize:8,color:B.mid}}>{ownerAbierto?.nombre} · {ownerAbierto?.area}</div>
          </div>
          <div style={{padding:"3px 10px",borderRadius:20,background:prio.bg,border:`1px solid ${prio.color}40`,fontSize:8,color:prio.color,fontWeight:700}}>{prio.dot} {prio.label}</div>
        </div>

        <div style={{paddingBottom:40}}>
          {/* Hero */}
          <div style={{background:B.white,padding:"18px",borderBottom:`1px solid ${B.pinkLight}`,position:"relative",overflow:"hidden"}}>
            <PatternBg opacity={0.04} id="det-pp"/>
            <div style={{position:"relative"}}>
              <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:16}}>
                {ownerAbierto&&<Avatar perfil={ownerAbierto} size={40}/>}
                <div>
                  <div style={{fontSize:9,color:B.mid,marginBottom:2}}>RESPONSABLE</div>
                  <div style={{fontSize:12,fontWeight:700,color:B.text}}>{ownerAbierto?.nombre}</div>
                  <div style={{fontSize:9,color:ownerAbierto?.color}}>{ownerAbierto?.area}</div>
                </div>
                {proyectoAbierto.fecha&&(
                  <div style={{marginLeft:"auto",textAlign:"right"}}>
                    <div style={{fontSize:8,color:B.mid,marginBottom:2}}>FECHA LÍMITE</div>
                    <div style={{fontSize:11,fontWeight:700,color:B.text}}>{proyectoAbierto.fecha}</div>
                  </div>
                )}
              </div>
              <Avance tareas={proyectoAbierto.tareas}/>
            </div>
          </div>

          <div style={{padding:"14px 16px 0"}}>
            {/* Comentarios */}
            {proyectoAbierto.comentarios&&(
              <div style={{background:B.goldPale,borderRadius:12,padding:"14px",border:`1px solid ${B.goldLight}30`,marginBottom:14}}>
                <div style={{fontSize:8,letterSpacing:2,color:B.gold,fontWeight:700,marginBottom:8}}>✨ DESCRIPCIÓN</div>
                <div style={{fontSize:12,color:B.text,lineHeight:1.7}}>{proyectoAbierto.comentarios}</div>
              </div>
            )}

            {/* Agregar comentario */}
            {canEdit&&(
              <div style={{marginBottom:14}}>
                <div style={{display:"flex",gap:8}}>
                  <input value={newComentario} onChange={e=>setNewComentario(e.target.value)} placeholder="Agregar comentario o actualización..." style={{flex:1,padding:"9px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:8,fontSize:11,color:B.text,background:B.white}}/>
                  <button onClick={()=>{if(newComentario.trim()){setProyectos(prev=>prev.map(p=>p.id===proyectoAbierto.id?{...p,comentarios:p.comentarios+(p.comentarios?"\n\n":"")+`[${new Date().toLocaleDateString("es-AR")}] ${newComentario.trim()}`}:p));setNewComentario("");}}} style={{padding:"9px 14px",background:B.gold,borderRadius:8,color:B.white,fontSize:11,fontWeight:700}}>+</button>
                </div>
              </div>
            )}

            {/* Tareas */}
            <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:12}}>TAREAS</div>
            {proyectoAbierto.tareas.map((t,i)=>(
              <div key={t.id} style={{background:B.white,borderRadius:10,padding:"12px 14px",marginBottom:6,border:`1px solid ${t.done?B.green+"30":B.pinkLight}`,display:"flex",gap:10,alignItems:"center",animation:`fadeUp .2s ease ${i*.03}s both`,transition:"all .2s"}}>
                <button onClick={()=>canEdit&&toggleTarea(proyectoAbierto.id,t.id)} style={{width:22,height:22,borderRadius:"50%",flexShrink:0,background:t.done?B.green:"transparent",border:`2px solid ${t.done?B.green:B.glacier}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,color:B.white,transition:"all .2s",cursor:canEdit?"pointer":"default"}}>
                  {t.done?"✓":""}
                </button>
                <div style={{flex:1,fontSize:12,color:t.done?B.mid:B.text,textDecoration:t.done?"line-through":"none",lineHeight:1.4}}>{t.texto}</div>
                {canEdit&&(
                  <button onClick={()=>eliminarTarea(proyectoAbierto.id,t.id)} style={{background:"transparent",color:B.glacier,fontSize:14,padding:"2px 4px",flexShrink:0}}>×</button>
                )}
              </div>
            ))}

            {/* Agregar tarea */}
            {canEdit&&(
              <div style={{display:"flex",gap:8,marginTop:8}}>
                <input
                  value={editingTarea||""}
                  onChange={e=>setEditingTarea(e.target.value)}
                  placeholder="Nueva tarea..."
                  onKeyDown={e=>{if(e.key==="Enter"&&editingTarea?.trim()){agregarTarea(proyectoAbierto.id,editingTarea);setEditingTarea("");}}}
                  style={{flex:1,padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:8,fontSize:11,color:B.text,background:B.white}}
                />
                <button onClick={()=>{if(editingTarea?.trim()){agregarTarea(proyectoAbierto.id,editingTarea);setEditingTarea("");}}} style={{padding:"10px 16px",background:B.pink,borderRadius:8,color:B.white,fontSize:11,fontWeight:700}}>+</button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // ── NUEVO PROYECTO ──────────────────────────────────────────────────────────
  if (view==="nuevo_proy") return (
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <style>{CSS}</style>
      <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)",display:"flex",alignItems:"center",gap:10}}>
        <button onClick={()=>setView("lista")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
        <div style={{flex:1,fontSize:13,fontWeight:700,color:B.text}}>Nuevo proyecto ✨</div>
      </div>

      <div style={{padding:"16px",paddingBottom:100}}>
        {[{key:"nombre",label:"NOMBRE DEL PROYECTO *",placeholder:"Ej: Campaña Mayo 2026",type:"text"},{key:"fecha",label:"FECHA LÍMITE",placeholder:"",type:"date"}].map(f=>(
          <div key={f.key} style={{marginBottom:12}}>
            <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:7}}>{f.label}</div>
            <input type={f.type} value={draftProy[f.key]} onChange={e=>setDraftProy(d=>({...d,[f.key]:e.target.value}))} placeholder={f.placeholder} style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,background:B.white}}/>
          </div>
        ))}

        <div style={{marginBottom:12}}>
          <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:8}}>PRIORIDAD</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
            {Object.entries(PRIORIDADES).map(([key,p])=>(
              <button key={key} onClick={()=>setDraftProy(d=>({...d,prioridad:key}))} style={{padding:"10px",background:draftProy.prioridad===key?p.bg:B.white,border:`2px solid ${draftProy.prioridad===key?p.color:B.glacier}`,borderRadius:10,fontSize:10,color:draftProy.prioridad===key?p.color:B.mid,fontWeight:700,transition:"all .2s"}}>
                {p.dot} {p.label}
              </button>
            ))}
          </div>
        </div>

        <div style={{marginBottom:12}}>
          <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:7}}>DESCRIPCIÓN / COMENTARIOS</div>
          <textarea value={draftProy.comentarios} onChange={e=>setDraftProy(d=>({...d,comentarios:e.target.value}))} placeholder="Contexto, objetivos, link a docs..." rows={4} style={{width:"100%",padding:"12px 14px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,lineHeight:1.6,resize:"none",background:B.white}}/>
        </div>

        <div style={{marginBottom:16}}>
          <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:8}}>TAREAS INICIALES</div>
          {draftProy.tareas.map((t,i)=>(
            <div key={i} style={{display:"flex",gap:8,alignItems:"center",marginBottom:6}}>
              <div style={{flex:1,padding:"9px 12px",background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,fontSize:11,color:B.text}}>{t.texto}</div>
              <button onClick={()=>setDraftProy(d=>({...d,tareas:d.tareas.filter((_,fi)=>fi!==i)}))} style={{background:"transparent",color:B.mid,fontSize:16,padding:"2px 6px"}}>×</button>
            </div>
          ))}
          <div style={{display:"flex",gap:8}}>
            <input value={draftTarea} onChange={e=>setDraftTarea(e.target.value)} placeholder="Agregar tarea..." onKeyDown={e=>{if(e.key==="Enter"&&draftTarea.trim()){setDraftProy(d=>({...d,tareas:[...d.tareas,{id:`t_${Date.now()}`,texto:draftTarea.trim(),done:false}]}));setDraftTarea("");}}} style={{flex:1,padding:"10px 12px",border:`1.5px solid ${B.pinkLight}`,borderRadius:8,fontSize:11,color:B.text,background:B.white}}/>
            <button onClick={()=>{if(draftTarea.trim()){setDraftProy(d=>({...d,tareas:[...d.tareas,{id:`t_${Date.now()}`,texto:draftTarea.trim(),done:false}]}));setDraftTarea("");}}} style={{padding:"10px 14px",background:B.pink,borderRadius:8,color:B.white,fontSize:11,fontWeight:700}}>+</button>
          </div>
        </div>
      </div>

      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,padding:"12px 16px 24px",background:B.white,borderTop:`1px solid ${B.pinkLight}`,boxShadow:"0 -2px 12px rgba(221,164,174,0.08)"}}>
        <button onClick={publicarProyecto} disabled={!draftProy.nombre.trim()} style={{width:"100%",padding:"14px",background:draftProy.nombre.trim()?`linear-gradient(135deg,${B.pink},${B.pinkDeep})`:B.glacier,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:draftProy.nombre.trim()?`0 5px 16px ${B.pink}30`:"none",transition:"all .3s"}}>
          <Star size={10} color={B.white}/>CREAR PROYECTO
        </button>
      </div>
    </div>
  );

  // ── NUEVO ITEM STOCK ────────────────────────────────────────────────────────
  if (view==="nuevo_item") return (
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <style>{CSS}</style>
      <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)",display:"flex",alignItems:"center",gap:10}}>
        <button onClick={()=>setView("lista")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
        <div style={{flex:1,fontSize:13,fontWeight:700,color:B.text}}>Agregar al stock ◆</div>
      </div>

      <div style={{padding:"16px",paddingBottom:100}}>
        <div style={{marginBottom:12}}>
          <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:7}}>NOMBRE DEL ÍTEM *</div>
          <input value={draftItem.nombre} onChange={e=>setDraftItem(d=>({...d,nombre:e.target.value}))} placeholder="Ej: Mesas de manicura, tornos, sillas..." style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,background:B.white}}/>
        </div>

        <div style={{marginBottom:12}}>
          <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:7}}>CANTIDAD</div>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <button onClick={()=>setDraftItem(d=>({...d,cantidad:Math.max(1,d.cantidad-1)}))} style={{width:36,height:36,borderRadius:8,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:18,color:B.mid,display:"flex",alignItems:"center",justifyContent:"center"}}>−</button>
            <div style={{fontFamily:"Georgia,serif",fontSize:28,color:B.text,fontWeight:300,minWidth:50,textAlign:"center"}}>{draftItem.cantidad}</div>
            <button onClick={()=>setDraftItem(d=>({...d,cantidad:d.cantidad+1}))} style={{width:36,height:36,borderRadius:8,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:18,color:B.mid,display:"flex",alignItems:"center",justifyContent:"center"}}>+</button>
          </div>
        </div>

        <div style={{marginBottom:12}}>
          <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:8}}>ESTADO</div>
          <div style={{display:"flex",flexDirection:"column",gap:8}}>
            {Object.entries(ESTADO_STOCK).map(([key,e])=>(
              <button key={key} onClick={()=>setDraftItem(d=>({...d,estado:key}))} style={{padding:"12px 14px",background:draftItem.estado===key?e.bg:B.white,border:`2px solid ${draftItem.estado===key?e.color:B.glacier}`,borderRadius:10,display:"flex",alignItems:"center",gap:10,transition:"all .2s"}}>
                <div style={{fontSize:16}}>{e.icon}</div>
                <div style={{fontSize:11,fontWeight:700,color:draftItem.estado===key?e.color:B.mid}}>{e.label}</div>
              </button>
            ))}
          </div>
        </div>

        <div style={{marginBottom:16}}>
          <div style={{fontSize:8,letterSpacing:1,color:B.mid,fontWeight:700,marginBottom:7}}>OBSERVACIONES</div>
          <textarea value={draftItem.obs} onChange={e=>setDraftItem(d=>({...d,obs:e.target.value}))} placeholder="Local asignado, condición, notas..." rows={3} style={{width:"100%",padding:"12px 14px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,lineHeight:1.6,resize:"none",background:B.white}}/>
        </div>
      </div>

      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,padding:"12px 16px 24px",background:B.white,borderTop:`1px solid ${B.pinkLight}`,boxShadow:"0 -2px 12px rgba(221,164,174,0.08)"}}>
        <button onClick={publicarItem} disabled={!draftItem.nombre.trim()} style={{width:"100%",padding:"14px",background:draftItem.nombre.trim()?`linear-gradient(135deg,${B.teal},${B.teal}cc)`:B.glacier,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:draftItem.nombre.trim()?`0 5px 16px ${B.teal}30`:"none",transition:"all .3s"}}>
          <Star size={10} color={B.white}/>AGREGAR AL STOCK
        </button>
      </div>
    </div>
  );

  // ── LISTA PRINCIPAL ─────────────────────────────────────────────────────────
  return (
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <style>{CSS}</style>

      {/* HEADER */}
      <div style={{background:B.white,padding:"0 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 12px rgba(221,164,174,0.07)"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"13px 0 10px"}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <Star size={12} color={B.gold}/>
            <div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:300,letterSpacing:4,textIndent:4,color:B.pink}}>NIKI OS</div>
              <div style={{fontSize:7,letterSpacing:3,color:B.mid}}>PROYECTOS & STOCK</div>
            </div>
          </div>
          {/* Selector de perfil (demo) */}
          <select value={userId} onChange={e=>setUserId(e.target.value)} style={{padding:"5px 10px",border:`1px solid ${B.pinkLight}`,borderRadius:8,fontSize:9,color:B.text,background:B.white,fontWeight:700}}>
            {Object.entries(PERFILES_PROY).map(([id,p])=>(
              <option key={id} value={id}>{p.icon} {p.nombre.split(" ")[0]}</option>
            ))}
          </select>
        </div>

        {/* Badge usuario */}
        <div style={{display:"flex",gap:8,alignItems:"center",paddingBottom:10}}>
          <Avatar perfil={perfil} size={28}/>
          <div style={{flex:1}}>
            <div style={{fontSize:10,fontWeight:700,color:B.text}}>{perfil.nombre}</div>
            <div style={{fontSize:8,color:perfil.color,fontWeight:700}}>
              {perfil.rol==="owner"?"Owner ✦":perfil.rol==="barbara"?"Acceso total · "+perfil.area:"Directora · "+perfil.area}
            </div>
          </div>
          {tab==="proyectos" && puedeEditarProyecto(userId, userId) && (
            <button onClick={()=>setView("nuevo_proy")} style={{padding:"7px 14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:1,boxShadow:`0 3px 10px ${B.pink}25`}}>+ PROYECTO</button>
          )}
          {tab==="stock" && (userId==="barbara"||userId==="nicole") && (
            <button onClick={()=>setView("nuevo_item")} style={{padding:"7px 14px",background:`linear-gradient(135deg,${B.teal},${B.teal}cc)`,borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:1,boxShadow:`0 3px 10px ${B.teal}25`}}>+ ÍTEM</button>
          )}
        </div>

        {/* Tabs */}
        <div style={{display:"flex"}}>
          {[{id:"proyectos",icon:"📋",label:"Proyectos"},{id:"stock",icon:"◆",label:"Stock Depósito"}].map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:"8px 0 10px",background:"transparent",borderBottom:`2.5px solid ${tab===t.id?B.pink:"transparent"}`,color:tab===t.id?B.pink:B.mid,fontSize:9,fontWeight:tab===t.id?700:400,letterSpacing:.5,transition:"all .2s"}}>
              <div style={{fontSize:11,marginBottom:2}}>{t.icon}</div>{t.label.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* ══ PROYECTOS ══ */}
      {tab==="proyectos"&&(
        <div style={{padding:"16px",paddingBottom:40}}>
          {/* Stats */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:16}}>
            {[
              {l:"Total",      v:proyectos.length,                                                                  c:B.pink  },
              {l:"En curso",   v:proyectos.filter(p=>p.tareas.some(t=>!t.done)&&p.tareas.some(t=>t.done)).length, c:B.gold  },
              {l:"Completados",v:proyectos.filter(p=>p.tareas.length>0&&p.tareas.every(t=>t.done)).length,         c:B.green },
            ].map((s,i)=>(
              <div key={i} style={{background:B.white,borderRadius:12,padding:"12px 8px",border:`1px solid ${B.pinkLight}`,textAlign:"center",boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
                <div style={{fontFamily:"Georgia,serif",fontSize:22,color:s.c,fontWeight:300}}>{s.v}</div>
                <div style={{fontSize:7,color:B.mid,marginTop:3}}>{s.l}</div>
              </div>
            ))}
          </div>

          {/* Filtro por directora */}
          <div style={{display:"flex",gap:7,overflowX:"auto",scrollbarWidth:"none",marginBottom:14}}>
            {[{id:"all",label:"Todos"}, ...Object.entries(PERFILES_PROY).filter(([_,p])=>p.area).map(([id,p])=>({id,label:p.area}))].map(f=>(
              <button key={f.id} onClick={()=>setFilterOwner(f.id)} style={{padding:"5px 12px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:filterOwner===f.id?B.dark:B.white,color:filterOwner===f.id?B.white:B.mid,border:`1px solid ${filterOwner===f.id?B.dark:B.glacier}`,transition:"all .2s"}}>
                {f.label.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Por directora */}
          {Object.entries(PERFILES_PROY).filter(([_,p])=>p.area).map(([ownerId,ownerP])=>{
            const ps = proyectosFiltrados.filter(p=>p.owner===ownerId);
            if ((filterOwner!=="all"&&filterOwner!==ownerId) || ps.length===0) return null;
            return (
              <div key={ownerId} style={{marginBottom:20}}>
                <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
                  <Avatar perfil={ownerP} size={28}/>
                  <div>
                    <div style={{fontSize:10,fontWeight:700,color:B.text}}>{ownerP.nombre}</div>
                    <div style={{fontSize:8,color:ownerP.color}}>{ownerP.area}</div>
                  </div>
                  <div style={{marginLeft:"auto",fontSize:9,color:B.mid}}>{ps.length} proyecto{ps.length!==1?"s":""}</div>
                </div>
                {ps.map((p,i)=>{
                  const prio = PRIORIDADES[p.prioridad];
                  const done = p.tareas.filter(t=>t.done).length;
                  const pct  = p.tareas.length>0?Math.round((done/p.tareas.length)*100):0;
                  const colP = pct===100?B.green:pct>=50?B.gold:B.pink;
                  return (
                    <div key={p.id} className="card" onClick={()=>{setOpenId(p.id);setView("detalle");}} style={{background:B.white,borderRadius:14,marginBottom:8,border:`1.5px solid ${B.pinkLight}`,cursor:"pointer",overflow:"hidden",transition:"all .2s",boxShadow:"0 2px 8px rgba(221,164,174,0.06)",animation:`fadeUp .3s ease ${i*.05}s both`}}>
                      <div style={{height:3,background:`linear-gradient(90deg,${ownerP.color}60,${ownerP.color})`}}/>
                      <div style={{padding:"14px 16px"}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
                          <div style={{flex:1,paddingRight:8}}>
                            <div style={{fontSize:13,fontWeight:700,color:B.text,lineHeight:1.3,marginBottom:4}}>{p.nombre}</div>
                            {p.fecha&&<div style={{fontSize:9,color:B.mid}}>📅 {p.fecha}</div>}
                          </div>
                          <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4,flexShrink:0}}>
                            <div style={{padding:"2px 8px",borderRadius:20,background:prio.bg,border:`1px solid ${prio.color}40`,fontSize:7,color:prio.color,fontWeight:700}}>{prio.dot} {prio.label}</div>
                            <div style={{fontFamily:"Georgia,serif",fontSize:18,color:colP,fontWeight:300}}>{pct}%</div>
                          </div>
                        </div>
                        <Avance tareas={p.tareas}/>
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      )}

      {/* ══ STOCK ══ */}
      {tab==="stock"&&(
        <div style={{padding:"16px",paddingBottom:40}}>
          {/* Header stock */}
          <div style={{background:B.white,borderRadius:14,overflow:"hidden",marginBottom:16,border:`1px solid ${B.pinkLight}`,boxShadow:"0 2px 8px rgba(221,164,174,0.07)"}}>
            <div style={{height:3,background:`linear-gradient(90deg,${B.teal},${B.gold})`}}/>
            <div style={{padding:"16px",position:"relative",overflow:"hidden"}}>
              <PatternBg opacity={0.04} id="stock-p"/>
              <div style={{position:"relative",display:"flex",gap:12,alignItems:"center"}}>
                <Avatar perfil={PERFILES_PROY.barbara} size={44}/>
                <div>
                  <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:B.text,fontWeight:300,marginBottom:2}}>Stock Depósito ◆</div>
                  <div style={{fontSize:9,color:B.mid}}>Inventario para futuras obras · Bárbara López</div>
                </div>
              </div>
            </div>
            {/* Stats stock */}
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:0,borderTop:`1px solid ${B.coolGray}`}}>
              {[
                {l:"Disponibles",v:stock.filter(s=>s.estado==="disponible").length, c:B.green},
                {l:"En uso",     v:stock.filter(s=>s.estado==="en_uso").length,     c:B.gold },
                {l:"Dañados",    v:stock.filter(s=>s.estado==="daniado").length,    c:B.red  },
              ].map((s,i)=>(
                <div key={i} style={{padding:"12px 8px",textAlign:"center",borderRight:i<2?`1px solid ${B.coolGray}`:"none"}}>
                  <div style={{fontFamily:"Georgia,serif",fontSize:20,color:s.c,fontWeight:300}}>{s.v}</div>
                  <div style={{fontSize:7,color:B.mid,marginTop:2}}>{s.l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Filtro estado */}
          <div style={{display:"flex",gap:7,marginBottom:14}}>
            {[{id:"all",label:"TODOS"},{id:"disponible",label:"✅ DISPONIBLE"},{id:"en_uso",label:"📦 EN USO"},{id:"daniado",label:"⚠️ DAÑADO"}].map(f=>(
              <button key={f.id} onClick={()=>setFilterEstado(f.id)} style={{padding:"5px 12px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:filterEstado===f.id?B.dark:B.white,color:filterEstado===f.id?B.white:B.mid,border:`1px solid ${filterEstado===f.id?B.dark:B.glacier}`,transition:"all .2s"}}>
                {f.label}
              </button>
            ))}
          </div>

          {stockFiltrado.map((item,i)=>{
            const est = ESTADO_STOCK[item.estado];
            return (
              <div key={item.id} style={{background:B.white,borderRadius:12,marginBottom:8,padding:"14px 16px",border:`1px solid ${item.estado==="daniado"?B.red+"30":B.pinkLight}`,display:"flex",gap:12,alignItems:"flex-start",animation:`fadeUp .25s ease ${i*.03}s both`,boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
                <div style={{width:44,height:44,borderRadius:10,background:est.bg,border:`1px solid ${est.color}30`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>{est.icon}</div>
                <div style={{flex:1}}>
                  <div style={{fontSize:13,fontWeight:700,color:B.text,marginBottom:4}}>{item.nombre}</div>
                  <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:item.obs?4:0}}>
                    <div style={{padding:"2px 8px",borderRadius:20,background:est.bg,border:`1px solid ${est.color}40`,fontSize:8,color:est.color,fontWeight:700}}>{est.label}</div>
                    <div style={{fontFamily:"Georgia,serif",fontSize:18,color:B.text,fontWeight:300}}>{item.cantidad}</div>
                    <div style={{fontSize:8,color:B.mid}}>unidad{item.cantidad!==1?"es":""}</div>
                  </div>
                  {item.obs&&<div style={{fontSize:10,color:B.mid,lineHeight:1.5}}>{item.obs}</div>}
                </div>
                {(userId==="barbara"||userId==="nicole")&&(
                  <div style={{display:"flex",flexDirection:"column",gap:4,flexShrink:0}}>
                    <button onClick={()=>setStock(prev=>prev.map(s=>s.id===item.id?{...s,cantidad:s.cantidad+1}:s))} style={{width:24,height:24,borderRadius:6,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:12,color:B.mid,display:"flex",alignItems:"center",justifyContent:"center"}}>+</button>
                    <button onClick={()=>setStock(prev=>prev.map(s=>s.id===item.id?{...s,cantidad:Math.max(0,s.cantidad-1)}:s))} style={{width:24,height:24,borderRadius:6,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:12,color:B.mid,display:"flex",alignItems:"center",justifyContent:"center"}}>−</button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── MODPLANCARRERA ───────────────────────────────────────────────────────────
// ─── JERARQUÍA DE ROLES ───────────────────────────────────────────────────────
// nivel: cuanto más alto, más permisos
const NIVEL_ROL = {
  owner:        5,
  directora:    4,
  barby:        4,
  franquiciada: 2,
  encargada:    2,
  manicura:     1,
};

// Quién puede EDITAR el plan de carrera de quién
// editor_nivel >= target_nivel → puede editar (con excepciones)
const puedeEditar = (editor, target) => {
  if (!editor || !target) return false;
  if (editor.id === target.id) return true; // uno mismo siempre puede ver/editar notas propias
  if (editor.rol === "owner") return true;
  if ((editor.rol === "directora" || editor.rol === "barby") && NIVEL_ROL[target.rol] <= 2) return true;
  if ((editor.rol === "encargada" || editor.rol === "franquiciada") && target.rol === "manicura" && editor.local === target.local) return true;
  return false;
};

const puedeVer = (viewer, target) => {
  if (!viewer || !target) return false;
  if (viewer.id === target.id) return true;
  if (viewer.rol === "owner") return true;
  if ((viewer.rol === "directora" || viewer.rol === "barby")) return true;
  if ((viewer.rol === "encargada" || viewer.rol === "franquiciada") && target.rol === "manicura" && viewer.local === target.local) return true;
  return false;
};

// ─── USUARIOS DEMO ────────────────────────────────────────────────────────────
const USUARIOS_PC = [
  // Owner
  { id:"nicole", nombre:"Nicole Ulloa", rol:"owner", local:null, avatar:"N", color:B.gold, pass:"nicole2026" },
  // Directoras
  { id:"agustina", nombre:"Agustina Quaglia", rol:"directora", area:"Marketing", local:null, avatar:"A", color:B.pink, pass:"agus2026" },
  { id:"laura",    nombre:"Laura Felipetti",  rol:"directora", area:"RRHH",      local:null, avatar:"L", color:B.pinkDeep, pass:"laura2026" },
  { id:"barbara",  nombre:"Bárbara López",    rol:"directora", area:"Obras",     local:null, avatar:"B", color:"#7A9E9F", pass:"barba2026" },
  { id:"lucia",    nombre:"Lucía Becker",     rol:"directora", area:"Stock",     local:null, avatar:"L2", color:B.purple, pass:"lucia2026" },
  // Barby
  { id:"barby", nombre:"Barby (Secretaria)", rol:"barby", local:null, avatar:"B2", color:B.gold, pass:"barby2026" },
  // Encargadas
  { id:"barbi_ortiz", nombre:"Bárbara Ortiz",   rol:"encargada", local:"Lomas",         avatar:"BO", color:B.pink, pass:"lomas2026" },
  { id:"belen",       nombre:"María Belén B.",  rol:"encargada", local:"Puerto Madero",  avatar:"MB", color:B.gold, pass:"madero2026" },
  { id:"guadalupe",   nombre:"Guadalupe Defalco",rol:"encargada", local:"Mar del Plata", avatar:"GD", color:B.pinkDeep, pass:"mdp2026" },
  // Franquiciadas
  { id:"yanina",  nombre:"Yanina (Bella Vista)", rol:"franquiciada", local:"Bella Vista", avatar:"Y", color:B.pink, pass:"bvista2026" },
  { id:"candela_f",nombre:"Candela (Saavedra)",  rol:"franquiciada", local:"Saavedra",    avatar:"C", color:B.gold, pass:"saav2026" },
  // Manicuras
  { id:"estefania", nombre:"Estefanía Soto",     rol:"manicura", local:"Adrogue",       skill:100, nivel:"master", avatar:"ES", color:B.pink, pass:"esto2026" },
  { id:"candela_a", nombre:"Candela Amaya",      rol:"manicura", local:"Puerto Madero", skill:97,  nivel:"master", avatar:"CA", color:B.pinkDeep, pass:"cama2026" },
  { id:"rosibel",   nombre:"Rosibel Gutiérrez",  rol:"manicura", local:"Puerto Madero", skill:100, nivel:"master", avatar:"RG", color:B.gold, pass:"rogu2026" },
  { id:"brisa_r",   nombre:"Brisa Ramírez",      rol:"manicura", local:"Lomas",         skill:97,  nivel:"master", avatar:"BR", color:"#7A9E9F", pass:"bram2026" },
  { id:"sol",       nombre:"Sol Martínez",        rol:"manicura", local:"Lomas",         skill:74,  nivel:"senior", avatar:"SM", color:B.pink, pass:"solm2026" },
  { id:"daniela_g", nombre:"Daniela Gambarte",   rol:"manicura", local:"Lomas",         skill:91,  nivel:"master", avatar:"DG", color:B.purple, pass:"daga2026" },
  { id:"florencia_a",nombre:"Florencia Antogiovanni",rol:"manicura",local:"Puerto Madero",skill:82,nivel:"senior",avatar:"FA",color:B.gold,pass:"flan2026"},
  { id:"noelia",    nombre:"Noelia Acevedo",      rol:"manicura", local:"Adrogue",       skill:65,  nivel:"senior", avatar:"NA", color:B.pinkDeep, pass:"noac2026" },
];

// ─── 1:1 DEMO ─────────────────────────────────────────────────────────────────
const UNOS_INIT = [
  {
    id:"u1", userId:"estefania", editorId:"laura",
    fecha:"15 Abr 2026", proximoUno:"15 May 2026",
    desempeno:5,
    notas:"Estefanía mantiene un desempeño excepcional. 100% de skill, muy querida por las clientas. Lidera con el ejemplo al resto del equipo de Adrogue.",
    planMejora:"Explorar posibilidad de rol de mentora para manicuras Junior. Capacitación en gestión de equipo.",
    objetivos:["Mantener 100% skill en el próximo skill review","Capacitar a 2 Juniors en kapping","Participar del evento 17/5"],
    estado:"completado",
  },
  {
    id:"u2", userId:"sol", editorId:"barbi_ortiz",
    fecha:"10 Abr 2026", proximoUno:"10 May 2026",
    desempeno:4,
    notas:"Sol está en un muy buen momento. Cumple con los turnos, las clientas la eligen. Tiene potencial de crecimiento claro.",
    planMejora:"Trabajar en técnicas de acrilico para subir del 74% al 86% y alcanzar nivel Master.",
    objetivos:["Tomar capacitación de acrílico en Mayo","Subir skill al 85% antes de Junio","Cero ausencias no avisadas"],
    estado:"completado",
  },
  {
    id:"u3", userId:"noelia", editorId:"barbi_ortiz",
    fecha:"08 Abr 2026", proximoUno:"08 May 2026",
    desempeno:3,
    notas:"Noelia viene mejorando desde el skill review. Actitud positiva pero necesita más práctica en técnicas avanzadas.",
    planMejora:"Acompañamiento semanal de la encargada. Objetivo: pasar de 65% a 72% en el próximo skill review.",
    objetivos:["Practicar kapping gel diariamente","Consultar dudas técnicas con Estefanía","Asistir a la capacitación del 9/4"],
    estado:"completado",
  },
];

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const ROL_LABEL = {
  owner:"Owner", directora:"Directora", barby:"Secretaria",
  franquiciada:"Franquiciada", encargada:"Encargada", manicura:"Manicura",
};
const ROL_COLOR = {
  owner:B.gold, directora:B.pink, barby:B.gold,
  franquiciada:B.pinkDeep, encargada:"#7A9E9F", manicura:B.purple,
};
const NIVEL_COLOR = { master:B.gold, senior:B.pink, junior:B.purple };



function Avatar({u, size=40}) {
  const color = ROL_COLOR[u.rol] || B.pink;
  return (
    <div style={{width:size,height:size,borderRadius:"50%",background:`${color}18`,border:`2px solid ${color}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.3,fontWeight:700,color,flexShrink:0}}>
      {u.avatar}
    </div>
  );
}

function DesempenoStars({value, onChange, readonly}) {
  return (
    <div style={{display:"flex",gap:4}}>
      {[1,2,3,4,5].map(n=>(
        <button key={n} onClick={()=>!readonly&&onChange&&onChange(n)} style={{background:"transparent",padding:2,cursor:readonly?"default":"pointer"}}>
          <svg width={18} height={18} viewBox="0 0 24 24" fill={n<=value?B.gold:"none"} stroke={B.gold} strokeWidth={1.5}>
            <path d="M12 2L13.5 10L22 12L13.5 14L12 22L10.5 14L2 12L10.5 10Z"/>
          </svg>
        </button>
      ))}
      <span style={{fontSize:10,color:B.mid,marginLeft:4,alignSelf:"center"}}>
        {value===5?"Excepcional":value===4?"Muy bueno":value===3?"En desarrollo":value===2?"A mejorar":"Crítico"}
      </span>
    </div>
  );
}

// ─── MAIN ──────────────────────────────────────────────────────────────────────
function ModPlanCarrera({user,onBack}) {
  const [usuarios]         = useState(USUARIOS_PC);
  const [unos, setUnos]    = useState(UNOS_INIT);
  // user comes from parent prop
  const [view, setView]    = useState("login");    // login | register | lista | perfil | nuevo_uno | ver_uno
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedUno, setSelectedUno]   = useState(null);
  const [loginForm, setLoginForm]       = useState({nombre:"", pass:""});
  const [registerForm, setRegisterForm] = useState({nombre:"", rol:"manicura", local:"Lomas", area:"", pass:"", pass2:""});
  const [loginError, setLoginError]     = useState("");
  const [registerError, setRegisterError] = useState("");
  const [newUsuarios, setNewUsuarios]   = useState([]);
  const [filterRol, setFilterRol]       = useState("all");
  const [filterLocal, setFilterLocal]   = useState("all");
  const [newUno, setNewUno]             = useState(null);
  const [nuevoObjetivo, setNuevoObjetivo] = useState("");

  const todosUsuarios = [...usuarios, ...newUsuarios];
  const perfilAbierto = selectedUser ? todosUsuarios.find(u=>u.id===selectedUser) : null;
  const unoAbierto    = selectedUno  ? unos.find(u=>u.id===selectedUno) : null;

  const unosDeUsuario = (uid) => unos.filter(u=>u.userId===uid).sort((a,b)=>new Date(b.fecha)-new Date(a.fecha));

  const puedeEditarTarget = (target) => user && puedeEditar(user, target);
  const puedeVerTarget    = (target) => user && puedeVer(user, target);

  const usuariosVisibles = todosUsuarios.filter(u => {
    if (u.id === user?.id) return true;
    if (!puedeVerTarget(u)) return false;
    if (filterRol !== "all" && u.rol !== filterRol) return false;
    if (filterLocal !== "all" && u.local !== filterLocal) return false;
    return true;
  });

  // Login
  const doLogin = () => {
    setLoginError("");
    const found = todosUsuarios.find(u =>
      u.nombre.toLowerCase().includes(loginForm.nombre.toLowerCase()) &&
      u.pass === loginForm.pass
    );
    if (!found) { setLoginError("Nombre o contraseña incorrectos."); return; }
        setView("lista");
  };

  // Registro
  const doRegister = () => {
    setRegisterError("");
    if (!registerForm.nombre.trim()) { setRegisterError("Ingresá tu nombre completo."); return; }
    if (registerForm.pass.length < 6) { setRegisterError("La contraseña debe tener al menos 6 caracteres."); return; }
    if (registerForm.pass !== registerForm.pass2) { setRegisterError("Las contraseñas no coinciden."); return; }
    const exists = todosUsuarios.find(u=>u.nombre.toLowerCase()===registerForm.nombre.toLowerCase());
    if (exists) { setRegisterError("Ya existe un usuario con ese nombre."); return; }
    const nuevo = {
      id: `u_${Date.now()}`,
      nombre: registerForm.nombre,
      rol: registerForm.rol,
      local: registerForm.local || null,
      area: registerForm.area || null,
      avatar: registerForm.nombre.split(" ").map(w=>w[0]).slice(0,2).join("").toUpperCase(),
      color: ROL_COLOR[registerForm.rol] || B.pink,
      pass: registerForm.pass,
      skill: null, nivel: null,
    };
    setNewUsuarios(prev=>[...prev, nuevo]);
        setView("lista");
  };

  // Publicar 1:1
  const publicarUno = () => {
    if (!newUno?.notas?.trim()) return;
    const uno = {
      id: `uno_${Date.now()}`,
      userId: perfilAbierto.id,
      editorId: user.id,
      fecha: new Date().toLocaleDateString("es-AR",{day:"2-digit",month:"short",year:"numeric"}),
      proximoUno: newUno.proximoUno || "",
      desempeno: newUno.desempeno || 3,
      notas: newUno.notas,
      planMejora: newUno.planMejora || "",
      objetivos: newUno.objetivos || [],
      estado: "completado",
    };
    setUnos(prev=>[uno,...prev]);
    setNewUno(null);
    setView("perfil");
  };

  const LOCALES = ["Lomas","Puerto Madero","Adrogue","Canning","Saavedra","Recoleta","Bella Vista","Belgrano","Cañitas","Banfield","Mar del Plata"];

  const CSS = `
    @import url('https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300&display=swap');
    *{box-sizing:border-box;margin:0;padding:0;}
    ::-webkit-scrollbar{width:3px;}::-webkit-scrollbar-thumb{background:${B.pinkLight};}
    @keyframes fadeUp{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
    @keyframes shimmer{0%,100%{opacity:.55}50%{opacity:1}}
    @keyframes softPulse{0%,100%{opacity:1}50%{opacity:.75}}
    button{cursor:pointer;border:none;font-family:inherit;}
    input,textarea,select{font-family:inherit;outline:none;}
    .card:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(221,164,174,0.14)!important;}
  `;

  // ── LOGIN ──────────────────────────────────────────────────────────────────
  if (view==="login") return (
    <div style={{minHeight:"100vh",maxWidth:430,margin:"0 auto",background:B.pinkBg,fontFamily:"'Lato',sans-serif",position:"relative",overflow:"hidden"}}>
      <style>{CSS}</style>
      <PatternBg opacity={0.06} id="lp"/>
      <div style={{position:"absolute",top:0,left:0,right:0,height:240,background:`linear-gradient(180deg,${B.pinkLight}40,transparent)`,pointerEvents:"none"}}/>

      <div style={{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"40px 28px",position:"relative"}}>
        {/* Logo */}
        <div style={{textAlign:"center",marginBottom:40,animation:"fadeUp .6s ease forwards"}}>
          <div style={{display:"flex",justifyContent:"center",marginBottom:12}}><Star size={20} color={B.gold}/></div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:52,fontWeight:300,letterSpacing:14,textIndent:14,color:B.pink,lineHeight:1}}>NIKI</div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:13,fontStyle:"italic",letterSpacing:4,textIndent:4,color:B.goldLight,marginTop:4,animation:"shimmer 4s ease infinite"}}>beauty bar</div>
          <div style={{marginTop:14,padding:"4px 16px",borderRadius:20,background:B.goldPale,border:`1px solid ${B.goldLight}60`,display:"inline-flex",alignItems:"center",gap:6}}>
            <span style={{fontSize:9,letterSpacing:4,color:B.gold,fontWeight:700}}>OS</span>
            <span style={{fontSize:8,color:B.mid,letterSpacing:2}}>PLAN DE CARRERA</span>
          </div>
        </div>

        {/* Form */}
        <div style={{width:"100%",background:B.white,borderRadius:16,padding:"24px 20px",border:`1px solid ${B.pinkLight}`,boxShadow:"0 4px 20px rgba(221,164,174,0.1)",animation:"fadeUp .6s ease .15s both"}}>
          <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:16}}>INGRESÁ A TU CUENTA</div>

          <div style={{marginBottom:12}}>
            <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:6}}>NOMBRE COMPLETO</div>
            <input
              value={loginForm.nombre}
              onChange={e=>setLoginForm(f=>({...f,nombre:e.target.value}))}
              placeholder="Ej: Estefanía Soto"
              style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:13,color:B.text,background:B.pinkBg}}
              onKeyDown={e=>e.key==="Enter"&&doLogin()}
            />
          </div>

          <div style={{marginBottom:16}}>
            <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:6}}>CONTRASEÑA</div>
            <input
              type="password"
              value={loginForm.pass}
              onChange={e=>setLoginForm(f=>({...f,pass:e.target.value}))}
              placeholder="Tu contraseña"
              style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:13,color:B.text,background:B.pinkBg}}
              onKeyDown={e=>e.key==="Enter"&&doLogin()}
            />
          </div>

          {loginError&&<div style={{padding:"8px 12px",background:"#FEE",border:"1px solid #FCC",borderRadius:8,fontSize:11,color:"#C0392B",marginBottom:12}}>{loginError}</div>}

          <button onClick={doLogin} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:4,boxShadow:`0 5px 16px ${B.pink}30`,display:"flex",alignItems:"center",justifyContent:"center",gap:8}}>
            <Star size={10} color={B.white}/>INGRESAR
          </button>
        </div>

        <button onClick={()=>setView("register")} style={{marginTop:16,background:"transparent",color:B.pink,fontSize:10,fontWeight:700,letterSpacing:1,animation:"fadeUp .6s ease .3s both"}}>
          ¿Primera vez? Registrate →
        </button>

        {/* Demo hints */}
        <div style={{marginTop:20,padding:"12px 14px",background:B.goldPale,borderRadius:10,border:`1px solid ${B.goldLight}30`,width:"100%",animation:"fadeUp .6s ease .4s both"}}>
          <div style={{fontSize:8,color:B.gold,fontWeight:700,letterSpacing:2,marginBottom:8}}>✦ ACCESOS DE DEMO</div>
          {[
            {n:"Nicole Ulloa", p:"nicole2026", r:"Owner"},
            {n:"Laura Felipetti", p:"laura2026", r:"Directora RRHH"},
            {n:"Bárbara Ortiz", p:"lomas2026", r:"Encargada Lomas"},
            {n:"Estefanía Soto", p:"esto2026", r:"Manicura Master"},
          ].map((d,i)=>(
            <div key={i} onClick={()=>setLoginForm({nombre:d.n,pass:d.p})} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:i<3?`1px solid ${B.goldLight}20`:"none",cursor:"pointer"}}>
              <div style={{fontSize:10,color:B.text,fontWeight:700}}>{d.n}</div>
              <div style={{fontSize:9,color:B.mid}}>{d.r} · <span style={{color:B.gold}}>{d.p}</span></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // ── REGISTRO ───────────────────────────────────────────────────────────────
  if (view==="register") return (
    <div style={{minHeight:"100vh",maxWidth:430,margin:"0 auto",background:B.pinkBg,fontFamily:"'Lato',sans-serif",position:"relative",overflow:"hidden"}}>
      <style>{CSS}</style>
      <PatternBg opacity={0.05} id="rp"/>

      <div style={{padding:"24px 24px 40px",position:"relative"}}>
        <button onClick={()=>setView("login")} style={{background:"transparent",color:B.mid,fontSize:10,fontWeight:700,marginBottom:20,display:"flex",alignItems:"center",gap:4}}>← Volver</button>

        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:26,color:B.text,fontWeight:300,marginBottom:4}}>Crear cuenta ✨</div>
        <div style={{fontSize:10,color:B.mid,marginBottom:24}}>Completá tus datos para unirte a NIKI OS</div>

        {[
          {key:"nombre", label:"NOMBRE COMPLETO", placeholder:"Tu nombre y apellido", type:"text"},
          {key:"pass",   label:"CONTRASEÑA",       placeholder:"Mínimo 6 caracteres",  type:"password"},
          {key:"pass2",  label:"REPETIR CONTRASEÑA",placeholder:"Repetí tu contraseña",type:"password"},
        ].map(f=>(
          <div key={f.key} style={{marginBottom:12}}>
            <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:6}}>{f.label}</div>
            <input
              type={f.type} value={registerForm[f.key]}
              onChange={e=>setRegisterForm(r=>({...r,[f.key]:e.target.value}))}
              placeholder={f.placeholder}
              style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:13,color:B.text,background:B.white}}
            />
          </div>
        ))}

        <div style={{marginBottom:12}}>
          <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:8}}>ROL</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            {[{k:"manicura",l:"💅 Manicura"},{k:"encargada",l:"⭐ Encargada"},{k:"franquiciada",l:"◈ Franquiciada"},{k:"directora",l:"✦ Directora"}].map(r=>(
              <button key={r.k} onClick={()=>setRegisterForm(f=>({...f,rol:r.k}))} style={{padding:"10px",background:registerForm.rol===r.k?`${ROL_COLOR[r.k]}15`:B.white,border:`1.5px solid ${registerForm.rol===r.k?ROL_COLOR[r.k]:B.pinkLight}`,borderRadius:10,fontSize:10,color:registerForm.rol===r.k?ROL_COLOR[r.k]:B.mid,fontWeight:700,transition:"all .2s"}}>{r.l}</button>
            ))}
          </div>
        </div>

        {["manicura","encargada","franquiciada"].includes(registerForm.rol)&&(
          <div style={{marginBottom:12}}>
            <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:6}}>LOCAL</div>
            <select value={registerForm.local} onChange={e=>setRegisterForm(f=>({...f,local:e.target.value}))} style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,background:B.white}}>
              {LOCALES.map(l=><option key={l}>{l}</option>)}
            </select>
          </div>
        )}

        {registerForm.rol==="directora"&&(
          <div style={{marginBottom:12}}>
            <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:6}}>ÁREA</div>
            <input value={registerForm.area} onChange={e=>setRegisterForm(f=>({...f,area:e.target.value}))} placeholder="Ej: RRHH, Marketing, Obras..." style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,background:B.white}}/>
          </div>
        )}

        {registerError&&<div style={{padding:"8px 12px",background:"#FEE",border:"1px solid #FCC",borderRadius:8,fontSize:11,color:"#C0392B",marginBottom:12}}>{registerError}</div>}

        <button onClick={doRegister} style={{width:"100%",padding:"14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,boxShadow:`0 5px 16px ${B.pink}30`,display:"flex",alignItems:"center",justifyContent:"center",gap:8,marginTop:8}}>
          <Star size={10} color={B.white}/>CREAR CUENTA
        </button>
      </div>
    </div>
  );

  // ── LISTA ──────────────────────────────────────────────────────────────────
  if (view==="lista") return (
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <style>{CSS}</style>

      {/* Header */}
      <div style={{background:B.white,padding:"14px 18px 0",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <Star size={12} color={B.gold}/>
            <div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:300,letterSpacing:4,textIndent:4,color:B.pink}}>Plan de Carrera ✨</div>
              <div style={{fontSize:7,letterSpacing:2,color:B.mid}}>NIKI OS · {user.nombre}</div>
            </div>
          </div>
          <button onClick={()=>{setUser(null);setView("login");}} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 12px",fontSize:9,color:B.mid,fontWeight:700}}>Salir</button>
        </div>

        {/* Mi perfil rápido */}
        <div style={{display:"flex",gap:10,alignItems:"center",padding:"10px 0 12px"}}>
          <Avatar u={user} size={36}/>
          <div style={{flex:1}}>
            <div style={{fontSize:12,fontWeight:700,color:B.text}}>{user.nombre}</div>
            <div style={{display:"flex",gap:6,marginTop:3}}>
              <div style={{padding:"2px 8px",borderRadius:20,background:`${ROL_COLOR[user.rol]}15`,border:`1px solid ${ROL_COLOR[user.rol]}40`,fontSize:7,color:ROL_COLOR[user.rol],fontWeight:700}}>{ROL_LABEL[user.rol]}</div>
              {user.local&&<div style={{padding:"2px 8px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:7,color:B.mid}}>📍 {user.local}</div>}
              {user.area&&<div style={{padding:"2px 8px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:7,color:B.mid}}>{user.area}</div>}
            </div>
          </div>
          <button onClick={()=>{setSelectedUser(user.id);setView("perfil");}} style={{padding:"6px 12px",background:`${B.pink}15`,border:`1px solid ${B.pink}40`,borderRadius:8,fontSize:9,color:B.pink,fontWeight:700}}>Mi perfil</button>
        </div>
      </div>

      <div style={{padding:"16px",paddingBottom:40}}>
        {/* Filtros */}
        {NIVEL_ROL[user.rol] >= 2 && (
          <div style={{display:"flex",gap:8,marginBottom:14,overflowX:"auto",scrollbarWidth:"none"}}>
            {["all","manicura","encargada","franquiciada","directora"].map(r=>(
              <button key={r} onClick={()=>setFilterRol(r)} style={{padding:"5px 12px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:filterRol===r?B.dark:B.white,color:filterRol===r?B.white:B.mid,border:`1px solid ${filterRol===r?B.dark:B.glacier}`,transition:"all .2s"}}>
                {r==="all"?"TODOS":ROL_LABEL[r].toUpperCase()}
              </button>
            ))}
          </div>
        )}

        {/* Stats rápidas */}
        {NIVEL_ROL[user.rol] >= 2 && (
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:16}}>
            {[
              {l:"Personas",  v:usuariosVisibles.length,                c:B.pink},
              {l:"1:1 este mes", v:unos.filter(u=>{const d=new Date(u.fecha);return d.getMonth()===new Date().getMonth();}).length, c:B.gold},
              {l:"Pendientes", v:usuariosVisibles.filter(u=>unosDeUsuario(u.id).length===0).length, c:"#9B8EA6"},
            ].map((s,i)=>(
              <div key={i} style={{background:B.white,borderRadius:12,padding:"12px 8px",border:`1px solid ${B.pinkLight}`,textAlign:"center",boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
                <div style={{fontFamily:"Georgia,serif",fontSize:22,color:s.c,fontWeight:300,lineHeight:1}}>{s.v}</div>
                <div style={{fontSize:7,color:B.mid,marginTop:3}}>{s.l}</div>
              </div>
            ))}
          </div>
        )}

        <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:12}}>
          {NIVEL_ROL[user.rol] >= 2 ? "EQUIPO" : "MI PLAN DE CARRERA"}
        </div>

        {usuariosVisibles.map((u,i)=>{
          const misUnos = unosDeUsuario(u.id);
          const ultimo  = misUnos[0];
          const canEdit = puedeEditarTarget(u);
          return (
            <div key={u.id} className="card" onClick={()=>{setSelectedUser(u.id);setView("perfil");}} style={{background:B.white,borderRadius:14,marginBottom:10,border:`1.5px solid ${B.pinkLight}`,cursor:"pointer",overflow:"hidden",transition:"all .2s",boxShadow:"0 2px 8px rgba(221,164,174,0.06)",animation:`fadeUp .3s ease ${i*.04}s both`}}>
              <div style={{height:3,background:`linear-gradient(90deg,${ROL_COLOR[u.rol]}60,${ROL_COLOR[u.rol]})`}}/>
              <div style={{padding:"14px 16px"}}>
                <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
                  <Avatar u={u} size={44}/>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:700,color:B.text,marginBottom:3}}>{u.nombre}</div>
                    <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:6}}>
                      <div style={{padding:"2px 8px",borderRadius:20,background:`${ROL_COLOR[u.rol]}12`,border:`1px solid ${ROL_COLOR[u.rol]}35`,fontSize:7,color:ROL_COLOR[u.rol],fontWeight:700}}>{ROL_LABEL[u.rol]}</div>
                      {u.local&&<div style={{padding:"2px 8px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:7,color:B.mid}}>📍 {u.local}</div>}
                      {u.nivel&&<div style={{padding:"2px 8px",borderRadius:20,background:`${NIVEL_COLOR[u.nivel]}12`,border:`1px solid ${NIVEL_COLOR[u.nivel]}35`,fontSize:7,color:NIVEL_COLOR[u.nivel],fontWeight:700}}>{u.nivel.charAt(0).toUpperCase()+u.nivel.slice(1)}</div>}
                    </div>
                    {ultimo?(
                      <div style={{display:"flex",alignItems:"center",gap:6}}>
                        <div style={{display:"flex",gap:2}}>
                          {[1,2,3,4,5].map(n=>(
                            <svg key={n} width={10} height={10} viewBox="0 0 24 24" fill={n<=ultimo.desempeno?B.gold:"none"} stroke={B.gold} strokeWidth={2}>
                              <path d="M12 2L13.5 10L22 12L13.5 14L12 22L10.5 14L2 12L10.5 10Z"/>
                            </svg>
                          ))}
                        </div>
                        <div style={{fontSize:8,color:B.mid}}>Último 1:1: {ultimo.fecha}</div>
                      </div>
                    ):(
                      <div style={{fontSize:9,color:"#E88A50",fontWeight:700}}>Sin 1:1 registrado</div>
                    )}
                  </div>
                  <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4}}>
                    {canEdit&&<div style={{fontSize:8,color:B.green,fontWeight:700}}>✏️ Puede editar</div>}
                    {!canEdit&&u.id!==user?.id&&<div style={{fontSize:8,color:B.mid}}>👁 Solo ver</div>}
                    <div style={{color:B.glacier,fontSize:14}}>›</div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  // ── PERFIL ─────────────────────────────────────────────────────────────────
  if (view==="perfil" && perfilAbierto) {
    const misUnos  = unosDeUsuario(perfilAbierto.id);
    const canEdit  = puedeEditarTarget(perfilAbierto);
    const esPropio = perfilAbierto.id === user?.id;

    return (
      <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
        <style>{CSS}</style>

        {/* Header */}
        <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)",display:"flex",alignItems:"center",gap:10}}>
          <button onClick={()=>setView("lista")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:700,color:B.text}}>Plan de Carrera ✨</div>
            <div style={{fontSize:8,color:B.mid}}>{esPropio?"Mi perfil":perfilAbierto.nombre}</div>
          </div>
          {canEdit&&(
            <button onClick={()=>{setNewUno({desempeno:3,notas:"",planMejora:"",objetivos:[],proximoUno:""});setView("nuevo_uno");}} style={{padding:"8px 14px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:8,color:B.white,fontSize:9,fontWeight:700,letterSpacing:1,boxShadow:`0 3px 10px ${B.pink}30`}}>
              + 1:1
            </button>
          )}
        </div>

        <div style={{paddingBottom:40}}>
          {/* Hero perfil */}
          <div style={{background:B.white,padding:"20px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"relative",overflow:"hidden"}}>
            <PatternBg opacity={0.04} id="pp-p"/>
            <div style={{position:"relative",display:"flex",gap:14,alignItems:"flex-start"}}>
              <Avatar u={perfilAbierto} size={60}/>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:B.text,fontWeight:300,marginBottom:6}}>{perfilAbierto.nombre}</div>
                <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:8}}>
                  <div style={{padding:"3px 10px",borderRadius:20,background:`${ROL_COLOR[perfilAbierto.rol]}15`,border:`1px solid ${ROL_COLOR[perfilAbierto.rol]}40`,fontSize:8,color:ROL_COLOR[perfilAbierto.rol],fontWeight:700}}>{ROL_LABEL[perfilAbierto.rol]}</div>
                  {perfilAbierto.local&&<div style={{padding:"3px 10px",borderRadius:20,background:B.coolGray,border:`1px solid ${B.glacier}`,fontSize:8,color:B.mid}}>📍 {perfilAbierto.local}</div>}
                  {perfilAbierto.nivel&&<div style={{padding:"3px 10px",borderRadius:20,background:`${NIVEL_COLOR[perfilAbierto.nivel]}15`,border:`1px solid ${NIVEL_COLOR[perfilAbierto.nivel]}40`,fontSize:8,color:NIVEL_COLOR[perfilAbierto.nivel],fontWeight:700}}>{perfilAbierto.nivel.charAt(0).toUpperCase()+perfilAbierto.nivel.slice(1)}</div>}
                </div>
                {perfilAbierto.skill&&(
                  <div>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                      <div style={{fontSize:8,color:B.mid}}>Skill actual</div>
                      <div style={{fontSize:8,color:B.gold,fontWeight:700}}>{perfilAbierto.skill}%</div>
                    </div>
                    <div style={{height:4,background:B.coolGray,borderRadius:2,overflow:"hidden"}}>
                      <div style={{width:`${perfilAbierto.skill}%`,height:"100%",background:`linear-gradient(90deg,${B.pink},${B.gold})`,borderRadius:2}}/>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Permiso visible */}
            <div style={{marginTop:14,padding:"8px 12px",background:canEdit?B.greenPale:B.goldPale,borderRadius:8,border:`1px solid ${canEdit?B.green:B.gold}30`,fontSize:9,color:canEdit?B.green:B.gold,fontWeight:700}}>
              {canEdit?"✏️ Podés registrar y editar 1:1 de esta persona":"👁 Podés ver el historial de esta persona"}
            </div>
          </div>

          {/* Stats 1:1 */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,padding:"14px 16px 0"}}>
            {[
              {l:"1:1 realizados", v:misUnos.length,                      c:B.pink},
              {l:"Desempeño prom.", v:misUnos.length>0?(misUnos.reduce((a,u)=>a+u.desempeno,0)/misUnos.length).toFixed(1):"—", c:B.gold},
              {l:"Próximo 1:1",    v:misUnos[0]?.proximoUno||"Sin fecha", c:B.purple, small:true},
            ].map((s,i)=>(
              <div key={i} style={{background:B.white,borderRadius:12,padding:"12px 8px",border:`1px solid ${B.pinkLight}`,textAlign:"center",boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
                <div style={{fontFamily:"Georgia,serif",fontSize:s.small?11:20,color:s.c,fontWeight:300,lineHeight:1.2}}>{s.v}</div>
                <div style={{fontSize:7,color:B.mid,marginTop:3}}>{s.l}</div>
              </div>
            ))}
          </div>

          {/* Historial 1:1 */}
          <div style={{padding:"14px 16px 0"}}>
            <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:12}}>HISTORIAL DE 1:1</div>
            {misUnos.length===0&&(
              <div style={{background:B.white,borderRadius:12,padding:"28px",textAlign:"center",border:`1px solid ${B.pinkLight}`}}>
                <div style={{fontSize:32,marginBottom:10}}>📋</div>
                <div style={{fontSize:12,color:B.text,fontWeight:700,marginBottom:4}}>Sin 1:1 registrados</div>
                <div style={{fontSize:10,color:B.mid}}>{canEdit?"Tocá + 1:1 para registrar el primero":"Aún no hay registros"}</div>
              </div>
            )}
            {misUnos.map((u,i)=>{
              const editor = todosUsuarios.find(us=>us.id===u.editorId);
              return(
                <div key={u.id} className="card" onClick={()=>{setSelectedUno(u.id);setView("ver_uno");}} style={{background:B.white,borderRadius:14,marginBottom:10,border:`1px solid ${B.pinkLight}`,cursor:"pointer",overflow:"hidden",transition:"all .2s",boxShadow:"0 2px 8px rgba(221,164,174,0.06)",animation:`fadeUp .3s ease ${i*.05}s both`}}>
                  <div style={{height:3,background:`linear-gradient(90deg,${B.pink}60,${B.gold})`}}/>
                  <div style={{padding:"14px 16px"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                      <div>
                        <div style={{fontSize:12,fontWeight:700,color:B.text,marginBottom:4}}>1:1 · {u.fecha}</div>
                        {editor&&<div style={{fontSize:9,color:B.mid}}>Por {editor.nombre}</div>}
                      </div>
                      <DesempenoStars value={u.desempeno} readonly/>
                    </div>
                    <div style={{fontSize:11,color:B.mid,lineHeight:1.5,marginBottom:8}}>{u.notas.substring(0,90)}{u.notas.length>90?"...":""}</div>
                    {u.proximoUno&&(
                      <div style={{padding:"5px 10px",background:B.goldPale,borderRadius:8,border:`1px solid ${B.goldLight}30`,fontSize:9,color:B.gold,fontWeight:700,display:"inline-block"}}>
                        📅 Próximo: {u.proximoUno}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // ── VER 1:1 ────────────────────────────────────────────────────────────────
  if (view==="ver_uno" && unoAbierto) {
    const editor = todosUsuarios.find(u=>u.id===unoAbierto.editorId);
    const target = todosUsuarios.find(u=>u.id===unoAbierto.userId);
    return (
      <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
        <style>{CSS}</style>
        <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)",display:"flex",alignItems:"center",gap:10}}>
          <button onClick={()=>setView("perfil")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:700,color:B.text}}>Registro 1:1 ✨</div>
            <div style={{fontSize:8,color:B.mid}}>{target?.nombre} · {unoAbierto.fecha}</div>
          </div>
        </div>

        <div style={{padding:"16px",paddingBottom:40}}>
          {/* Desempeño */}
          <div style={{background:B.white,borderRadius:14,padding:"18px",border:`1px solid ${B.pinkLight}`,marginBottom:12,boxShadow:"0 2px 8px rgba(221,164,174,0.06)",position:"relative",overflow:"hidden"}}>
            <PatternBg opacity={0.04} id="uno-p"/>
            <div style={{position:"relative"}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:12}}>DESEMPEÑO</div>
              <DesempenoStars value={unoAbierto.desempeno} readonly/>
              <div style={{marginTop:12,display:"flex",gap:10}}>
                {editor&&<div style={{fontSize:9,color:B.mid}}>Registrado por <strong style={{color:B.text}}>{editor.nombre}</strong></div>}
                {unoAbierto.proximoUno&&<div style={{fontSize:9,color:B.gold,fontWeight:700,marginLeft:"auto"}}>📅 {unoAbierto.proximoUno}</div>}
              </div>
            </div>
          </div>

          {/* Notas */}
          <div style={{background:B.white,borderRadius:12,padding:"16px",border:`1px solid ${B.pinkLight}`,marginBottom:10,boxShadow:"0 2px 8px rgba(221,164,174,0.06)"}}>
            <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:10}}>📝 NOTAS DE LA REUNIÓN</div>
            <div style={{fontSize:13,color:B.text,lineHeight:1.7}}>{unoAbierto.notas}</div>
          </div>

          {/* Plan de mejora */}
          {unoAbierto.planMejora&&(
            <div style={{background:B.goldPale,borderRadius:12,padding:"16px",border:`1px solid ${B.goldLight}30`,marginBottom:10}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.gold,fontWeight:700,marginBottom:10}}>✨ PLAN DE MEJORA</div>
              <div style={{fontSize:13,color:B.text,lineHeight:1.7}}>{unoAbierto.planMejora}</div>
            </div>
          )}

          {/* Objetivos */}
          {unoAbierto.objetivos?.length>0&&(
            <div style={{background:B.greenPale,borderRadius:12,padding:"16px",border:`1px solid ${B.green}30`,marginBottom:10}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.green,fontWeight:700,marginBottom:10}}>🎯 OBJETIVOS</div>
              {unoAbierto.objetivos.map((o,i)=>(
                <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start",marginBottom:6}}>
                  <div style={{width:18,height:18,borderRadius:"50%",background:B.green,display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,color:B.white,flexShrink:0,marginTop:1}}>✓</div>
                  <div style={{fontSize:12,color:B.text,lineHeight:1.5}}>{o}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // ── NUEVO 1:1 ──────────────────────────────────────────────────────────────
  if (view==="nuevo_uno" && perfilAbierto && newUno) {
    return (
      <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
        <style>{CSS}</style>
        <div style={{background:B.white,padding:"14px 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)",display:"flex",alignItems:"center",gap:10}}>
          <button onClick={()=>setView("perfil")} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"7px 14px",fontSize:10,color:B.mid,fontWeight:700}}>←</button>
          <div style={{flex:1}}>
            <div style={{fontSize:13,fontWeight:700,color:B.text}}>Nuevo 1:1 ✨</div>
            <div style={{fontSize:8,color:B.mid}}>con {perfilAbierto.nombre}</div>
          </div>
        </div>

        <div style={{padding:"16px",paddingBottom:100}}>
          {/* Desempeño */}
          <div style={{background:B.white,borderRadius:12,padding:"16px",border:`1px solid ${B.pinkLight}`,marginBottom:12,boxShadow:"0 2px 8px rgba(221,164,174,0.06)"}}>
            <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:12}}>ESCALA DE DESEMPEÑO</div>
            <DesempenoStars value={newUno.desempeno} onChange={v=>setNewUno(n=>({...n,desempeno:v}))}/>
          </div>

          {/* Notas */}
          <div style={{marginBottom:12}}>
            <div style={{fontSize:8,color:B.mid,letterSpacing:2,fontWeight:700,marginBottom:8}}>📝 NOTAS DE LA REUNIÓN *</div>
            <textarea value={newUno.notas} onChange={e=>setNewUno(n=>({...n,notas:e.target.value}))} placeholder="¿Qué se habló en el 1:1? Actitud, desempeño, situaciones del mes, logros..." rows={5} style={{width:"100%",padding:"12px 14px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,lineHeight:1.6,resize:"none",background:B.white}}/>
          </div>

          {/* Plan de mejora */}
          <div style={{marginBottom:12}}>
            <div style={{fontSize:8,color:B.gold,letterSpacing:2,fontWeight:700,marginBottom:8}}>✨ PLAN DE MEJORA</div>
            <textarea value={newUno.planMejora} onChange={e=>setNewUno(n=>({...n,planMejora:e.target.value}))} placeholder="¿Qué acciones concretas se acordaron para mejorar?" rows={3} style={{width:"100%",padding:"12px 14px",border:`1.5px solid ${B.goldLight}40`,borderRadius:10,fontSize:12,color:B.text,lineHeight:1.6,resize:"none",background:B.goldPale}}/>
          </div>

          {/* Objetivos */}
          <div style={{marginBottom:12}}>
            <div style={{fontSize:8,color:B.green,letterSpacing:2,fontWeight:700,marginBottom:8}}>🎯 OBJETIVOS ACORDADOS</div>
            {newUno.objetivos.map((o,i)=>(
              <div key={i} style={{display:"flex",gap:8,alignItems:"center",marginBottom:6}}>
                <div style={{flex:1,padding:"9px 12px",background:B.greenPale,border:`1px solid ${B.green}30`,borderRadius:8,fontSize:11,color:B.text}}>{o}</div>
                <button onClick={()=>setNewUno(n=>({...n,objetivos:n.objetivos.filter((_,fi)=>fi!==i)}))} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:6,width:28,height:28,fontSize:12,color:B.mid}}>×</button>
              </div>
            ))}
            <div style={{display:"flex",gap:8}}>
              <input value={nuevoObjetivo} onChange={e=>setNuevoObjetivo(e.target.value)} placeholder="Agregar objetivo..." onKeyDown={e=>{if(e.key==="Enter"&&nuevoObjetivo.trim()){setNewUno(n=>({...n,objetivos:[...n.objetivos,nuevoObjetivo.trim()]}));setNuevoObjetivo("");}}} style={{flex:1,padding:"9px 12px",border:`1.5px solid ${B.green}40`,borderRadius:8,fontSize:12,color:B.text,background:B.greenPale}}/>
              <button onClick={()=>{if(nuevoObjetivo.trim()){setNewUno(n=>({...n,objetivos:[...n.objetivos,nuevoObjetivo.trim()]}));setNuevoObjetivo("");}}} style={{padding:"9px 14px",background:B.green,borderRadius:8,color:B.white,fontSize:11,fontWeight:700}}>+</button>
            </div>
          </div>

          {/* Próximo 1:1 */}
          <div style={{marginBottom:16}}>
            <div style={{fontSize:8,color:B.mid,letterSpacing:2,fontWeight:700,marginBottom:8}}>📅 FECHA DEL PRÓXIMO 1:1</div>
            <input type="date" value={newUno.proximoUno} onChange={e=>setNewUno(n=>({...n,proximoUno:e.target.value}))} style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:10,fontSize:12,color:B.text,background:B.white}}/>
          </div>
        </div>

        {/* Footer publicar */}
        <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,padding:"12px 16px 24px",background:B.white,borderTop:`1px solid ${B.pinkLight}`,boxShadow:"0 -2px 12px rgba(221,164,174,0.08)"}}>
          <button onClick={publicarUno} disabled={!newUno.notas?.trim()} style={{width:"100%",padding:"14px",background:newUno.notas?.trim()?`linear-gradient(135deg,${B.pink},${B.pinkDeep})`:B.glacier,borderRadius:10,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:8,boxShadow:newUno.notas?.trim()?`0 5px 16px ${B.pink}35`:"none",transition:"all .3s"}}>
            <Star size={10} color={B.white}/>GUARDAR 1:1
          </button>
        </div>
      </div>
    );
  }

  return null;
}

// ─── MÓDULO GENÉRICO (placeholder) ───────────────────────────────────────────
function ModGenerico({mod,onBack}){
  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto"}}>
      <div style={{background:B.white,padding:"13px 18px",borderBottom:`1px solid ${B.pinkLight}`,display:"flex",alignItems:"center",gap:10,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
        <button onClick={onBack} style={{background:B.coolGray,border:`1px solid ${B.glacier}`,borderRadius:8,padding:"6px 13px",fontSize:10,color:B.mid,fontWeight:700}}>← OS</button>
        <div style={{flex:1}}><div style={{fontSize:13,fontWeight:700,color:B.text}}>{mod.emoji} {mod.label}</div><div style={{fontSize:8,color:B.mid}}>{mod.desc}</div></div>
      </div>
      <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:"70vh",padding:"32px 24px",textAlign:"center"}}>
        <div style={{fontSize:52,marginBottom:16}}>{mod.emoji}</div>
        <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,color:B.text,fontWeight:300,letterSpacing:2,marginBottom:8}}>{mod.label} ✨</div>
        <div style={{fontSize:12,color:B.mid,lineHeight:1.6,maxWidth:260,marginBottom:20}}>{mod.desc}</div>
        <div style={{padding:"10px 18px",background:B.goldPale,borderRadius:10,border:`1px solid ${"#CAA150"}30`,fontSize:10,color:"#CAA150",fontWeight:700}}>Módulo disponible en la versión integrada</div>
      </div>
    </div>
  );
}

// ─── MAIN NIKI OS ──────────────────────────────────────────────────────────────
export default function NikiOS() {
  const [screen,setScreen]=useState("login");
  const [usuarios,setUsuarios]=useState(USUARIOS_INIT);
  const [user,setUser]=useState(null);
  const [loginForm,setLoginForm]=useState({email:"",pass:""});
  const [loginError,setLoginError]=useState("");
  const [regForm,setRegForm]=useState({nombre:"",email:"",pass:"",pass2:"",codigo:"",emoji:"✨"});
  const [regError,setRegError]=useState("");
  const [regStep,setRegStep]=useState(1);
  const [codigoOk,setCodigoOk]=useState(null);
  const [emojiGrupo,setEmojiGrupo]=useState(0);
  const [mainTab,setMainTab]=useState("home");
  const [activeModule,setActiveModule]=useState(null);
  const [blogOpen,setBlogOpen]=useState(null);
  const countdown=useCountdown("2026-05-17T10:00:00");

  const pd=user?PERFILES[user.perfil]:null;
  const permisos=user?PERMISOS[user.perfil]:[];
  const canAccess=id=>permisos.includes(id);

  // Login
  const doLogin=()=>{
    setLoginError("");
    const u=usuarios.find(u=>u.email.toLowerCase()===loginForm.email.toLowerCase().trim()&&u.pass===loginForm.pass);
    if(!u){setLoginError("Mail o contraseña incorrectos.");return;}
    setUser(u);setScreen("app");
  };

  // Registro
  const validarCodigo=()=>{
    setRegError("");
    const d=CODIGOS[regForm.codigo.trim().toUpperCase()];
    if(!d){setRegError("Código inválido. Pedíselo a la administradora.");return;}
    if(usuarios.find(u=>u.codigoUsado===regForm.codigo.trim().toUpperCase())){setRegError("Este código ya fue usado.");return;}
    setCodigoOk(d);setRegStep(2);
  };
  const validarDatos=()=>{
    setRegError("");
    if(!regForm.nombre.trim()){setRegError("Ingresá tu nombre completo.");return;}
    if(!regForm.email.includes("@")){setRegError("Mail inválido.");return;}
    if(usuarios.find(u=>u.email.toLowerCase()===regForm.email.toLowerCase().trim())){setRegError("Ya existe una cuenta con ese mail.");return;}
    if(regForm.pass.length<6){setRegError("Contraseña mínimo 6 caracteres.");return;}
    if(regForm.pass!==regForm.pass2){setRegError("Las contraseñas no coinciden.");return;}
    setRegStep(3);
  };
  const finalizarReg=()=>{
    const nuevo={id:`u_${Date.now()}`,nombre:regForm.nombre.trim(),email:regForm.email.trim().toLowerCase(),pass:regForm.pass,perfil:codigoOk.perfil,local:codigoOk.local,emoji:regForm.emoji,codigoUsado:regForm.codigo.trim().toUpperCase()};
    setUsuarios(p=>[...p,nuevo]);setUser(nuevo);setScreen("app");
  };

  // Módulo activo
  if(activeModule){
    const mod=MODULES_LIST.find(m=>m.id===activeModule);
    const back=()=>setActiveModule(null);
    if(activeModule==="comunicaciones")  return <div><style>{CSS}</style><ModComunicaciones user={user} onBack={back}/></div>;
    if(activeModule==="rewards")         return <div><style>{CSS}</style><ModRewards user={user} onBack={back}/></div>;
    if(activeModule==="cotizador")       return <div><style>{CSS}</style><ModCotizador user={user} onBack={back}/></div>;
    if(activeModule==="lab")             return <div><style>{CSS}</style><ModLab user={user} onBack={back}/></div>;
    if(activeModule==="blog")            return <div><style>{CSS}</style><ModBlog user={user} onBack={back}/></div>;
    if(activeModule==="frases")          return <div><style>{CSS}</style><ModFrases onBack={back}/></div>;
    if(activeModule==="auditorias")      return <div><style>{CSS}</style><ModAuditorias user={user} onBack={back}/></div>;
    if(activeModule==="obras")           return <div><style>{CSS}</style><ModObras user={user} onBack={back}/></div>;
    if(activeModule==="rrhh")            return <div><style>{CSS}</style><ModRRHH user={user} onBack={back}/></div>;
    if(activeModule==="proyectos")       return <div><style>{CSS}</style><ModProyectosStock user={user} onBack={back}/></div>;
    if(activeModule==="stock")           return <div><style>{CSS}</style><ModProyectosStock user={user} onBack={back}/></div>;
    if(activeModule==="plan_carrera")    return <div><style>{CSS}</style><ModPlanCarrera user={user} onBack={back}/></div>;
    return <div><style>{CSS}</style><ModGenerico mod={mod} onBack={back}/></div>;
  }

  // ── LOGIN ──────────────────────────────────────────────────────────────────
  if(screen==="login") return(
    <div style={{minHeight:"100vh",maxWidth:430,margin:"0 auto",background:B.pinkBg,position:"relative",overflow:"hidden",fontFamily:"'Lato',sans-serif"}}>
      <style>{CSS}</style>
      <PatternBg opacity={0.05} id="l-p"/>
      <div style={{position:"absolute",top:0,left:0,right:0,height:270,background:`linear-gradient(180deg,${B.pinkLight}40,transparent)`,pointerEvents:"none"}}/>
      <div style={{position:"absolute",inset:0,pointerEvents:"none",overflow:"hidden"}}>
        <div style={{position:"absolute",top:"10%",left:"50%",transform:"translateX(-50%)",width:200,height:200,borderRadius:"50%",background:"rgba(202,161,80,0.3)",filter:"blur(60px)",animation:"glowPulse 3s ease-in-out infinite"}}/>
        {[[26,"13%","10%",""],[14,"18%","","9%",.45],[20,"7%","","20%",.5],[10,"23%","27%","","destelloPulse",.35],[15,"","20%","7%","destelloFloat 3s",.35]].map(([s,t,l,r,an,op],i)=>(
          <Destello key={i} size={s} color="#CAA150" style={{position:"absolute",top:t,bottom:["","","","","20%"][i],left:l,right:r,opacity:op||.6,animation:`${an||"destelloFloat"} ${2.8+i*.3}s ease-in-out infinite ${i*.2}s`}}/>
        ))}
      </div>
      <div style={{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"36px 24px",position:"relative"}}>
        {/* Logo */}
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",textAlign:"center",marginBottom:28,animation:"fadeUp .7s ease forwards"}}>
          <div style={{position:"relative",marginBottom:11}}>
            <div style={{position:"absolute",inset:-9,borderRadius:"50%",background:"rgba(202,161,80,0.35)",filter:"blur(13px)",animation:"destelloPulse 2s ease-in-out infinite"}}/>
            <Destello size={36} color="#CAA150" style={{position:"relative",display:"block",animation:"destelloSpin 7s linear infinite",filter:"drop-shadow(0 0 5px rgba(202,161,80,0.7))"}}/>
          </div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:64,fontWeight:300,letterSpacing:16,paddingLeft:16,color:B.pink,lineHeight:1}}>NIKI</div>
          <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:13,fontStyle:"italic",letterSpacing:5,paddingLeft:5,color:B.goldLight,marginTop:5,animation:"shimmer 4s ease infinite"}}>beauty bar</div>
          <div style={{display:"flex",alignItems:"center",gap:8,marginTop:12}}>
            <div style={{width:28,height:1,background:"linear-gradient(90deg,transparent,rgba(202,161,80,0.5))"}}/>
            <div style={{padding:"3px 13px",borderRadius:20,background:B.goldPale,border:"1px solid rgba(202,161,80,0.4)",display:"flex",alignItems:"center",gap:5}}>
              <Destello size={7} color="#CAA150" style={{animation:"destelloPulse 2s ease-in-out infinite"}}/>
              <span style={{fontSize:9,letterSpacing:5,color:"#CAA150",fontWeight:700}}>OS</span>
              <span style={{fontSize:8,color:B.mid,letterSpacing:2}}>SISTEMA OPERATIVO</span>
            </div>
            <div style={{width:28,height:1,background:"linear-gradient(90deg,rgba(202,161,80,0.5),transparent)"}}/>
          </div>
        </div>
        {/* Form */}
        <div style={{width:"100%",background:B.white,borderRadius:14,padding:"20px 18px",border:`1px solid ${B.pinkLight}`,boxShadow:"0 4px 18px rgba(221,164,174,0.1)",animation:"fadeUp .7s ease .15s both",marginBottom:10}}>
          <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:14}}>INGRESÁ A TU CUENTA</div>
          {[{k:"email",l:"MAIL",p:"tu@mail.com",t:"email"},{k:"pass",l:"CONTRASEÑA",p:"••••••••",t:"password"}].map(f=>(
            <div key={f.k} style={{marginBottom:10}}>
              <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:5}}>{f.l}</div>
              <input type={f.t} value={loginForm[f.k]} onChange={e=>setLoginForm(v=>({...v,[f.k]:e.target.value}))} onKeyDown={e=>e.key==="Enter"&&doLogin()} placeholder={f.p} style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:13,color:B.text,background:B.pinkBg}}/>
            </div>
          ))}
          {loginError&&<div style={{padding:"8px 11px",background:B.redPale,border:`1px solid ${B.red}25`,borderRadius:8,fontSize:11,color:B.red,marginBottom:10}}>{loginError}</div>}
          <button onClick={doLogin} style={{width:"100%",padding:"13px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:4,boxShadow:`0 5px 16px ${B.pink}30`,display:"flex",alignItems:"center",justifyContent:"center",gap:9,marginTop:4}}>
            <Destello size={11} color={B.white}/>INGRESAR<Destello size={11} color={B.white}/>
          </button>
        </div>
        <button onClick={()=>{setRegForm({nombre:"",email:"",pass:"",pass2:"",codigo:"",emoji:"✨"});setRegError("");setCodigoOk(null);setRegStep(1);setScreen("register");}} style={{background:"transparent",color:B.pink,fontSize:10,fontWeight:700,letterSpacing:1,animation:"fadeUp .7s ease .3s both"}}>
          ¿Primera vez? Registrate con tu código →
        </button>
        {/* Demos */}
        <div style={{marginTop:14,padding:"11px 13px",background:B.goldPale,borderRadius:10,border:"1px solid rgba(202,161,80,0.25)",width:"100%",animation:"fadeUp .7s ease .4s both"}}>
          <div style={{fontSize:8,color:"#CAA150",fontWeight:700,letterSpacing:2,marginBottom:7}}>✦ DEMOS RÁPIDOS</div>
          {[{e:"👑",n:"Nicole Barat",m:"nicole@nikibb.com",p:"nicole123",r:"Casa Matriz"},{e:"💅",n:"Estefanía Soto",m:"este@nikibb.com",p:"este123",r:"Manicura"},{e:"🌟",n:"Bárbara Ortiz",m:"bartiz@nikibb.com",p:"ortiz123",r:"Encargada"}].map((d,i)=>(
            <div key={i} onClick={()=>setLoginForm({email:d.m,pass:d.p})} style={{display:"flex",gap:8,alignItems:"center",padding:"5px 0",borderBottom:i<2?`1px solid rgba(202,161,80,0.12)`:"none",cursor:"pointer"}}>
              <div style={{fontSize:15}}>{d.e}</div>
              <div style={{flex:1}}><div style={{fontSize:10,color:B.text,fontWeight:700}}>{d.n}</div><div style={{fontSize:8,color:B.mid}}>{d.r}</div></div>
              <div style={{fontSize:8,color:"#CAA150",fontWeight:700}}>tocar ↑</div>
            </div>
          ))}
        </div>
        <div style={{textAlign:"center",marginTop:16,fontFamily:"'Cormorant Garamond',serif",fontSize:11,color:B.glacier,fontStyle:"italic",letterSpacing:2,animation:"shimmer 5s ease infinite"}}>"It's your time to shine" ✨</div>
      </div>
    </div>
  );

  // ── REGISTRO ───────────────────────────────────────────────────────────────
  if(screen==="register") return(
    <div style={{minHeight:"100vh",maxWidth:430,margin:"0 auto",background:B.pinkBg,fontFamily:"'Lato',sans-serif",position:"relative",overflow:"hidden"}}>
      <style>{CSS}</style>
      <PatternBg opacity={0.04} id="r-p"/>
      <div style={{padding:"52px 22px 100px",position:"relative"}}>
        <button onClick={()=>regStep===1?setScreen("login"):setRegStep(regStep-1)} style={{background:"transparent",color:B.mid,fontSize:10,fontWeight:700,marginBottom:22,display:"flex",alignItems:"center",gap:4}}>← {regStep===1?"Volver al inicio":"Paso anterior"}</button>
        {/* Steps */}
        <div style={{display:"flex",gap:8,marginBottom:24,alignItems:"center",justifyContent:"center"}}>
          {[1,2,3].map(s=>(
            <div key={s} style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{width:28,height:28,borderRadius:"50%",background:regStep>=s?B.pink:B.coolGray,border:`2px solid ${regStep>=s?B.pink:B.glacier}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:700,color:regStep>=s?B.white:B.mid,transition:"all .3s"}}>{regStep>s?"✓":s}</div>
              {s<3&&<div style={{width:28,height:2,background:regStep>s?B.pink:B.glacier,borderRadius:1,transition:"all .3s"}}/>}
            </div>
          ))}
        </div>

        {/* STEP 1 — Código */}
        {regStep===1&&(
          <div style={{animation:"fadeUp .4s ease forwards"}}>
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",textAlign:"center",marginBottom:24}}>
              <div style={{width:58,height:58,borderRadius:"50%",background:`${"#CAA150"}15`,border:`2px solid ${"#CAA150"}40`,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:12,boxShadow:`0 0 0 8px ${"#CAA150"}08`}}>
                <Destello size={26} color="#CAA150" style={{animation:"destelloSpin 5s linear infinite"}}/>
              </div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:22,color:B.text,fontWeight:300,marginBottom:5}}>Bienvenida a NIKI OS ✨</div>
              <div style={{fontSize:11,color:B.mid,lineHeight:1.6,maxWidth:280}}>Necesitás el código de invitación que te envió la administradora.</div>
            </div>
            <div style={{background:B.white,borderRadius:13,padding:"20px 18px",border:`1px solid ${B.pinkLight}`,boxShadow:"0 3px 14px rgba(221,164,174,0.08)",marginBottom:10}}>
              <div style={{fontSize:8,letterSpacing:2,color:B.mid,fontWeight:700,marginBottom:7}}>CÓDIGO DE INVITACIÓN</div>
              <input value={regForm.codigo} onChange={e=>setRegForm(f=>({...f,codigo:e.target.value.toUpperCase()}))} onKeyDown={e=>e.key==="Enter"&&validarCodigo()} placeholder="Ej: NIKI-MAN-2026" style={{width:"100%",padding:"12px 13px",border:`2px solid ${B.pinkLight}`,borderRadius:9,fontSize:14,color:B.text,background:B.pinkBg,letterSpacing:2,fontWeight:700,textAlign:"center"}}/>
              <div style={{fontSize:9,color:B.mid,marginTop:7,textAlign:"center"}}>Lo recibiste por WhatsApp o mail de Nicole</div>
            </div>
            {regError&&<div style={{padding:"8px 11px",background:B.redPale,border:`1px solid ${B.red}25`,borderRadius:8,fontSize:11,color:B.red,marginBottom:9}}>{regError}</div>}
            <button onClick={validarCodigo} disabled={!regForm.codigo.trim()} style={{width:"100%",padding:"13px",background:regForm.codigo.trim()?`linear-gradient(135deg,${B.pink},${B.pinkDeep})`:B.glacier,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:9,transition:"all .3s",boxShadow:regForm.codigo.trim()?`0 5px 16px ${B.pink}25`:"none"}}>
              <Destello size={10} color={B.white}/>VALIDAR CÓDIGO
            </button>
            <div style={{marginTop:14,padding:"10px 12px",background:B.goldPale,borderRadius:9,border:"1px solid rgba(202,161,80,0.2)"}}>
              <div style={{fontSize:8,color:"#CAA150",fontWeight:700,letterSpacing:2,marginBottom:6}}>CÓDIGOS DE PRUEBA</div>
              {Object.entries(CODIGOS).map(([cod,d])=>(
                <div key={cod} onClick={()=>setRegForm(f=>({...f,codigo:cod}))} style={{display:"flex",justifyContent:"space-between",cursor:"pointer",padding:"3px 0",borderBottom:"1px solid rgba(202,161,80,0.1)"}}>
                  <div style={{fontSize:9,fontWeight:700,color:PERFILES[d.perfil]?.color,letterSpacing:1}}>{cod}</div>
                  <div style={{fontSize:8,color:B.mid}}>{PERFILES[d.perfil]?.label}{d.local?` · ${d.local}`:""}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STEP 2 — Datos */}
        {regStep===2&&codigoOk&&(
          <div style={{animation:"fadeUp .4s ease forwards"}}>
            <div style={{background:B.white,borderRadius:13,padding:"14px 16px",border:`2px solid ${PERFILES[codigoOk.perfil]?.color}50`,marginBottom:18,boxShadow:`0 3px 14px ${PERFILES[codigoOk.perfil]?.glow}`,display:"flex",alignItems:"center",gap:11}}>
              <div style={{width:44,height:44,borderRadius:"50%",background:`${PERFILES[codigoOk.perfil]?.color}15`,border:`2px solid ${PERFILES[codigoOk.perfil]?.color}50`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                <Destello size={19} color={PERFILES[codigoOk.perfil]?.color} style={{animation:"destelloSpin 4s linear infinite"}}/>
              </div>
              <div>
                <div style={{fontSize:8,color:PERFILES[codigoOk.perfil]?.color,fontWeight:700,letterSpacing:2,marginBottom:2}}>✦ ACCESO VERIFICADO</div>
                <div style={{fontSize:13,fontWeight:700,color:B.text}}>{PERFILES[codigoOk.perfil]?.label}</div>
                {codigoOk.local&&<div style={{fontSize:9,color:B.mid}}>📍 {codigoOk.local}</div>}
              </div>
            </div>
            {[{k:"nombre",l:"NOMBRE COMPLETO *",p:"Tu nombre y apellido",t:"text"},{k:"email",l:"MAIL *",p:"tu@mail.com",t:"email"},{k:"pass",l:"CONTRASEÑA *",p:"Mínimo 6 caracteres",t:"password"},{k:"pass2",l:"REPETIR CONTRASEÑA *",p:"Repetí tu contraseña",t:"password"}].map(f=>(
              <div key={f.k} style={{marginBottom:10}}>
                <div style={{fontSize:8,color:B.mid,letterSpacing:1,marginBottom:5}}>{f.l}</div>
                <input type={f.t} value={regForm[f.k]} onChange={e=>setRegForm(r=>({...r,[f.k]:e.target.value}))} placeholder={f.p} style={{width:"100%",padding:"11px 13px",border:`1.5px solid ${B.pinkLight}`,borderRadius:9,fontSize:13,color:B.text,background:B.white}}/>
              </div>
            ))}
            {regError&&<div style={{padding:"8px 11px",background:B.redPale,border:`1px solid ${B.red}25`,borderRadius:8,fontSize:11,color:B.red,marginBottom:9}}>{regError}</div>}
          </div>
        )}

        {/* STEP 3 — Emoji */}
        {regStep===3&&codigoOk&&(
          <div style={{animation:"fadeUp .4s ease forwards"}}>
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",marginBottom:22}}>
              <div style={{position:"relative",marginBottom:12}}>
                <div style={{position:"absolute",inset:-6,borderRadius:"50%",background:PERFILES[codigoOk.perfil]?.glow,filter:"blur(10px)",animation:"destelloPulse 2s ease-in-out infinite"}}/>
                <div style={{width:72,height:72,borderRadius:"50%",background:`${PERFILES[codigoOk.perfil]?.color}18`,border:`3px solid ${PERFILES[codigoOk.perfil]?.color}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:34,position:"relative"}}>{regForm.emoji}</div>
              </div>
              <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:19,color:B.text,fontWeight:300,marginBottom:4}}>{regForm.nombre}</div>
              <div style={{padding:"3px 11px",borderRadius:20,background:`${PERFILES[codigoOk.perfil]?.color}15`,border:`1px solid ${PERFILES[codigoOk.perfil]?.color}40`,fontSize:9,color:PERFILES[codigoOk.perfil]?.color,fontWeight:700}}>{PERFILES[codigoOk.perfil]?.label}</div>
            </div>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:B.text,fontWeight:300,textAlign:"center",marginBottom:4}}>Elegí tu emoji ✨</div>
            <div style={{fontSize:10,color:B.mid,textAlign:"center",marginBottom:14}}>Este será tu avatar en toda la app</div>
            <div style={{display:"flex",gap:5,marginBottom:11,overflowX:"auto",scrollbarWidth:"none"}}>
              {EMOJI_GRUPOS.map((g,i)=><button key={i} onClick={()=>setEmojiGrupo(i)} style={{padding:"4px 11px",borderRadius:20,fontSize:8,fontWeight:700,whiteSpace:"nowrap",flexShrink:0,background:emojiGrupo===i?B.text:B.white,color:emojiGrupo===i?B.white:B.mid,border:`1px solid ${emojiGrupo===i?B.text:B.glacier}`,transition:"all .2s"}}>{g.label}</button>)}
            </div>
            <div style={{background:B.white,borderRadius:13,padding:"14px",border:`1px solid ${B.pinkLight}`,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
              <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:7}}>
                {EMOJI_GRUPOS[emojiGrupo].items.map((em,i)=>(
                  <button key={i} onClick={()=>setRegForm(f=>({...f,emoji:em}))} style={{width:"100%",aspectRatio:"1",borderRadius:9,fontSize:22,background:regForm.emoji===em?`${PERFILES[codigoOk.perfil]?.color}18`:B.coolGray,border:`2px solid ${regForm.emoji===em?PERFILES[codigoOk.perfil]?.color:B.glacier}`,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s",transform:regForm.emoji===em?"scale(1.08)":"scale(1)",boxShadow:regForm.emoji===em?`0 0 10px ${PERFILES[codigoOk.perfil]?.glow}`:"none"}}>
                    {em}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,padding:"10px 22px 24px",background:B.white,borderTop:`1px solid ${B.pinkLight}`,boxShadow:"0 -2px 12px rgba(221,164,174,0.08)"}}>
        <button onClick={regStep===1?validarCodigo:regStep===2?validarDatos:finalizarReg} style={{width:"100%",padding:"13px",background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,borderRadius:9,color:B.white,fontSize:10,fontWeight:700,letterSpacing:3,display:"flex",alignItems:"center",justifyContent:"center",gap:9,boxShadow:`0 5px 16px ${B.pink}25`}}>
          <Destello size={10} color={B.white}/>{regStep===1?"VALIDAR CÓDIGO":regStep===2?"CONTINUAR →":"CREAR MI CUENTA"}
        </button>
      </div>
    </div>
  );

  // ── APP PRINCIPAL ──────────────────────────────────────────────────────────
  const TABS=[{id:"home",icon:"◆",label:"Inicio"},{id:"modules",icon:"⊞",label:"Módulos"},{id:"blog",icon:"✨",label:"Stay Tuned"}];

  return(
    <div style={{minHeight:"100vh",background:B.coolGray,fontFamily:"'Lato',sans-serif",maxWidth:430,margin:"0 auto",position:"relative"}}>
      <style>{CSS}</style>

      {/* HEADER */}
      <div style={{background:B.white,padding:"0 18px",borderBottom:`1px solid ${B.pinkLight}`,position:"sticky",top:0,zIndex:100,boxShadow:"0 2px 10px rgba(221,164,174,0.07)"}}>
        <div style={{overflow:"hidden",height:22,borderBottom:`1px solid ${B.coolGray}`,display:"flex",alignItems:"center"}}>
          <div style={{display:"flex",whiteSpace:"nowrap",animation:"ticker 28s linear infinite"}}>
            {["✨  EVENTO 17 DE MAYO","◆  NIKI OS v1.0","🧪  NIKI LAB ACTIVO","◆  5 OBRAS EN MARCHA","✨  JUNIOR → MASTER","◆  MIAMI EN CONSTRUCCIÓN"].map((t,i)=>(
              <span key={i} style={{fontSize:8,color:i%2===0?B.pink:"#CAA150",letterSpacing:2,padding:"0 25px",fontWeight:700}}>{t}</span>
            ))}
          </div>
        </div>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"10px 0 8px"}}>
          <div style={{display:"flex",alignItems:"center",gap:7}}>
            <Destello size={11} color="#CAA150"/>
            <div>
              <div style={{display:"flex",alignItems:"baseline",gap:5}}>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:16,fontWeight:300,letterSpacing:5,paddingLeft:5,color:B.pink,lineHeight:1}}>NIKI</div>
                <div style={{padding:"2px 7px",borderRadius:5,background:B.goldPale,border:"1px solid rgba(202,161,80,0.4)",fontSize:8,color:"#CAA150",fontWeight:700,letterSpacing:3}}>OS</div>
              </div>
              <div style={{fontSize:7,letterSpacing:3,color:B.mid,marginTop:1}}>SISTEMA OPERATIVO</div>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:7}}>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:10,fontWeight:700,color:B.text}}>{user.nombre.split(" ")[0]}</div>
              <div style={{fontSize:8,color:pd?.color,fontWeight:700}}>{pd?.label}</div>
            </div>
            <div style={{width:32,height:32,borderRadius:"50%",background:`${pd?.color}18`,border:`2px solid ${pd?.color}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16}}>{user.emoji}</div>
            <button onClick={()=>{setUser(null);setScreen("login");}} style={{background:"transparent",color:B.glacier,fontSize:13,padding:1}}>✕</button>
          </div>
        </div>
        <div style={{display:"flex"}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setMainTab(t.id)} style={{flex:1,padding:"7px 0 9px",background:"transparent",borderBottom:`2.5px solid ${mainTab===t.id?B.pink:"transparent"}`,color:mainTab===t.id?B.pink:B.mid,fontSize:9,fontWeight:mainTab===t.id?700:400,letterSpacing:.5,transition:"all .2s"}}>
              <div style={{fontSize:10,marginBottom:2}}>{t.icon}</div>{t.label.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* HOME */}
      {mainTab==="home"&&(
        <div style={{padding:"16px 14px 80px",animation:"fadeUp .4s ease forwards"}}>
          {/* Bienvenida */}
          <div style={{background:B.white,borderRadius:14,overflow:"hidden",marginBottom:13,border:`1.5px solid ${pd?.color}30`,boxShadow:`0 4px 16px ${pd?.glow||"rgba(202,161,80,0.2)"}`,position:"relative"}}>
            <div style={{height:4,background:`linear-gradient(90deg,${pd?.color}60,${pd?.color})`}}/>
            <PatternBg opacity={0.04} id="h-p"/>
            <div style={{padding:"16px 18px",position:"relative",display:"flex",gap:12,alignItems:"center"}}>
              <div style={{position:"relative"}}>
                <div style={{position:"absolute",inset:-4,borderRadius:"50%",background:pd?.glow,filter:"blur(8px)",animation:"destelloPulse 2.5s ease-in-out infinite"}}/>
                <div style={{width:52,height:52,borderRadius:"50%",background:`${pd?.color}18`,border:`2.5px solid ${pd?.color}50`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:26,position:"relative"}}>{user.emoji}</div>
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:11,color:B.mid,marginBottom:2}}>Hola,</div>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:B.text,fontWeight:300,lineHeight:1.2,marginBottom:5}}>{user.nombre} ✨</div>
                <div style={{display:"inline-flex",alignItems:"center",gap:5,padding:"3px 9px",borderRadius:20,background:`${pd?.color}15`,border:`1px solid ${pd?.color}40`}}>
                  <Destello size={7} color={pd?.color}/><span style={{fontSize:8,color:pd?.color,fontWeight:700}}>{pd?.label}</span>
                  {user.local&&<><span style={{fontSize:8,color:B.mid}}>·</span><span style={{fontSize:8,color:B.mid}}>📍 {user.local}</span></>}
                </div>
              </div>
            </div>
          </div>

          {/* Evento countdown */}
          {!countdown.expired&&countdown.dias!==undefined&&(
            <div style={{background:B.white,borderRadius:13,overflow:"hidden",marginBottom:12,border:`1px solid ${B.pinkLight}`,boxShadow:"0 3px 12px rgba(221,164,174,0.08)",position:"relative"}}>
              <div style={{height:3,background:`linear-gradient(90deg,${B.pink},${B.gold})`}}/>
              <PatternBg opacity={0.03} id="ev-p"/>
              <div style={{padding:"14px 16px",position:"relative"}}>
                <div style={{display:"inline-block",padding:"2px 10px",borderRadius:20,background:`${B.pink}15`,border:`1px solid ${B.pink}40`,fontSize:7,color:B.pink,fontWeight:700,letterSpacing:2,marginBottom:9}}>🎀 PRÓXIMO EVENTO ✨</div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
                  <div>
                    <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:B.text,fontWeight:300,marginBottom:2}}>Niki Beauty Bar</div>
                    <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:13,color:B.pink,fontStyle:"italic"}}>17 de Mayo, 2026</div>
                  </div>
                  <a href="https://nikibeautybar.my.canva.site/" target="_blank" rel="noopener noreferrer" style={{textDecoration:"none"}}>
                    <div style={{padding:"7px 12px",borderRadius:8,background:`linear-gradient(135deg,${B.pink},${B.pinkDeep})`,fontSize:8,color:B.white,fontWeight:700,letterSpacing:1,boxShadow:`0 3px 10px ${B.pink}25`}}>VER ›</div>
                  </a>
                </div>
                <div style={{display:"flex",gap:7}}>
                  {[{v:countdown.dias,l:"DÍAS"},{v:countdown.horas,l:"HS"},{v:countdown.min,l:"MIN"},{v:countdown.seg,l:"SEG"}].map((c,i)=>(
                    <div key={i} style={{flex:1,background:i===0?`${B.pink}10`:B.coolGray,border:`1px solid ${i===0?B.pinkLight:B.glacier}`,borderRadius:8,padding:"8px 5px",textAlign:"center"}}>
                      <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:18,color:i===0?B.pink:B.text,fontWeight:300,lineHeight:1}}>{String(c.v).padStart(2,"0")}</div>
                      <div style={{fontSize:7,color:B.mid,letterSpacing:.5,marginTop:2}}>{c.l}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Stats */}
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:7,marginBottom:13}}>
            {[{i:"🏪",l:"Locales",v:"14",c:"#CAA150"},{i:"🏗️",l:"Obras",v:"5",c:B.teal},{i:"🧪",l:"Ideas",v:"4",c:B.green},{i:"💰",l:"Inv.",v:"3",c:B.purple}].map((s,i)=>(
              <div key={i} style={{background:B.white,borderRadius:11,padding:"11px 7px",border:`1px solid ${B.pinkLight}`,textAlign:"center",boxShadow:"0 2px 5px rgba(221,164,174,0.06)"}}>
                <div style={{fontSize:14,marginBottom:3}}>{s.i}</div>
                <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:20,color:s.c,fontWeight:300,lineHeight:1}}>{s.v}</div>
                <div style={{fontSize:7,color:B.mid,marginTop:2}}>{s.l}</div>
              </div>
            ))}
          </div>

          {/* Módulos rápidos */}
          <div style={{fontSize:9,letterSpacing:3,color:B.mid,fontWeight:700,marginBottom:10}}>MÓDULOS</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            {MODULES_LIST.filter(m=>canAccess(m.id)).slice(0,6).map((mod,i)=>(
              <div key={mod.id} onClick={()=>setActiveModule(mod.id)} style={{background:B.white,borderRadius:12,padding:"13px 12px",border:`1px solid ${B.pinkLight}`,cursor:"pointer",transition:"all .2s",animation:`fadeUp .3s ease ${i*.05}s both`,position:"relative",overflow:"hidden",boxShadow:"0 2px 6px rgba(221,164,174,0.06)"}}>
                <div style={{position:"absolute",top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${mod.color}60,${mod.color})`}}/>
                <div style={{fontSize:20,marginBottom:6,marginTop:2}}>{mod.emoji}</div>
                <div style={{fontSize:11,fontWeight:700,color:B.text,marginBottom:2}}>{mod.label}</div>
                <div style={{fontSize:9,color:B.mid}}>{mod.desc}</div>
                <div style={{position:"absolute",bottom:9,right:11,color:B.pinkLight,fontSize:13}}>›</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MÓDULOS */}
      {mainTab==="modules"&&(
        <div style={{padding:"18px 14px 80px",animation:"fadeUp .4s ease forwards"}}>
          <div style={{marginBottom:16}}>
            <div style={{fontFamily:"'Cormorant Garamond',serif",fontSize:23,color:B.text,fontWeight:300,marginBottom:3}}>Módulos ✨</div>
            <div style={{fontSize:10,color:B.mid}}>NIKI OS · {permisos.filter(p=>MODULES_LIST.find(m=>m.id===p)).length} disponibles</div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
            {MODULES_LIST.map((mod,i)=>{
              const ok=canAccess(mod.id);
              return(
                <div key={mod.id} onClick={()=>ok&&setActiveModule(mod.id)} style={{background:ok?B.white:"rgba(241,241,242,0.5)",borderRadius:13,padding:"14px 12px",border:`1px solid ${ok?B.pinkLight:B.glacier}`,opacity:ok?1:.38,cursor:ok?"pointer":"not-allowed",transition:"all .2s",animation:`fadeUp .4s ease ${i*.04}s both`,position:"relative",overflow:"hidden",boxShadow:ok?"0 2px 6px rgba(221,164,174,0.06)":"none"}}>
                  {ok&&<div style={{position:"absolute",top:0,left:0,right:0,height:3,background:`linear-gradient(90deg,${mod.color}60,${mod.color})`}}/>}
                  <div style={{fontSize:21,marginBottom:7,marginTop:2}}>{mod.emoji}</div>
                  <div style={{fontSize:11,fontWeight:700,color:ok?B.text:B.mid,marginBottom:3}}>{mod.label}</div>
                  <div style={{fontSize:9,color:B.mid,lineHeight:1.4}}>{mod.desc}</div>
                  {!ok&&<div style={{position:"absolute",top:7,right:7,fontSize:10}}>🔒</div>}
                  {ok&&<div style={{position:"absolute",bottom:8,right:10,color:B.pinkLight,fontSize:13}}>›</div>}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* STAY TUNED */}
      {mainTab==="blog"&&<ModBlog user={user} onBack={()=>setMainTab("home")}/>}

      {/* BOTTOM NAV */}
      <div style={{position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,background:B.white,borderTop:`1px solid ${B.pinkLight}`,display:"flex",padding:"7px 0 13px",zIndex:100,boxShadow:"0 -2px 10px rgba(221,164,174,0.07)"}}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setMainTab(t.id)} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:2,background:"transparent",position:"relative"}}>
            <div style={{fontSize:12,color:mainTab===t.id?B.pink:B.glacier,transition:"color .2s"}}>{t.icon}</div>
            <div style={{fontSize:7,letterSpacing:.5,fontWeight:mainTab===t.id?700:400,color:mainTab===t.id?B.pink:B.mid,transition:"all .2s"}}>{t.label.toUpperCase()}</div>
            {mainTab===t.id&&<div style={{position:"absolute",bottom:-13,width:4,height:4,borderRadius:"50%",background:B.pink}}/>}
          </button>
        ))}
      </div>
    </div>
  );
}
