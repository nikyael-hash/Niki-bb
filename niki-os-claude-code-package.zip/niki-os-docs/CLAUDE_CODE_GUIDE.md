# CLAUDE_CODE_GUIDE.md — Guía para Claude Code

## CONTEXTO
Estás desarrollando NIKI OS — la app interna de Niki Beauty Bar. La owner (Nicole Barat) no tiene conocimientos técnicos. El objetivo es una app production-ready que ella y su equipo puedan usar desde el día 1.

---

## STACK RECOMENDADO

### Frontend
```
React Native con Expo
  - expo-router para navegación
  - NativeWind o StyleSheet para estilos
  - react-native-reanimated para animaciones
```

### Alternativa (si se prefiere web)
```
Next.js 14 (App Router) + Tailwind CSS
  → Deployable en Vercel en minutos
  → PWA para instalación en el teléfono
```

### Backend y servicios
```
Firebase (recomendado por simplicidad)
  - Firebase Auth (email/contraseña)
  - Firestore (base de datos)
  - Firebase Storage (fotos de auditorías)
  - Firebase Cloud Functions (lógica de servidor)

Anthropic Claude API
  - Para el cotizador de nail art
  - API key en variables de entorno del servidor (NUNCA en el cliente)
```

---

## ARCHIVOS DE REFERENCIA

| Archivo | Para qué usarlo |
|---------|----------------|
| `README.md` | Visión general y punto de entrada |
| `PRODUCT_SPEC.md` | Toda la lógica de negocio y flujos |
| `DESIGN_SYSTEM.md` | Colores, tipografía, componentes exactos |
| `MODULES.md` | Especificación detallada de cada módulo |
| `DATA_MODELS.md` | Esquemas de Firestore y reglas de seguridad |
| `BUSINESS_CONTEXT.md` | Contexto del negocio y datos reales |
| `prototype/niki-os-final-v1.jsx` | **PROTOTIPO FUNCIONAL** — referencia visual y lógica |

---

## ORDEN DE IMPLEMENTACIÓN SUGERIDO

### Fase 1 — Base (1-2 semanas)
1. Setup del proyecto (Expo / Next.js)
2. Firebase Auth — login con email/contraseña
3. Sistema de registro con código de invitación (3 pasos)
4. Pantalla de login con destellos animados por perfil
5. Navegación base (3 tabs: Inicio, Módulos, Stay Tuned)
6. Sistema de permisos por perfil

### Fase 2 — Módulos Core (2-3 semanas)
7. Comunicaciones (feed + publicar + reacciones)
8. Niki Rewards (ranking + catálogo)
9. Cotizador IA (foto + Claude API)
10. Niki Lab (ideas + votos + comentarios)

### Fase 3 — Módulos Operativos (2-3 semanas)
11. Auditorías (nueva auditoría + historial + misterioso shopper)
12. Inversores (informes + dividendos + retiro)
13. Obras (checklist equipamiento + etapas)
14. RRHH & Turnos

### Fase 4 — Módulos Internos (1-2 semanas)
15. Proyectos CM
16. Stock Depósito
17. Plan de Carrera (1:1)
18. Frases del Café
19. Skills
20. Stay Tuned / Blog

---

## VARIABLES DE ENTORNO REQUERIDAS

```env
# Firebase
FIREBASE_API_KEY=
FIREBASE_AUTH_DOMAIN=
FIREBASE_PROJECT_ID=
FIREBASE_STORAGE_BUCKET=
FIREBASE_MESSAGING_SENDER_ID=
FIREBASE_APP_ID=

# Anthropic (SOLO en servidor/functions — nunca en cliente)
ANTHROPIC_API_KEY=

# App
NEXT_PUBLIC_APP_URL=https://os.nikibeautybar.com
```

---

## REGLAS CRÍTICAS DE DISEÑO

1. **Colores exactos** — Ver `DESIGN_SYSTEM.md`. No aproximar.
2. **Destello SVG** — El path exacto es `M12 2 L13.2 10.8 L22 12 L13.2 13.2 L12 22 L10.8 13.2 L2 12 L10.8 10.8 Z`
3. **Tipografía** — Cormorant Garamond + Lato. Sin excepciones.
4. **Logo NIKI** — `fontSize: 64, letterSpacing: 16, paddingLeft: 16` para centrar correctamente
5. **maxWidth: 430px** — La app es mobile-first. Desktop es secundario.
6. **Sin nombres en login** — Solo los 5 perfiles como opciones.
7. **Idioma** — Todo en español (Argentina). Vos, no tú.

---

## FLUJO DEL COTIZADOR (Claude API)

```javascript
// En Cloud Function / API Route (NUNCA en el cliente)
export async function POST(request) {
  const { imageBase64, local, pago } = await request.json();
  
  const precioTabla = getPreciosSegunLocalYPago(local, pago);
  
  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-20250514",
    max_tokens: 600,
    messages: [{
      role: "user",
      content: [
        {
          type: "image",
          source: { type: "base64", media_type: "image/jpeg", data: imageBase64 }
        },
        {
          type: "text",
          text: `Sos la asistente de Niki Beauty Bar. Analizá esta imagen de nail art y clasificala:
- INCLUIDO ($0): Francesita, líneas, baby shine, chromas 1 tono, papel oro, strass, flores/corazones (2 total), french 4 uñas
- SIMPLE x2 ($${precioTabla.simple}): Baby boomer esponja/pincel, 1 por mano
- COMPLEJO ($${precioTabla.complejo}): Baby boomer/aura todas las uñas, diseños elaborados
Local: ${local === "estandar" ? "ESTÁNDAR" : "PREMIUM"} | Pago: ${pago === "efectivo" ? "EFECTIVO" : "TARJETA"}
Respondé SOLO JSON sin markdown: {"nivel":"incluido"|"simple"|"complejo","precio":número,"diseno":"descripción","justificacion":"1-2 oraciones","elementos":["el1","el2"],"tip":"consejo"}`
        }
      ]
    }]
  });
  
  const result = JSON.parse(response.content[0].text);
  return Response.json(result);
}
```

---

## DATOS DE PRUEBA (seed para Firebase)

```javascript
// Usuarios iniciales
const SEED_USERS = [
  { email: "nicole@nikibb.com", nombre: "Nicole Barat", perfil: "casa_matriz", emoji: "👑" },
  { email: "agus@nikibb.com",   nombre: "Agustina Quaglia", perfil: "casa_matriz", area: "Marketing", emoji: "🌸" },
  { email: "laura@nikibb.com",  nombre: "Laura Felipetti", perfil: "casa_matriz", area: "RRHH", emoji: "⭐" },
  { email: "barbara@nikibb.com",nombre: "Bárbara López", perfil: "casa_matriz", area: "Obras", emoji: "💎" },
  { email: "este@nikibb.com",   nombre: "Estefanía Soto", perfil: "manicura", local: "Adrogue", emoji: "💅" },
  { email: "bartiz@nikibb.com", nombre: "Bárbara Ortiz", perfil: "encargada", local: "Lomas", emoji: "🌟" },
  { email: "inv@nikibb.com",    nombre: "Inversor Lomas", perfil: "inversor", emoji: "💰" },
];

// Códigos de invitación iniciales
const SEED_CODIGOS = [
  { codigo: "NIKI-CM-2026",  perfil: "casa_matriz",  local: null },
  { codigo: "NIKI-FRQ-2026", perfil: "franquiciada", local: "Lomas" },
  { codigo: "NIKI-ENC-2026", perfil: "encargada",    local: "Puerto Madero" },
  { codigo: "NIKI-MAN-2026", perfil: "manicura",     local: "Adrogue" },
  { codigo: "NIKI-INV-2026", perfil: "inversor",     local: null },
];
```

---

## PREGUNTAS FRECUENTES

**¿El prototipo JSX es production-ready?**
No. Es un prototipo funcional en un solo archivo React. Úsalo como referencia de UI/UX y lógica, pero reescribilo modularmente.

**¿Cómo se generan los códigos de invitación?**
Casa Matriz tiene una pantalla de admin donde puede crear nuevos códigos especificando: perfil + local. El sistema genera el string único.

**¿La app funciona offline?**
No es requerimiento. Conexión a internet necesaria.

**¿Hay notificaciones push?**
No están en el MVP, pero se puede agregar con Firebase Cloud Messaging en una segunda fase.

**¿Multi-idioma?**
No. Solo español (Argentina).

**¿Hay un dominio?**
Sugerido: os.nikibeautybar.com o app.nikibeautybar.com

---

## ENTREGABLES ESPERADOS

1. ✅ App funcional en iOS y Android (o PWA web)
2. ✅ Todos los módulos operativos (no placeholders)
3. ✅ Base de datos Firebase configurada con seed data
4. ✅ Deploy en Vercel/Expo + dominio configurado
5. ✅ Instrucciones de uso para Nicole (sin tecnicismos)
