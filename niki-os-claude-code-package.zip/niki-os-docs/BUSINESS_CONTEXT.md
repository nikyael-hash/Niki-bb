# BUSINESS_CONTEXT.md — Contexto del Negocio

## NIKI BEAUTY BAR

### Descripción
Cadena de salones de uñas premium con sede en Buenos Aires, Argentina. Posicionamiento luxury — segmento de mercado libre en BsAs (no hay competencia directa en el segmento alto).

### Datos clave
- **Fundadora:** Nicole Barat
- **Locales:** 14 activos (6 propios + franquicias)
- **Facturación:** $20-25M ARS mensuales
- **Flagship:** Puerto Madero y Lomas (~550 clientas/mes, ticket >$35.000)
- **Expansión 2026:** Miami, USA (adquirieron operación de Umara Miami)

### Referencia de posicionamiento
Nail'd It Londres (@wenaildit) — 187K seguidores en Instagram, 28 locales globales

---

## LOCALES ACTUALES

### Sucursales propias
| Local | Tipo |
|-------|------|
| Puerto Madero | Flagship |
| Lomas de Zamora | Propio |
| Adrogue | Propio |
| Canning | Propio |
| Belgrano | Propio |
| Saavedra | Propio |

### Franquicias
Bella Vista, Recoleta, Cañitas, Banfield, Mar del Plata Centro, Mar del Plata Güemes, y más en expansión.

### Obras activas (2026)
| Obra | Etapa |
|------|-------|
| Miami — Flagship USA | Obra Civil |
| Recoleta II | Búsqueda Local |
| Ramos Mejía | Firma Contrato |
| San Isidro | Firma Contrato |
| Caballito | Búsqueda Local |

---

## MANICURAS — DATOS DE SKILL (sucursales propias)

Datos reales del último skill review. El skill % = servicios del menú que domina / 34 servicios totales.

| Nombre | Local | Skill % | Nivel |
|--------|-------|---------|-------|
| Estefanía Soto | Adrogue | 100% | Master |
| Candela Amaya | Puerto Madero | 97% | Master |
| Rosibel Gutiérrez | Puerto Madero | 100% | Master |
| Brisa Ramírez | Lomas | 97% | Master |
| Florencia Antogiovanni | Puerto Madero | 82% | Senior |
| Daniela Gambarte | Lomas | 91% | Master |
| Soledad Gómez | Canning | 91% | Master |
| Felicitas Capó | Canning | 91% | Master |
| Sol Martínez | Lomas | 74% | Senior |
| Alexandra Pérez | Canning | 71% | Senior |
| Noelia Acevedo | Adrogue | 65% | Senior |

---

## SISTEMA DE COMISIONES

| Nivel | Requisito | Comisión |
|-------|-----------|----------|
| Junior | ≤ 60% skill | 35% |
| Senior | 61-85% skill | 38% |
| Master | 86-100% skill | 40% |

**Lanzamiento:** Junio 2026

---

## MENÚ DE SERVICIOS (34 servicios totales)

El menú completo de Niki Beauty Bar incluye 34 servicios. El skill de cada manicura se mide por cuántos domina. Los principales grupos son:

- Semipermanente básico
- Kapping (gel)
- Kapping complejo
- Acrílico
- Baby boomer (esponja y pincel)
- Aura nails
- Nail art (simple y complejo)
- Pestañas
- Pedicura
- Tratamientos adicionales

---

## CONTEXTO COMPETITIVO

| Marca | Locales | Segmento | Ticket |
|-------|---------|---------|--------|
| **Niki Beauty Bar** | 14+ | **Luxury (único)** | **>$35.000** |
| UMARA | ~10 | Masivo | ~$15.000 |
| Ka Wirth | ~50 | Accesible | ~$8.000 |

**Ventaja competitiva:** El segmento luxury en BsAs está completamente libre. Niki es la única marca premium.

---

## EVENTOS Y FECHAS CLAVE

| Fecha | Evento |
|-------|--------|
| 17 Mayo 2026 | Evento presencial Niki Beauty Bar — https://nikibeautybar.my.canva.site/ |
| Junio 2026 | Implementación sistema de niveles Junior/Senior/Master |
| 2026 | Apertura Miami flagship |
| 2026 | Lanzamiento NIKI OS v1.0 |

---

## VALORES DE LA MARCA

- Luxury accesible — no exclusiva, pero sí premium
- El detalle importa — las uñas son "el accesorio que siempre llevás puesto"
- Autocuidado como necesidad, no como lujo
- Comunidad interna fuerte — todas se cuidan y crecen juntas
- El café, la conversación y la experiencia son parte del servicio

---

## NOTAS PARA EL DESARROLLO

1. **Idioma:** Todo en español (Argentina). Usar "vos" en lugar de "tú".
2. **Moneda:** Pesos argentinos ($). Usar `toLocaleString("es-AR")` para formatear.
3. **Fechas:** Formato DD/MM/YYYY o "15 Abr 2026".
4. **Nombres propios:** Nicole no quiere sus nombres propios en la pantalla de login — solo los 5 roles.
5. **Tono:** Cálido, femenino, empoderador. No corporativo.
